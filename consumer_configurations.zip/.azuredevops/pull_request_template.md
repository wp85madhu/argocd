## Checklist

***

- Is this a Production change?
  - [ ] Yes - Requires a ServiceNow Change Request
  - [ ] No

## Required for Production Change
Click [here](https://colesgroup.atlassian.net/wiki/spaces/DK/pages/1393295543/Consumer+onboarding+Change+Record+Guidance) for more details about raising a Service Now Change

**ServiceNow Change Request number**: < Enter your Change Request number here >

***

- Is this a new project onboarding?
  - [ ] Yes - Requires a Front Door (Coles Project Engagement) request
  - [ ] No

## Required for New project onboarding
Please submit a Front Door (Coles Project Engagement) request through [here](https://colesgroup.atlassian.net/servicedesk/customer/portal/6/group/55).

Refer to [Project Engagement](https://sharepoint.cmltd.net.au/sites/CloudEngineering/SitePages/Engagement.aspx) for more details.

***

## Further Reading
For use of Kubernetes at Coles please refer to our [Consumer Guides](https://colesgroup.atlassian.net/wiki/spaces/DK/pages/256676391/Consumer+Guides)

For a setup guide on managing your projects (new or existing), please refer to our [Consumer Onboarding Section](https://colesgroup.atlassian.net/wiki/spaces/DK/pages/638124434/Consumer+Onboarding).

***

*Please allow time for KubeOps team to review and approve your pull requests.* 