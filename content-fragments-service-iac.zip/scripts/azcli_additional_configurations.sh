#!/bin/bash
##########################################################################
# This script is a supplement of the Main Terraform Apply Stage.
# The purpose of this script is purely for Configuration Management.
# All Resources used here must exist via Terraform, otherwise, this script will fail.
##########################################################################

args=("$@")

resource_group_name="${args[0]}"
key_vault_name="${args[1]}"
ip_addresses="${args[2]}"
other_ip_addreses="${args[3]}"
# primary_appsvc_identity="${args[4]}"
# secondary_appsvc_identity="${args[5]}"

###########################
# KEY VAULT CONFIGURATIONS
###########################

# Get the App Service Outbound IP Address
# This will be used to IP Whitelist the App Services in the TEST Key Vault to access secrets
# NOTE: The TEST Key Vault is used by all non-production App Services (Dev, Test and SVT) 
# This is to ensure a centralized Key Vault used across environment

#Remove the existing IP Addresses first
# echo "##  Cleaning up IP Addressess...  ##"

# # Split the IPs into an array
# kv_ip_rules=$(az keyvault network-rule list --name $key_vault_name --resource-group $resource_group_name --query ipRules -o tsv)

# #echo "## TSV Results ##"
# #echo ${kv_ip_rules}
# #echo "## For each loop below ##"

# # Cleanup IP in Key Vault
# echo "## Cleaning IP Addresses from Key Vault...##"
# while IFS= read -r line; do
#     #echo "IP: ${line}"
#     az keyvault network-rule remove --name $key_vault_name --ip-address "${line}" --resource-group $resource_group_name -o none    
# done <<< "$kv_ip_rules"     

# echo "## Clean up completed...##"
# End: Remove the existing IP Addresses

# Start: Adding App Service IP Addressess
# Split the IPs into an array
IFS="," read -a arr_app_outbound_ips <<< $ip_addresses

# Add App Service IP in Key Vault
echo "## Adding App Service Outbound IP Addresses to Key Vault IP allowed list...##"
for ips in "${arr_app_outbound_ips[@]}"
do
    #echo "$ips"
    az keyvault network-rule add --name $key_vault_name --ip-address "$ips" --resource-group $resource_group_name -o none    
done

# Split the Other IPs into an array
IFS="," read -a arr_app_outbound_ips <<< $other_ip_addreses

# Add App Service IP in Key Vault
echo "## Adding App Service Other Outbound IP Addresses to Key Vault IP allowed list...##"
for ips in "${arr_app_outbound_ips[@]}"
do
    #echo "$ips"
    az keyvault network-rule add --name $key_vault_name --ip-address "$ips" --resource-group $resource_group_name -o none    
done


# Add App Service Identities to KV Access Policy
# echo "## Adding Primary: " $primary_appsvc_identity " to Key Vault ##"
# az keyvault set-policy --name $key_vault_name --resource-group $resource_group_name \
# --object-id $primary_appsvc_identity \
# --secret-permissions get list -o none

# echo "## Adding Secondary: " $secondary_appsvc_identity " to Key Vault ##"
# az keyvault set-policy --name $key_vault_name --resource-group $resource_group_name \
# --object-id $secondary_appsvc_identity \
# --secret-permissions get list -o none