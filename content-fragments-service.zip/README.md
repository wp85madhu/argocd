# Content Fragments API

## Solution Requirements
Requirements documentation can be found here:
https://colesgroup.atlassian.net/wiki/spaces/DCAU/pages/3349284271/Requirements+for+AEM+content+fragments

## Environments

### DEV

TODO

### TEST

TODO

### SVT

TODO

### PROD

TODO