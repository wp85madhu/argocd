namespace ContentFragments.Infrastructure.Options;

public class TableStorageOptions
{
    public static string Section => "TableStorage";
    public string ConnectionString { get; set; } = string.Empty;
    public string Endpoint { get; set; } = null!;
}
