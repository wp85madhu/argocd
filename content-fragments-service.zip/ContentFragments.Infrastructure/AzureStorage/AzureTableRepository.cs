using Azure;
using Azure.Data.Tables;
using Microsoft.Extensions.Logging;

namespace ContentFragments.Infrastructure.AzureStorage;

public abstract class AzureTableRepository<T> where T : class, ITableEntity, new()
{
    protected abstract string TableName { get; }
    protected TableClient TableClient { get; }
    protected ILogger Logger { get; }

    protected AzureTableRepository(IAzureStorageFactory azureStorageTableFactory, ILogger logger)
    {
        TableClient = azureStorageTableFactory.GetTableClient(TableName);
        Logger = logger;
    }

    protected async Task<IEnumerable<T>> QueryAsync(string partitionKey, string rowKey)
    {
        try
        {
            var query = string.IsNullOrWhiteSpace(rowKey) ?
                $"PartitionKey eq '{partitionKey}'" : $"PartitionKey eq '{partitionKey}' and RowKey eq '{rowKey}'";
            var result = TableClient.QueryAsync<T>(filter: query);

            await foreach (Page<T> page in result.AsPages())
            {
                return page.Values;
            }

            Logger.LogInformation("Get content complete for partition key {PartitionKey} and row key {RowKey}", partitionKey, rowKey);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Error occurred while getting content fragment data for {PartitionKey} and row key {RowKey}", partitionKey, rowKey);
            throw;
        }
        return new List<T>();
    }
}
