using Azure;
using Azure.Data.Tables;
using Azure.Identity;

namespace ContentFragments.Infrastructure.AzureStorage;

public class AzureStorageFactory : IAzureStorageFactory
{
    private readonly TableServiceClient _tableServiceClient;

    public AzureStorageFactory(string connectionString)
    {
        _tableServiceClient = new TableServiceClient(connectionString);
    }
    public AzureStorageFactory(Uri endPoint)
    {
        _tableServiceClient = new TableServiceClient(endPoint, new DefaultAzureCredential());
    }
    public TableClient GetTableClient(string tableName)
    {
        return _tableServiceClient.GetTableClient(tableName);
    }
}
