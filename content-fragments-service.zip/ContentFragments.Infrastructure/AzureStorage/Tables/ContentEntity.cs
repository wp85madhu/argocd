using Azure;
using Azure.Data.Tables;

namespace ContentFragments.Infrastructure.AzureStorage.Tables;

public class ContentEntity : ITableEntity
{
    public string PartitionKey { get; set; } = null!;
    public string RowKey { get; set; } = null!;
    public string Content { get; set; } = string.Empty;
    public DateTimeOffset? Timestamp { get; set; }
    public ETag ETag { get; set; }
}
