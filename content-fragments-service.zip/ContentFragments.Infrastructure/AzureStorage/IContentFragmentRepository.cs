using ContentFragments.Infrastructure.Models;

namespace ContentFragments.Infrastructure.AzureStorage;

public interface IContentFragmentRepository
{
    Task<IEnumerable<string>> GetContentsAsync(ContentsRequest contentRequest);
}
