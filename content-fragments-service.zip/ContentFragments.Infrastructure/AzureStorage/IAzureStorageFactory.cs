using Azure.Data.Tables;

namespace ContentFragments.Infrastructure.AzureStorage;

public interface IAzureStorageFactory
{
    public TableClient GetTableClient(string tableName);
}
