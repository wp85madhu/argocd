using ContentFragments.Infrastructure.Options;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace ContentFragments.Infrastructure.AzureStorage;

public static class ServiceExtensions
{
    public static void RegisterAzureStorage(this IServiceCollection serviceCollection,
        IConfiguration configuration, bool useConnectionString = false)
    {
        var tableStorageOptions = configuration.GetSection(TableStorageOptions.Section)
            .Get<TableStorageOptions>();

        if (useConnectionString)
        {
            var connectionString = tableStorageOptions.ConnectionString;
            serviceCollection.AddSingleton<IAzureStorageFactory>(_ => new AzureStorageFactory(connectionString));
        }
        else
        {
            serviceCollection.AddSingleton<IAzureStorageFactory>(_ => new AzureStorageFactory(new Uri(tableStorageOptions.Endpoint)));
        }

        serviceCollection.AddSingleton<IContentFragmentRepository, ContentFragmentRepository>();

    }
}
