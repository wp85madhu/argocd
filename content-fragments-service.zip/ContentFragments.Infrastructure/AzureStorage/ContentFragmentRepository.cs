using ContentFragments.Infrastructure.AzureStorage.Tables;
using ContentFragments.Infrastructure.Exceptions;
using ContentFragments.Infrastructure.Models;
using Microsoft.Extensions.Logging;

namespace ContentFragments.Infrastructure.AzureStorage;

public class ContentFragmentRepository : AzureTableRepository<ContentEntity>, IContentFragmentRepository
{
    protected sealed override string TableName => "contentfragments";

    public ContentFragmentRepository(IAzureStorageFactory azureDbFactory, ILogger<ContentFragmentRepository> logger)
        : base(azureDbFactory, logger)
    {
    }

    public async Task<IEnumerable<string>> GetContentsAsync(ContentsRequest contentRequest)
    {
        Logger.LogInformation("Get content fragment for {Category} and {SubCategory}", contentRequest.Category, contentRequest.SubCategory);

        try
        {
            var contentList = await QueryAsync(contentRequest.Category, contentRequest.SubCategory);
            return contentList.Select(content => content.Content);
        }
        catch (Exception ex)
        {
            Logger.LogError("Failed to connect to Azure Blob Storage: {Exception}", ex);
            throw new AzureBlobStorageUnavailableException("Something went wrong");
        }
    }
}
