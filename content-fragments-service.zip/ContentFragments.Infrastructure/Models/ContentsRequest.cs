namespace ContentFragments.Infrastructure.Models;

public class ContentsRequest
{
    public string Category { get; set; } = string.Empty;
    public string SubCategory { get; set; } = string.Empty;
    public string Brand { get; set; } = string.Empty;
    public string Channel { get; set; } = string.Empty;
}
