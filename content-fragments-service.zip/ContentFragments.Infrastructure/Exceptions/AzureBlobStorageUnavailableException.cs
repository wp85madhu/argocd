namespace ContentFragments.Infrastructure.Exceptions;

public class AzureBlobStorageUnavailableException : Exception
{
    public AzureBlobStorageUnavailableException(string message) : base(message)
    {

    }
}
