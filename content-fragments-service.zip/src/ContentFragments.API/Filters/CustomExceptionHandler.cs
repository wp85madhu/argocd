using System.Net.Mime;
using System.Text.Json;
using System.Text.Json.Serialization;
using ContentFragments.API.Enums;
using ContentFragments.API.Errors;
using ContentFragments.Infrastructure.Exceptions;
using FluentValidation;
using Microsoft.AspNetCore.Diagnostics;

namespace ContentFragments.API.Filters;

public static class CustomExceptionHandler
{
    public static void UseCustomExceptionHandler(this IApplicationBuilder app)
    {
        app.UseExceptionHandler(exceptionHandlerApp =>
        {
            exceptionHandlerApp.Run(async context =>
            {
                var exceptionFeature = context.Features.Get<IExceptionHandlerPathFeature>();
                await HandleExceptionAsync(context, exceptionFeature);
            });
        });
    }

    private static async Task HandleExceptionAsync(HttpContext context, IExceptionHandlerFeature? exceptionHandlerFeature)
    {
        var exception = exceptionHandlerFeature?.Error ?? null;

        var (errorResponse, statusCode) = exception switch
        {
            AzureBlobStorageUnavailableException blobStorageException =>
            (
                (
                    new ErrorResponse(blobStorageException.Message, ErrorPriority.HIGH, ErrorCode.InternalServerError),
                    StatusCodes.Status500InternalServerError
                )
            ),
            ValidationException validationException =>
            (
                new ErrorResponse
                {
                    Errors = validationException.Errors.Select(error =>
                        new ErrorDetail
                        {
                            ErrorCode = ErrorCode.BadRequest,
                            Message = error.ErrorMessage,
                            Priority = ErrorPriority.HIGH,
                            Properties = new ErrorProperty(error.PropertyName, string.Empty)
                        })
                },
                StatusCodes.Status400BadRequest
            ),
            UnauthorizedAccessException unauthorizedAccessException =>
                (
                    new ErrorResponse(unauthorizedAccessException.Message, ErrorPriority.HIGH, ErrorCode.UnauthorizedAccess),
                    StatusCodes.Status401Unauthorized
                ),
            _ =>
                (
                    new ErrorResponse(exception?.Message ?? "Internal server error", ErrorPriority.HIGH, ErrorCode.InternalServerError),
                    StatusCodes.Status500InternalServerError
                )
        };

        var errorResponseJson = JsonSerializer.Serialize(errorResponse, new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        });

        context.Response.StatusCode = statusCode;
        context.Response.ContentType = MediaTypeNames.Application.Json;

        await context.Response.WriteAsync(errorResponseJson);
    }
}
