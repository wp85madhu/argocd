using System.Net;
using ContentFragments.API.Enums;
using ContentFragments.API.Errors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace ContentFragments.API.Filters;

public class ValidateModelStateFilterAttribute : ActionFilterAttribute
{
    public override void OnActionExecuting(ActionExecutingContext context)
    {
        if (context.ModelState.IsValid)
        {
            return;
        }

        var responseObj = new ErrorResponse
        {
            Errors = context.ModelState.Values.SelectMany(o => o.Errors)
                .Select(error => new ErrorDetail()
                {
                    Message = error.ErrorMessage,
                    Priority = ErrorPriority.HIGH,
                    ErrorCode = ErrorCode.BadRequest
                })
        };

        context.Result = new JsonResult(responseObj)
        {
            StatusCode = (int)HttpStatusCode.BadRequest
        };
    }
}
