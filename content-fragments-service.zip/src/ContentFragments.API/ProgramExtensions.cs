using System.Reflection;
using ContentFragments.API.Filters;
using ContentFragments.API.Options;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

namespace ContentFragments.API;

public static class ProgramExtensions
{
    public static void RegisterAuthentication(this IServiceCollection services, IConfiguration configuration)
    {
        var azureAdSection = configuration.GetSection(AzureAdOptions.Section);
        var azureAdOptions = azureAdSection.Get<AzureAdOptions>();
        services
            .AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(options =>
            {
                options.Authority = azureAdOptions.Authority;
                options.Audience = azureAdOptions.ClientId;
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateAudience = true,
                };
            });
    }

    public static void RegisterSwagger(this IServiceCollection services)
    {
        services.AddEndpointsApiExplorer();
        services.AddSwaggerGen(s =>
        {
            s.SwaggerDoc("v1", new OpenApiInfo
            {
                Version = "1.0.0",
                Title = "Content Fragments API",
                Description = "Content Fragments",
                Contact = new OpenApiContact
                {
                    Name = "CXT API Support",
                    Email = "cxtapisupport@coles.com.au"
                }
            });
            s.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
            {
                Type = SecuritySchemeType.Http,
                BearerFormat = "JWT",
                In = ParameterLocation.Header,
                Scheme = "bearer",
                Description = "JWT Authorization header using the Bearer scheme."
            });
            s.AddServer(new OpenApiServer
            {
                Url = "/digital/content-fragment"
            });

            var xmlFileApi = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
            s.IncludeXmlComments(Path.Combine(AppContext.BaseDirectory, xmlFileApi));
        });
    }

    public static void UseAdaptiveSampling(this WebApplication app)
    {
        var telemetryConfig = app.Services.GetService<TelemetryConfiguration>();
        var telemetryProcessorChainBuilder = telemetryConfig!.DefaultTelemetrySink.TelemetryProcessorChainBuilder;

        // Using adaptive sampling
        telemetryProcessorChainBuilder.UseAdaptiveSampling(maxTelemetryItemsPerSecond: 5, "Request;Exception;Event");
        telemetryProcessorChainBuilder.Use((next) => new CustomTelemetryProcessor(next));
        telemetryProcessorChainBuilder.Build();
    }
}
