using System.Text.Json.Serialization;
using ContentFragments.API;
using ContentFragments.API.Filters;
using ContentFragments.API.Models;
using ContentFragments.API.Services;
using ContentFragments.API.Validators;
using ContentFragments.Infrastructure.AzureStorage;
using FluentValidation;
using Microsoft.ApplicationInsights.AspNetCore.Extensions;
using Microsoft.AspNetCore.Mvc;
using NLog.Web;

var builder = WebApplication.CreateBuilder(args);

/*
 * Generic micro-service configuration
 */
// Configure default API behavior
builder.Services.Configure<RouteOptions>(options =>
{
    options.LowercaseUrls = true;
});

// Add OpenAPI 3
builder.Services.RegisterSwagger();

// Add health checks
builder.Services.AddHealthChecks();

// Setup NLog logging provider
builder.Logging.ClearProviders();
builder.Host.UseNLog();

// Add App Insights
var aiOptions = new ApplicationInsightsServiceOptions { EnableAdaptiveSampling = false };

builder.Services.AddApplicationInsightsTelemetry(aiOptions);

// Add Key Vault configuration
/* To be enabled when KeyVault is ready
if (!builder.Environment.IsDevelopment())
{
    builder.Configuration.AddAzureKeyVault(
        new Uri($"https://{builder.Configuration["KeyVault:Name"]}.vault.azure.net/"),
        new DefaultAzureCredential());
}
*/

// Add AzureAd authorization
builder.Services.RegisterAuthentication(builder.Configuration);

// Configure controllers with Fluent validation
// Suppress model state invalid filter to use customized response model
builder.Services.Configure<ApiBehaviorOptions>(options =>
{
    options.SuppressModelStateInvalidFilter = true;
});

// Add services to the container.
builder.Services.AddControllers(options =>
{
    options.Filters.Add<ValidateModelStateFilterAttribute>();

    var cacheProfiles = builder.Configuration.GetSection("CacheProfiles").Get<Dictionary<string, CacheProfile>>();

    foreach (var cacheProfile in cacheProfiles)
    {
        options.CacheProfiles.Add(cacheProfile);
    }
}).AddJsonOptions(s =>
{
    s.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
});

// Add Validators
builder.Services.AddScoped<IValidator<ContentsRequestParameters>, ContentRequestValidator>();

// Add Automapper
builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());

// Add Table Storage Repository
builder.Services.RegisterAzureStorage(builder.Configuration, builder.Environment.IsDevelopment());

// Add content service
builder.Services.AddSingleton<IContentsService, ContentsService>();

var app = builder.Build();

//Use custom adaptive sampling
app.UseAdaptiveSampling();

// Use custom exception handler
app.UseCustomExceptionHandler();

app.UseSwagger();
app.UseSwaggerUI();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.MapHealthChecks("/health");

app.Run();
