using Microsoft.AspNetCore.Mvc;

namespace ContentFragments.API.Options;

public class CacheProfileSettings
{
    public Dictionary<string, CacheProfile>? CacheProfileSetting { get; set; }
}
