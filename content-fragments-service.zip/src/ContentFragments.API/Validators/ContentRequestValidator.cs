using ContentFragments.API.Enums;
using ContentFragments.API.Models;
using FluentValidation;

namespace ContentFragments.API.Validators;

public class ContentRequestValidator : AbstractValidator<ContentsRequestParameters>
{
    public ContentRequestValidator()
    {
        When(x => x.Category == Category.Liquor, () =>
        {
            RuleFor(x => x.SubCategory)
                .NotEmpty().WithMessage("Missing subCategory");
        });
    }
}
