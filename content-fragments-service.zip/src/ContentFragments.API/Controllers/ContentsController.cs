using System.Net.Mime;
using AutoMapper;
using ContentFragments.API.Errors;
using ContentFragments.API.Models;
using ContentFragments.API.Services;
using ContentFragments.Infrastructure.Models;
using FluentValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ContentFragments.API.Controllers;

[ApiController]
[Route("[controller]")]
[Produces(MediaTypeNames.Application.Json)]
[Authorize]
public class ContentsController : ControllerBase
{
    private readonly IMapper _mapper;
    private readonly IContentsService _contentService;
    private readonly IValidator<ContentsRequestParameters> _contentRequestValidator;

    public ContentsController(IMapper mapper, IContentsService contentService, IValidator<ContentsRequestParameters> contentRequestValidator)
    {
        _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        _contentService = contentService;
        _contentRequestValidator = contentRequestValidator;
    }
    /// <summary>
    /// Get content fragment
    /// </summary>
    /// <remarks>Fetches content fragment include type, subtype, state, and description</remarks>
    /// <param name="contentsRequestDto"></param>
    /// <returns></returns>
    /// <response code="200">Successful Response</response>
    /// <response code="400">Bad Request</response>
    /// <response code="401">Unauthorized</response>
    /// <response code="500">Internal Server Error</response>
    [ProducesResponseType(typeof(ContentsResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status500InternalServerError)]
    [HttpGet(Name = "getContents")]
    [ResponseCache(CacheProfileName = "PrivateCache")]
    public async Task<IActionResult> GetContents([FromQuery] ContentsRequestParameters contentsRequestDto)
    {
        await _contentRequestValidator.ValidateAndThrowAsync(contentsRequestDto);

        var contentsRequest = _mapper.Map<ContentsRequest>(contentsRequestDto);

        var contents = await _contentService.GetContentsAsync(contentsRequest);
        return Ok(contents);
    }
}
