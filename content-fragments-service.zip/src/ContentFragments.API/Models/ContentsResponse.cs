using System.Text.Json.Serialization;

namespace ContentFragments.API.Models;

public class ContentsResponse
{
    [JsonPropertyName("items")]
    public IEnumerable<object> Items { get; set; } = Enumerable.Empty<object>();
}
