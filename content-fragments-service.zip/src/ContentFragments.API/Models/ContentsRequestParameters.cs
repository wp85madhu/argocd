using System.ComponentModel.DataAnnotations;
using ContentFragments.API.Enums;

namespace ContentFragments.API.Models;

public class ContentsRequestParameters
{
    /// <summary>
    /// Customer facing brand. Only enterprise MDM reference data values are allowed
    /// </summary>
    [Required]
    public Brand? Brand { get; set; }

    /// <summary>
    /// Sales channel. Refer to https://colesgroup.atlassian.net/wiki/spaces/EA/pages/3381002323/Naming+convention
    /// </summary>
    [Required]
    public Channel? Channel { get; set; }

    [Required]
    public Category? Category { get; set; }

    /// <summary>
    /// Mandatory if category is liquor / orderConfirmation.
    /// Allowed values are NSW, WA, SA, VIC, NT, TAS, modifyOrder, togetherToZero, feedback, restrictedItem.
    /// </summary>
    public string? SubCategory { get; set; }
}
