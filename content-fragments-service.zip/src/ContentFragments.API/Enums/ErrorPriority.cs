namespace ContentFragments.API.Enums;

public enum ErrorPriority
{
    HIGH,
    MEDIUM,
    LOW
}
