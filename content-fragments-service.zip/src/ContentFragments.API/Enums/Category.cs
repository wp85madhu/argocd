using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace ContentFragments.API.Enums;

[JsonConverter(typeof(JsonStringEnumMemberConverter))]
public enum Category
{
    [EnumMember(Value = "liquor")]
    Liquor,
    [EnumMember(Value = "tobacco")]
    Tobacco,
    [EnumMember(Value = "orderSummary")]
    OrderSummary,
    [EnumMember(Value = "orderConfirmation")]
    OrderConfirmation,
}
