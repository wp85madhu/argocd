using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace ContentFragments.API.Enums;

#pragma warning disable CA1707

[JsonConverter(typeof(JsonStringEnumMemberConverter))]
public enum Channel
{
    CS_WEB,
    CS_APP,
}
