using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace ContentFragments.API.Enums;

[JsonConverter(typeof(JsonStringEnumMemberConverter))]
public enum ErrorCode
{
    [EnumMember(Value = "Upstream_Error")]
    UpStreamError,
    [EnumMember(Value = "Unauthorized_Access")]
    UnauthorizedAccess,
    [EnumMember(Value = "Bad_Request")]
    BadRequest,
    [EnumMember(Value = "Internal_Server_Error")]
    InternalServerError,
    [EnumMember(Value = "Forbidden")]
    Forbidden
}
