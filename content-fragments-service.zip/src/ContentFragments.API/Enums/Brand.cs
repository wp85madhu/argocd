using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace ContentFragments.API.Enums;

#pragma warning disable CA1707

[JsonConverter(typeof(JsonStringEnumMemberConverter))]
public enum Brand
{
    SMKT_CS,
    CEXP_CE,
    LIQ_LL,
    LIQ_1C,
    LIQ_VC
}
