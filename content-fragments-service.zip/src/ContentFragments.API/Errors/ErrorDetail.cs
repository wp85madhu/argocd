using System.Text.Json.Serialization;
using ContentFragments.API.Enums;

namespace ContentFragments.API.Errors;

public class ErrorDetail
{
    public ErrorCode ErrorCode { get; set; }
    public string? Message { get; set; }

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public ErrorPriority Priority { get; set; }
    public ErrorProperty? Properties { get; set; }
}
