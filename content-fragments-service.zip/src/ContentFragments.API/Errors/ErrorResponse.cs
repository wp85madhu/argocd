using System.Diagnostics;
using ContentFragments.API.Enums;
using FluentValidation.Results;

namespace ContentFragments.API.Errors;

public class ErrorResponse
{
    public string TraceId { get; set; }

    public DateTime Timestamp { get; set; }

    public IEnumerable<ErrorDetail> Errors { get; set; }

    public ErrorResponse(string message, ErrorPriority errorPriority, ErrorCode errorCode, ErrorProperty? properties = null)
    {
        TraceId = Activity.Current?.TraceId.ToString() ?? Guid.Empty.ToString();
        Timestamp = DateTime.UtcNow;
        Errors = new List<ErrorDetail>
        {
            new()
            {
                ErrorCode = errorCode,
                Message = message,
                Priority = errorPriority,
                Properties = properties
            }
        };
    }

    public ErrorResponse()
    {
        TraceId = Activity.Current?.TraceId.ToString() ?? Guid.Empty.ToString();
        Timestamp = DateTime.UtcNow;
        Errors = new List<ErrorDetail>();
    }

    public ErrorResponse(IEnumerable<ValidationFailure> errors)
    {
        TraceId = Activity.Current?.TraceId.ToString() ?? Guid.Empty.ToString();
        Timestamp = DateTime.UtcNow;
        Errors = errors.Select(error =>
            new ErrorDetail
            {
                ErrorCode = ErrorCode.BadRequest,
                Message = error.ErrorMessage,
                Priority = ErrorPriority.HIGH,
                Properties = new ErrorProperty(error.PropertyName, string.Empty)
            });
    }
}
