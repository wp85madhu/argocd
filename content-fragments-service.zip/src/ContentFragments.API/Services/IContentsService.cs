using ContentFragments.API.Models;
using ContentFragments.Infrastructure.Models;

namespace ContentFragments.API.Services;

public interface IContentsService
{
    Task<ContentsResponse> GetContentsAsync(ContentsRequest contentRequest);
}
