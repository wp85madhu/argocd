using System.Text.Json;
using ContentFragments.API.Models;
using ContentFragments.Infrastructure.AzureStorage;
using ContentFragments.Infrastructure.Models;

namespace ContentFragments.API.Services;

public class ContentsService : IContentsService
{
    private readonly IContentFragmentRepository _contentFragmentRepository;

    public ContentsService(IContentFragmentRepository contentFragmentRepository)
    {
        _contentFragmentRepository = contentFragmentRepository;
    }

    public async Task<ContentsResponse> GetContentsAsync(ContentsRequest contentRequest)
    {
        var content = await _contentFragmentRepository.GetContentsAsync(contentRequest);
        var response = new ContentsResponse
        {
            Items = content.Select(o => JsonSerializer.Deserialize<object>(o)!)
        };
        return response;
    }
}
