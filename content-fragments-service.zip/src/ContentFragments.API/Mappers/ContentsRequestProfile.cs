using AutoMapper;
using ContentFragments.API.Models;
using ContentFragments.Infrastructure.Models;

namespace ContentFragments.API.Mappers;

public class ContentsRequestProfile : Profile
{
    public ContentsRequestProfile()
    {
        CreateMap<ContentsRequestParameters, ContentsRequest>()
            .ForMember(d => d.Category, op => op.MapFrom(o => o.Category))
            .ForMember(d => d.SubCategory, op => op.MapFrom(o => o.SubCategory))
            .ForMember(d => d.Brand, op => op.MapFrom(o => o.Brand))
            .ForMember(d => d.Channel, op => op.MapFrom(o => o.Channel));
    }
}
