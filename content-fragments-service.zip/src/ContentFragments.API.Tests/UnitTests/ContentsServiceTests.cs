using System.Collections.Generic;
using System.Threading.Tasks;
using ContentFragments.API.Models;
using ContentFragments.API.Services;
using ContentFragments.Infrastructure.AzureStorage;
using ContentFragments.Infrastructure.Models;
using FluentAssertions;
using Moq;
using Xunit;
namespace ContentFragments.API.Tests.UnitTests;
public class ContentsServiceTests
{
    private readonly Mock<IContentFragmentRepository> _mockContentFragmentRepository;

    public ContentsServiceTests()
    {
        _mockContentFragmentRepository = new Mock<IContentFragmentRepository>();
    }

    [Fact]
    public async Task GetContent_WithCategoryEqualToTobacco_Should_ReturnValidTobaccoContent()
    {
        var expectedContentResponseJson =
            @"{""items"":[{""name"": ""tobacco"",""title"": ""Call Quit line on 13 7848"", ""description"": { ""html"": ""placeholder"", ""plaintext"": ""It is illegal to sell tobacco products to a person under 18 and it is illegal to purchase a tobacco product for use by a person under 18."", ""json"": ""placeholder""},""imageUrl"": ""/content/dam/coles/shop-categories/product/Tobacco-jpg.jpg""}]}";

        var contentResponse = new List<string>() { expectedContentResponseJson };
        var contentRequest = new ContentsRequest()
        {
            Category = "tobacco"
        };

        _mockContentFragmentRepository.Setup(s => s.GetContentsAsync(contentRequest)).ReturnsAsync(contentResponse);
        var service = new ContentsService(_mockContentFragmentRepository.Object);
        var actualItems = await service.GetContentsAsync(contentRequest);

        var result = actualItems;
        result.Items.Should().NotBeNull();
        result.Should().BeOfType<ContentsResponse>();
        result.Items.Should().BeEquivalentTo(contentResponse);
    }
}
