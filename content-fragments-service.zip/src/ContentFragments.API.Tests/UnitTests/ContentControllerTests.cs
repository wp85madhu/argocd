using System;
using System.Collections.Generic;
using AutoMapper;
using ContentFragments.API.Controllers;
using ContentFragments.API.Enums;
using ContentFragments.API.Mappers;
using ContentFragments.API.Models;
using ContentFragments.API.Services;
using ContentFragments.API.Validators;
using ContentFragments.Infrastructure.Exceptions;
using FluentAssertions;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestPlatform.CommunicationUtilities;
using Moq;
using Xunit;

namespace ContentFragments.API.Tests.UnitTests;

public class ContentControllerTests
{
    private IMapper _mapper;
    private Mock<IContentsService> mockContentService;
    private IValidator<ContentsRequestParameters> validator;

    public ContentControllerTests()
    {
        var profiles = new List<Profile>
        {
            new ContentsRequestProfile()
        };

        var mappingConfig = new MapperConfiguration(mc => mc.AddProfiles(profiles));
        _mapper = mappingConfig.CreateMapper();

        mockContentService = new Mock<IContentsService>();

        validator = new ContentRequestValidator();
    }

    //Scenario 2.2: Conditional validation
    [Fact]
    public void ConditionalValidation_CategorySupplied()
    {
        var controller =
            new ContentsController(_mapper, mockContentService.Object, validator);

        var testRequest = new ContentsRequestParameters
        {
            Brand = Brand.SMKT_CS,
            Category = Category.Liquor,
            Channel = Channel.CS_APP,
            SubCategory = "NSW"
        };

        var response = controller.GetContents(testRequest).Result;

        response.Should().BeOfType<OkObjectResult>();
    }

    //If category is Liquor, SubCategory must be supplied
    [Theory]
    [InlineData(Category.Liquor)]
    public async void ConditionalValidation_NoCategory(Category category)
    {
        var controller = new ContentsController(_mapper, mockContentService.Object, validator);

        var testRequest = new ContentsRequestParameters
        {
            Brand = Brand.SMKT_CS,
            Category = category,
            Channel = Channel.CS_APP,
            SubCategory = null
        };

        var expectedExceptionText = "Validation failed: \n -- subCategory: Missing subCategory Severity: Error";

        await controller.Invoking(c => c.GetContents(testRequest)).Should().ThrowAsync<ValidationException>().WithMessage(expectedExceptionText);
    }

    //Scenario 3.3: Unhandled error, Azure blob storage unavailable
    [Fact]
    public async void AzureBlobStorageUnavailable()
    {
        var expectedException = new AzureBlobStorageUnavailableException("Test Exception");

        var contentService = new Mock<IContentsService>();
        contentService.Setup(c => c.GetContentsAsync(It.IsAny<Infrastructure.Models.ContentsRequest>())).ThrowsAsync(expectedException);

        var controller =
            new ContentsController(_mapper, contentService.Object, validator);

        var testRequest = new ContentsRequestParameters
        {
            Brand = Brand.SMKT_CS,
            Category = Category.Liquor,
            Channel = Channel.CS_APP,
            SubCategory = "NSW"
        };

        await controller.Invoking(c => c.GetContents(testRequest)).Should()
            .ThrowAsync<AzureBlobStorageUnavailableException>();
    }
}
