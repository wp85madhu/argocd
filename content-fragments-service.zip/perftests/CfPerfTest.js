import http from 'k6/http';
import { check, sleep } from 'k6';
import { parseHTML } from "k6/html";

//To run this script, navigate to the directory containing this file and enter "k6 run CfPerfTest.js" in your terminal

let token_url = 'https://login.microsoftonline.com/82551a12-bbc8-4fed-8b7f-2b758284b5ea/oauth2/token';

//The URL of the endpoint to test against
let host_url = 'https://svt2apigw.cmltd.net.au/digital/content-fragment/v1/contents?brand=SMKT_CS&channel=CS_APP';

var client_id = "REPLACE ME"; //jwt_client_id in platform-one-svt postman collection
var client_secret = "REPLACE ME; //jwt_client_secret in platform-one-svt postman collection
var resource = "REPLACE ME"; //content_fragments_resource_id in postman collection
var apimKey = "REPLACE ME"; //content_fragments_apim_key in postman collection
let authToken = ""; //Set at run-time

var categories = [
    "liquor",
    "orderConfirmation",
    "orderSummary",
    "tobacco"
];

var subCategories = [
    "nsw",
    "vic",
    "tas",
    "act",
    "wa",
    "sa",
    "nt"
];

export let options = {
    insecureSkipTLSVerify: true,
    // If we want to test scaling up/down in stages, use "stages"
    // stages: [
    //     //{ duration: '5s', target: 5 }, //Scale up to peak load
    //     //{ duration: '60m', target: 35 }, //Run at peak load
    //     //{ duration: '1m', target: 35 },  //Continue to run at Normal load for 1 minute
    //     // { duration: '1m', target: 110 }, //Scale up to peak load over the next minute
    //     // { duration: '1m', target: 110 }, //Remain at peak load for 1 minute
    //     // { duration: '1m', target: 0 },  //Scale down to 0, end test
    // ]
    //If we want to set a specific request rate, use a "scenario";
    //Note that spinning up new VUs takes time, so best to set the scenario to aim for slightly more requests than we actually want
    scenarios: {
    constant_request_rate: {
        executor: 'constant-arrival-rate',
        rate: 10, // How many requests to attempt per timeunit (i.e, per second)
        timeUnit: '1s', // Time unit is 1 second
        duration: '5s', //Run for 5 seconds
        preAllocatedVUs: 30, // how large the initial pool of VUs would be
        maxVUs: 400, // if the preAllocatedVUs are not enough, we can initialize more
        //You may need to increase your "soft" max files limit to support more VUs, see here:
        //https://k6.io/docs/misc/fine-tuning-os/
    },
    },
};

export function setup() {
    //Setup code; this will be run once only
    console.log("Running Content Fragments load test");

    return { authToken: GetAuthToken() };
}

function GetAuthToken()
{
    let tokenHeaders = {
        "Content-Type": "application/x-www-form-urlencoded",
        Accept: "application/json"
    };

    var body =
        "grant_type=client_credentials&client_id=" +
        client_id +
        "&client_secret=" +
        client_secret +
        "&resource=" +
        resource;

    let res = http.post(token_url, body, { headers: tokenHeaders });

    authToken = res.json(['access_token']);

    console.log("Got auth token: " + authToken);

    return authToken;
}

//This "default" function will run once per iteration
export default function (data) {

    let headers = {
        Connection: "keep-alive",
        Accept: "*/*",
        "Accept-Encoding": "gzip, deflate, br",
        "Ocp-Apim-Subscription-Key": apimKey,
        Authorization: "Bearer " + data.authToken
    };

    var randomizedUrl = host_url + "&category=" + GetRandomCategory();

    if(Math.random() > 0.5) //50% change of including a random subcategory in the query
    {
        randomizedUrl += "&subCategory=" + GetRandomSubCategory();
    }

    console.log(randomizedUrl);

    let res = http.get(randomizedUrl, { headers: headers });

    console.log(res.body);

    check(res, {
        'is status 200': (r) => r.status === 200,
    });

    sleep(1);
}

function GetRandomCategory() {
    return categories[Math.floor(Math.random() * categories.length)];
}

function GetRandomSubCategory() {
    return subCategories[Math.floor(Math.random() * subCategories.length)];
}

