#!/bin/bash

set -euxo pipefail

wget -d -v -r http://pki.cmltd.net.au/pi/ -A crt -P ./certs -nH --cut-dirs=1 && set -eu
pwd
ls
find ./certs -name '*.crt' -exec openssl x509 -inform der -outform pem -in {} -out {} \;
