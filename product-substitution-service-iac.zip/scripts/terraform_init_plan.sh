#!/bin/bash
#  set -x

############################ FUNCTIONS ####################################################
terraform_plan() {
    echo "======================================================="
    echo "================ Plan Terraform ======================="
    echo "======================================================="
    terraform plan \
        -no-color \
        $tf_var_files \
        -var "client_id=$servicePrincipalId" \
        -input=false \
        $working_directory

    EXIT_CODE="$?"
    if [[ "$EXIT_CODE" -gt 0 ]]; then exit "$EXIT_CODE"; fi
}

############################ FUNCTIONS ####################################################
terraform_show() {
    echo "======================================================="
    echo "================ Show Current State ==================="
    echo "======================================================="
    terraform show \
        -no-color
       
    EXIT_CODE="$?"
    if [[ "$EXIT_CODE" -gt 0 ]]; then exit "$EXIT_CODE"; fi
}

############################ MAIN ####################################################
# This path won't work if not using BASH
. "${BASH_SOURCE%/*}"/common.sh
terraform_init
terraform_plan
terraform_show