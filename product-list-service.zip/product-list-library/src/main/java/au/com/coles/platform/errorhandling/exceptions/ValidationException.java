package au.com.coles.platform.errorhandling.exceptions;

import org.springframework.validation.Errors;

import au.com.coles.platform.errorhandling.CommonErrorCodes;

public class ValidationException extends ApplicationException {

    private static final long serialVersionUID = 571733299904514605L;
    
    private final transient Errors validationErrors;

    public ValidationException(Errors errors) {
        super(CommonErrorCodes.VALIDATION);

        this.validationErrors = errors;
    }

    public Errors getValidationErrors() {
        return validationErrors;
    }
    
}
