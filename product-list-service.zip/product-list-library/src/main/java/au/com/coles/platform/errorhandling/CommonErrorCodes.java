package au.com.coles.platform.errorhandling;

public class CommonErrorCodes {
    
    private CommonErrorCodes() {
    }
    
    public static final String GENERAL_ERROR = "general_error";
    public static final String DATE_DESERIALIZER = "date_deserializer";
    public static final String MISSING_PARAMS = "missing_params";
    public static final String VALIDATION = "validation";
    public static final String ALL_NULL_PARAMS = "all_null_params";

}
