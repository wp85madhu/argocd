package au.com.coles.platform.logging;

import static net.logstash.logback.argument.StructuredArguments.value;
import static net.logstash.logback.marker.Markers.append;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;

class ServiceInvocationContext {

    private static final String JAVAX_SERVLET_ERROR_EXCEPTION = "javax.servlet.error.exception";

    private long elapsedTimeMillis;
    private String requestMethod;
    private String requestPath;
    private int statusCode;
    private Exception exception;
    private String query;
    private String requestBody;
    private String responseBody;
    private String headerTrackingReference;
    private boolean payloadAdded = false;

    ServiceInvocationContext(HttpServletRequest request, HttpServletResponse response, long elapsedTimeMillis) {
        this.requestMethod = request.getMethod();
        this.requestPath = request.getRequestURI();
        this.query = request.getQueryString();
        this.statusCode = response.getStatus();
        this.headerTrackingReference = request.getHeader("X-Azure-Ref");
        this.exception = getExceptionFromRequest(request);
        this.elapsedTimeMillis = elapsedTimeMillis;

    }

    void addPayload(String requestBody, String responseBody) {
        this.payloadAdded = true;
        this.requestBody = requestBody;
        this.responseBody = responseBody;
    }

    Object[] getLogParameters() {
        ArrayList<Object> logParameters = new ArrayList<>();
        logParameters.add(value("requestMethod", requestMethod));
        logParameters.add(value("requestPath", requestPath));
        logParameters.add(value("statusCode", statusCode));
        logParameters.add(value("elapsedTimeMillis", elapsedTimeMillis));
        logParameters.add(append("query", query));
        logParameters.add(append("trackingreference_s", headerTrackingReference));
        
        if (payloadAdded) {
            logParameters.add(append("requestBody", requestBody));
            logParameters.add(append("responseBody", responseBody));
        }

        if (exception != null) {
            logParameters.add(exception);
        }

        return logParameters.toArray();
    }

    boolean hasServerError() {
        return statusCode == HttpStatus.INTERNAL_SERVER_ERROR.value();
    }

    private Exception getExceptionFromRequest(HttpServletRequest request) {
        return (Exception) request.getAttribute(JAVAX_SERVLET_ERROR_EXCEPTION);
    }

}
