package au.com.coles.platform.logging;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
class ServiceInvocationLogger {
    private static final Logger LOG = LoggerFactory.getLogger(ServiceInvocationLogger.class);
    private static final String LOG_TEMPLATE = "HTTP {} {} returned {} in {}ms";

    private static final String[] REQ_PATHS_TO_FILTER = new String[] { "/health", "/prometheus", "/simple-health" };
    // Request Uri path is defined in 2nd position in ServiceInvocationContext's
    // logParameters List
    private static final int REQ_PATH_LOG_PARAM_POS = 2;

    public void logInvocationError(final ServiceInvocationContext serviceInvocationContext) {
        LOG.error(LOG_TEMPLATE, serviceInvocationContext.getLogParameters());
    }

    public void logInvocation(final ServiceInvocationContext serviceInvocationContext) {
        Object[] logParams = serviceInvocationContext.getLogParameters();
        if (!shouldSkipLogging(logParams)) {
            LOG.info(LOG_TEMPLATE, serviceInvocationContext.getLogParameters());
        }
    }

    public boolean isPayloadLoggingEnabled() {
        return LOG.isDebugEnabled();
    }

    private boolean shouldSkipLogging(final Object[] logParams) {
        if (logParams == null || logParams.length < REQ_PATH_LOG_PARAM_POS) {
            return false;
        }
        String requestPath = logParams[REQ_PATH_LOG_PARAM_POS - 1].toString();
        return Arrays.asList(REQ_PATHS_TO_FILTER).stream().anyMatch(x -> x.equalsIgnoreCase(requestPath));
    }

}
