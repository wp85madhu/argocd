package au.com.coles.logging;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ ElementType.TYPE, ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
public @interface LogMe {

    LogMeLevel level() default LogMeLevel.INFO;

    enum LogMeLevel {

        INFO, DEBUG, WARNING, ERROR, TRACE
    }
}
