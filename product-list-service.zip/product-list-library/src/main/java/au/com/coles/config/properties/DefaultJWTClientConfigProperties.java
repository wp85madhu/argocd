package au.com.coles.config.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Holder for Default JWT Client related properties.
 */
@Configuration
@ConfigurationProperties("jwt.client")
public class DefaultJWTClientConfigProperties extends JWTClientConfigProperties {

}