package au.com.coles;

public interface UnitTest {
    
}
