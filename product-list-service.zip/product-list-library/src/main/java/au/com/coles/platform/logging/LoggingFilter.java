package au.com.coles.platform.logging;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;
import org.springframework.web.util.WebUtils;

import brave.ScopedSpan;
import brave.Tracer;
import brave.Tracing;

@Component
public class LoggingFilter implements Filter {

    private ServiceInvocationLogger serviceInvocationLogger;
    private Tracer tracer;
    private Tracing tracing;
    
    LoggingFilter(ServiceInvocationLogger serviceInvocationLogger,
            Tracer tracer) {
        this.serviceInvocationLogger = serviceInvocationLogger;
        this.tracer = tracer;
        this.tracing = Tracing.newBuilder().build();
    }

    public void setTracing(Tracing tracing) {
        this.tracing = tracing;
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Do nothing
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
            throws IOException, ServletException {
        
        if (servletRequest instanceof HttpServletRequest && servletResponse instanceof HttpServletResponse) {
            if (serviceInvocationLogger.isPayloadLoggingEnabled()) {
                doWithPayloadLogging((HttpServletRequest) servletRequest, (HttpServletResponse) servletResponse,
                        filterChain);
            } else {
                doWithLogging((HttpServletRequest) servletRequest, (HttpServletResponse) servletResponse, filterChain);
            }

        } else {
            filterChain.doFilter(servletRequest, servletResponse);
        }
    }

    private void doWithPayloadLogging(HttpServletRequest servletRequest, HttpServletResponse servletResponse,
            FilterChain filterChain) throws IOException, ServletException {
        ContentCachingRequestWrapper requestToCache = new ContentCachingRequestWrapper(servletRequest);
        ContentCachingResponseWrapper responseToCache = new ContentCachingResponseWrapper(servletResponse);
        
        ScopedSpan span = tracer.startScopedSpan("doWithPayloadLogging");
        long start = tracing.clock(span.context()).currentTimeMicroseconds();

        filterChain.doFilter(requestToCache, responseToCache);

        span.finish();
        long end = tracing.clock(span.context()).currentTimeMicroseconds();
        long elapsedTimeMillis = (end - start) / 1000;
        
        ServiceInvocationContext serviceInvocation = new ServiceInvocationContext(requestToCache, responseToCache,
                elapsedTimeMillis);
        serviceInvocation.addPayload(getRequestData(requestToCache), getResponseData(responseToCache));
        responseToCache.copyBodyToResponse();

        if (serviceInvocation.hasServerError()) {
            serviceInvocationLogger.logInvocationError(serviceInvocation);
        } else {
            serviceInvocationLogger.logInvocation(serviceInvocation);
        }
    }

    private void doWithLogging(HttpServletRequest servletRequest, HttpServletResponse servletResponse,
            FilterChain filterChain) throws IOException, ServletException {

        ScopedSpan span = tracer.startScopedSpan("doWithLogging");
        long start = tracing.clock(span.context()).currentTimeMicroseconds();

        filterChain.doFilter(servletRequest, servletResponse);

        span.finish();
        long end = tracing.clock(span.context()).currentTimeMicroseconds();
        long elapsedTimeMillis = (end - start) / 1000;

        ServiceInvocationContext serviceInvocation = new ServiceInvocationContext(servletRequest, servletResponse,
                elapsedTimeMillis);

        if (serviceInvocation.hasServerError()) {
            serviceInvocationLogger.logInvocationError(serviceInvocation);
        } else {
            serviceInvocationLogger.logInvocation(serviceInvocation);
        }
    }

    @Override
    public void destroy() {
        // Do nothing
    }

    private static String getRequestData(final HttpServletRequest request) {
        String payload = null;
        ContentCachingRequestWrapper wrapper = WebUtils.getNativeRequest(request, ContentCachingRequestWrapper.class);
        if (wrapper != null) {
            byte[] buf = wrapper.getContentAsByteArray();
            if (buf.length > 0) {
                try {
                    payload = new String(buf, 0, buf.length, wrapper.getCharacterEncoding());
                } catch (IOException e) {
                    payload = "ERROR: " + e.getMessage();
                }
            }
        }
        return payload;
    }

    private static String getResponseData(final HttpServletResponse response) {
        String payload = null;
        ContentCachingResponseWrapper wrapper = WebUtils.getNativeResponse(response,
                ContentCachingResponseWrapper.class);
        if (wrapper != null) {
            byte[] buf = wrapper.getContentAsByteArray();
            if (buf.length > 0) {
                try {
                    payload = new String(buf, 0, buf.length, wrapper.getCharacterEncoding());
                } catch (IOException e) {
                    payload = "ERROR: " + e.getMessage();
                }
            }
        }
        return payload;
    }
}
