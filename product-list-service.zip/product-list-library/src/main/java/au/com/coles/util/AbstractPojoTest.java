package au.com.coles.util;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.validation.constraints.NotNull;

import org.junit.Assert;
import org.junit.Test;

import com.openpojo.random.RandomFactory;
import com.openpojo.reflection.PojoClass;
import com.openpojo.reflection.PojoClassFilter;
import com.openpojo.reflection.PojoField;
import com.openpojo.validation.ValidatorBuilder;
import com.openpojo.validation.test.Tester;
import com.openpojo.validation.utils.ValidationHelper;

/**
 * Base abstract class for testing pojos.
 * <p>
 * All classes under the current package will be scanned, fields and
 * classes can be marked to be excluded.
 */
public abstract class AbstractPojoTest {

	/**
	 * Set of field names to be excluded form the tests.
	 */
	private final Set<String> excludedFieldNames;
	
	/**
	 * Set of class names to be excluded form the tests.
	 */
	private final Set<String> excludedClassNames;
	
	/**
	 * Flag indicates if we are to test the toString method has been overridden.
	 */
	private final boolean testToString;
	
	
	/**
	 * Run the tests across all classes within the implementing classes package.
	 */
	public AbstractPojoTest() {
		this(Collections.emptySet(), Collections.emptySet());
	}
	
	/**
	 * Run the tests across all classes within the implementing classes package.  Fields and
	 * Classes that matched the excluded sets will not be tested.
	 * 
	 * @param excludedFieldNames excluded field names
	 * @param excludedClassNames excluded class names
	 */
	public AbstractPojoTest(Set<String> excludedFieldNames, Set<String> excludedClassNames) {
		super();
		
		this.excludedClassNames = excludedClassNames;
		this.excludedFieldNames = excludedFieldNames;
		this.testToString = false;
	}
	
	/**
	 * Run the tests across all classes within the implementing classes package.  Fields and
	 * Classes that matched the excluded sets will not be tested.
	 * 
	 * @param excludedFieldNames excluded field names
	 * @param excludedClassNames excluded class names
	 * @param testToString indicates if we are to test the toString method has been overridden.
	 */
	public AbstractPojoTest(Set<String> excludedFieldNames, Set<String> excludedClassNames, boolean testToString) {
		super();
		
		this.excludedClassNames = excludedClassNames;
		this.excludedFieldNames = excludedFieldNames;
		this.testToString = testToString;
	}
	
    @Test
    public void testPojos() {
        
        ValidatorBuilder.create().with(getTesters())
                .build().validate(super.getClass().getPackage().getName(), new ClassesFilter(excludedClassNames));
    }
    
    @NotNull
    private Tester getterSetterTester() {
        return pojoClass -> {
            final Object classInstance = ValidationHelper.getBasicInstance(pojoClass);

            for (final PojoField fieldEntry : pojoClass.getPojoFields()) {
    
            	if (!excludedFieldNames.contains(fieldEntry.getName())) {

	                Object value = RandomFactory.getRandomValue(fieldEntry);

	                fieldEntry.invokeSetter(classInstance, value);
	
	                Assert.assertEquals(fieldEntry.invokeGetter(classInstance), value);
            	}
            }
        };
    }
    
    /**
     * Builds the array of Testers that are to be run against each POJO.
     * 
     * @return Tester[] array of Testers to be run.
     */
    private Tester[] getTesters() {
    	Set<Tester> rules = new HashSet<>();
    	
    	rules.add(getterSetterTester());
    	
    	if(testToString) {
    		rules.add(toStringTester());
    	}

    	return rules.toArray(new Tester[rules.size()]);
    }
    
    /**
     * Filter out test classes and any excluded classes i.e those that are not models
     * i.e util, json etc (really should have packaged it better).
     * 
     * @author andrewbath
     *
     */
    private static class ClassesFilter implements PojoClassFilter {
    	
    	private final Set<String> excludedClassNames;
    	

    	public ClassesFilter(Set<String> excludedClassNames) {
    		super();
    		
    		this.excludedClassNames = excludedClassNames;
    	}
    	
    	public boolean include(PojoClass pojoClass) {
    		return !pojoClass.getSourcePath().contains("/test-classes/") && !excludedClassNames.contains(pojoClass.getClazz().getSimpleName());
    	}
	}
    
    /**
     * Simple test to ensure the toString on the models is overridden.
     */
    @NotNull
    private Tester toStringTester() {
        return pojoClass -> {
            final Object classInstance = ValidationHelper.getBasicInstance(pojoClass);
            
            Assert.assertFalse(classInstance.toString().contains("@"));

        };
    }
}
