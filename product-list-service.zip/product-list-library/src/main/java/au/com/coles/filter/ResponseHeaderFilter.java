package au.com.coles.filter;

import static au.com.coles.constants.CommonConstants.CACHE_CONTROL_HEADER;
import static au.com.coles.constants.CommonConstants.CACHE_HEADER_MAX_AGE;
import static au.com.coles.constants.CommonConstants.GEOLOCATION_HEADER;
import static au.com.coles.constants.CommonConstants.SENSITIVE_FIELDS_HEADER;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
public class ResponseHeaderFilter extends OncePerRequestFilter {

    @Value("${cache.control.header.time:900}")
    private String cacheTime;
    
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        
        // Add common headers to response
        response.addHeader(CACHE_CONTROL_HEADER, CACHE_HEADER_MAX_AGE + cacheTime);
        response.addHeader(SENSITIVE_FIELDS_HEADER, "");
        response.addHeader(GEOLOCATION_HEADER, "");

        filterChain.doFilter(request, response);
        
    }
    
}
