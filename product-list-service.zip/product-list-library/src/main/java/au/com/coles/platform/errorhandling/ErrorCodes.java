package au.com.coles.platform.errorhandling;

import static org.slf4j.LoggerFactory.getLogger;

import java.util.Map;

import org.slf4j.Logger;

public class ErrorCodes {
    
    private static final Logger LOG = getLogger(ErrorCodes.class.getName());

    private Map<String, ErrorCode> errorCodeIndex;

    public ErrorCodes(Map<String, ErrorCode> errorCodeIndex) {
        this.errorCodeIndex = errorCodeIndex;
    }
    
    public ErrorCode getError(String key) {
        return this.errorCodeIndex.get(key);
    }
    
    public String getCode(String key) {
        return this.errorCodeIndex.get(key).getCode();
    }
    
    public String getDescription(String key) {
        return this.errorCodeIndex.get(key).getDescription();
    }
    
    public boolean hasKey(String key) {
        return this.errorCodeIndex.containsKey(key);
    }
    
    public ErrorCode defaultErrorCode() {
        return new ErrorCode(ErrorHandlingConstants.DEFAULT_ERROR_CODE,
                ErrorHandlingConstants.DEFAULT_ERROR_DESCRIPTION);
    }
    
    public ErrorCode getErrorCode(String key) {
        if (this.hasKey(key)) {
            return this.getError(key);
        } else {
            LOG.error("Error Property '{}' Code or Desc not set! Returning default error code.", key);
        }
        return this.defaultErrorCode();
    }
    
    @Override
    public String toString() {
        return "ErrorCodes [errorCodeIndex=" + errorCodeIndex + "]";
    }
    
}
