package au.com.coles.filter.security.jwt;

import static java.lang.String.join;
import static org.slf4j.LoggerFactory.getLogger;
import static org.springframework.http.HttpMethod.POST;

import java.io.IOException;
import java.time.Instant;

import org.slf4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import au.com.coles.config.JWTTokenResponse;
import au.com.coles.config.properties.JWTClientConfigProperties;

public class JwtClientInterceptor implements ClientHttpRequestInterceptor {

    private static final Logger LOG = getLogger(JwtClientInterceptor.class.getName());

    private static final String AUTH_HEADER = "Authorization";
    private static final String BEARER = "Bearer";
    private static final String GRANT_TYPE = "grant_type";
    private static final String CLIENT_CREDENTIALS = "client_credentials";
    private static final String CLIENT_ID = "client_id";
    private static final String CLIENT_SECRET = "client_secret";
    private static final String RESOURCE = "resource";

    private static final String TOKEN_URL = "https://login.microsoftonline.com/%s/oauth2/token?api-version=1.0";

    private static final long EXPIRE_THRESHHOLD_MS = 500;

    private JWTTokenResponse token;

    private final JWTClientConfigProperties config;

//    @Autowired
//    private RestTemplateBuilder restBuilder;

    private RestTemplate rest;
    
    public <T extends JWTClientConfigProperties> JwtClientInterceptor(final T config) {
        this.config = config;
        rest = new RestTemplate();
    }

//    @PostConstruct
//    public void init() {
//        rest = restBuilder.build();
//    }

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
            throws IOException {

        // Grab a token if ours is null or expired
        if (null == token || tokenExpired()) {
            token = getToken();
        }

        request.getHeaders().set(AUTH_HEADER, join(" ", BEARER, token.getAccessToken()));
        return execution.execute(request, body);
    }

    private JWTTokenResponse getToken() {
        String url = String.format(TOKEN_URL, config.getTennantId());
        LOG.debug("Fetching new JWT Token from {}", url);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add(GRANT_TYPE, CLIENT_CREDENTIALS);
        map.add(CLIENT_ID, config.getId());
        map.add(CLIENT_SECRET, config.getSecret());
        map.add(RESOURCE, config.getResource());
        HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(map, headers);
        ResponseEntity<JWTTokenResponse> response = rest.exchange(url, POST, entity, JWTTokenResponse.class);
        return response.getBody();
    }

    private boolean tokenExpired() {
        long now = Instant.now().getEpochSecond();
        long expiredTime = Long.parseLong(token.getExpiresOn());
        boolean result = expiredTime - now < EXPIRE_THRESHHOLD_MS;
        LOG.debug("Checking if JWT from {} is expired at {}. Result: {}", expiredTime, now, result);
        return result;
    }
}