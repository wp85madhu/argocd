package au.com.coles.config.properties;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

/**
 * Holder for JWT Client related properties.
 */
public class JWTClientConfigProperties {
    
    private Boolean enabled;
    private String resource;
    private String tennantId;
    private String id;
    private String secret;

    @PostConstruct
    public void init() {
        // Set enabled to false if not set
        if (null == this.enabled) {
            this.enabled = false;
        }
    }
    
    public String getResource() {
        return resource;
    }
    
    public void setResource(String resource) {
        this.resource = resource;
    }
    
    public String getTennantId() {
        return tennantId;
    }
    
    public void setTennantId(String tennantId) {
        this.tennantId = tennantId;
    }
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getSecret() {
        return secret;
    }
    
    public void setSecret(String secret) {
        this.secret = secret;
    }
    
    public Boolean getEnabled() {
        return enabled;
    }
    
    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }
    
}
