package au.com.coles.validation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import au.com.coles.validation.constraints.DateFormatValidator;

/**
 * Validates the date by the given date pattern
 *
 * @deprecated use the
 *             {@link au.com.coles.validation.constraints.ValidDateFormat}
 *             constraint instead
 */
@Target({ ElementType.FIELD, ElementType.METHOD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = DateFormatValidator.class)
@Documented
@Deprecated
public @interface CheckDateFormat {

    String message() default "Date format is not valid";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String pattern();

}