package au.com.coles.platform.util;

/**
 * Common Constants.
 *
 * @author andrewbath
 *
 */
public class CommonConsts {

    private CommonConsts() {
    }

    /**
     * Date Time Format.
     * <p>
     * Seem to be pasted all over the shop, incorrectly i.e hh instead of HH, thus
     * we lose the AM/PM precision.
     */
    public static final String DATE_TIME_FORMAT = "dd-MM-yyyy HH:mm:ss";
}
