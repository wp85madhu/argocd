package au.com.coles.platform.errorhandling;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ErrorResponse {

    @JsonProperty
    private String traceId;
    
    private ZonedDateTime timestamp;
    
    @JsonProperty
    private List<ErrorResponseObject> errors = new ArrayList<>();
    
    public ErrorResponse() {
        this.timestamp = ZonedDateTime.now();
    }
    
    public void addError(ErrorResponseObject error) {
        errors.add(error);
    }
    
    public List<ErrorResponseObject> getErrors() {
        return errors;
    }
    
    public void setErrors(List<ErrorResponseObject> errors) {
        this.errors = errors;
    }
    
    public String getTraceId() {
        return traceId;
    }
    
    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }
    
    public ZonedDateTime getTimestamp() {
        return timestamp;
    }
    
    public void setTimestamp(ZonedDateTime timestamp) {
        this.timestamp = timestamp;
    }

}
