package au.com.coles.config;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.web.client.RestTemplate;

import au.com.coles.config.properties.DefaultJWTClientConfigProperties;
import au.com.coles.filter.security.jwt.JwtClientInterceptor;
import au.com.coles.filter.subscriptionkey.SubscriptionKeyInterceptor;

/**
 * Configuration class which creates a RestTemplate bean which will inject the
 * ocp-apim-subscription-key header into every HTTP request. Ensure that you set
 * the key in the properties file using productpricing.apim.subscription.key;
 *
 */
@Configuration
public class RestConfig {

    // Default to 10 seconds
    @Value("${microservices.rest.readTimeout:10000}")
    private int readTimeout;

    @Autowired
    private DefaultJWTClientConfigProperties jwtConfigProperties;

    @Autowired
    private SubscriptionKeyInterceptor subscriptionKeyInterceptor;

    @Bean(name = "commonRestTemplate")
    public RestTemplate restTemplate(final RestTemplateBuilder builder) {

        Collection<ClientHttpRequestInterceptor> interceptors = new ArrayList<>();

        // Add subscription key header to all HTTP requests
        interceptors.add(subscriptionKeyInterceptor);

        // Add JWT Token if enabled
        if (Boolean.TRUE.equals(jwtConfigProperties.getEnabled())) {
            JwtClientInterceptor jwtInterceptor = new JwtClientInterceptor(jwtConfigProperties);
            interceptors.add(jwtInterceptor);
        }

        return builder.setReadTimeout(Duration.ofMillis(readTimeout))
                      .interceptors(interceptors)
                      .build();
    }

}