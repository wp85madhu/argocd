package au.com.coles.logging;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

/**
 * Annotation to log the Class/Method Name.
 *
 * How to use:
 *
 * Add @LogMe on the top of the class or method declaration.
 *
 * The class will need to be managed by the Spring Context for the annotation to
 * work. i.e. Autowired instead of new SomeClass().
 *
 * You can also change the log level like so:
 *
 * @LogMe(level = LogMe.LogMeLevel.ERROR)
 */
@Slf4j
@Aspect
@Component
public class LogAspect {

    @Before(value = "@within(logMe)", argNames = "joinPoint, logMe")
    public void logclass(JoinPoint joinPoint, LogMe logMe) {
        log(joinPoint, logMe);
    }

    @Before(value = "@annotation(logMe)", argNames = "joinPoint, logMe")
    public void logMethod(JoinPoint joinPoint, LogMe logMe) {
        log(joinPoint, logMe);
    }

    private void log(JoinPoint joinPoint, LogMe logMe) {
        String format = "[{}][{}]";
        String className = joinPoint.getTarget().getClass().getSimpleName();
        String methodName = joinPoint.getSignature().getName();

        switch (logMe.level()) {

            case INFO:
                log.info(format, className, methodName);
                break;
            case DEBUG:
                log.debug(format, className, methodName);
                break;
            case ERROR:
                log.error(format, className, methodName);
                break;
            case TRACE:
                log.trace(format, className, methodName);
                break;
            case WARNING:
                log.warn(format, className, methodName);
                break;
            default:
                log.info(format, className, methodName);
                break;
        }
    }
}
