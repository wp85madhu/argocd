package au.com.coles.config;

import static org.slf4j.LoggerFactory.getLogger;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.EnumerablePropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.env.PropertySource;

import au.com.coles.platform.errorhandling.ErrorCode;
import au.com.coles.platform.errorhandling.ErrorCodes;
import au.com.coles.platform.errorhandling.ErrorHandlingConstants;

@Configuration
public class ErrorCodeConfig {

    private static final Logger LOG = getLogger(ErrorCodeConfig.class.getName());

    private static final String PREFIX = "microservice.errors.";
    private static final String CODE_SUFFIX = ".code";
    private static final String DESC_SUFFIX = ".desc";
    
    @Autowired
    private Environment env;

    @Bean
    public ErrorCodes errorCodes() {

        Map<String, String> codes = new HashMap<>();
        Map<String, String> descriptions = new HashMap<>();
        
        String newKey;
        // Build up map of codes and descriptions
        if (env instanceof ConfigurableEnvironment) {
            for (PropertySource<?> propertySource : ((ConfigurableEnvironment) env).getPropertySources()) {
                if (propertySource instanceof EnumerablePropertySource) {
                    for (String key : ((EnumerablePropertySource<?>) propertySource).getPropertyNames()) {

                        if (key.startsWith(PREFIX)) {
                            if (key.endsWith(CODE_SUFFIX)) {
                                newKey = getKey(key);
                                codes.put(newKey, (String) propertySource.getProperty(key));
                            } else if (key.endsWith(DESC_SUFFIX)) {
                                newKey = getKey(key);
                                descriptions.put(newKey, (String) propertySource.getProperty(key));
                            }
                        }
                    }
                }
            }
        }
        return create(codes, descriptions);
    }
    
    private ErrorCodes create(Map<String, String> codes, Map<String, String> descriptions) {
        Map<String, ErrorCode> errorCodes = new HashMap<>();
        
        Set<String> allCodes = new HashSet<>(codes.keySet());
        allCodes.addAll(descriptions.keySet());
        
        allCodes.forEach(k -> {

            // Log an error if the properties are missing
            if (!codes.containsKey(k)) {
                errorCodes.put(k, defaultErrorCode(k, CODE_SUFFIX));
            } else if (!descriptions.containsKey(k)) {
                errorCodes.put(k, defaultErrorCode(k, DESC_SUFFIX));
            } else {
                String code = codes.get(k);
                String desc = descriptions.get(k);
                ErrorCode error = new ErrorCode(code, desc);
                errorCodes.put(k, error);
            }

        });
        return new ErrorCodes(errorCodes);
    }

    private String getKey(String propertyKey) {
        String newKey = StringUtils.remove(propertyKey, PREFIX);
        newKey = StringUtils.remove(newKey, CODE_SUFFIX);
        newKey = StringUtils.remove(newKey, DESC_SUFFIX);
        return newKey;
    }

    private ErrorCode defaultErrorCode(String key, String suffix) {
        String property = PREFIX.concat(key);
        LOG.error("Field {} not set for property {}!", suffix, property);

        String description = ErrorHandlingConstants.DEFAULT_ERROR_DESCRIPTION.concat(" : ").concat(property);
        return new ErrorCode(ErrorHandlingConstants.DEFAULT_ERROR_CODE, description);
    }
    
}
