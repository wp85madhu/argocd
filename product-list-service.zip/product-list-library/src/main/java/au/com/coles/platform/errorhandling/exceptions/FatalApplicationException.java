package au.com.coles.platform.errorhandling.exceptions;

import static org.slf4j.LoggerFactory.getLogger;

import org.slf4j.Logger;
import org.springframework.http.HttpStatus;

import au.com.coles.platform.errorhandling.ErrorHandlingConstants.Priority;

public class FatalApplicationException extends ApplicationException {
    
    private static final Logger LOG = getLogger(FatalApplicationException.class.getName());
    private static final long serialVersionUID = 571733299904514605L;
    private static final HttpStatus FATAL_APPLICATION_DEFAULT_HTTP_STATUS = HttpStatus.INTERNAL_SERVER_ERROR;

    public FatalApplicationException(String errorCodeProperty) {
        super(errorCodeProperty, DEFAULT_PRIORITY, null, FATAL_APPLICATION_DEFAULT_HTTP_STATUS);
    }

    public FatalApplicationException(String errorCodeProperty, HttpStatus httpStatus, Throwable t) {
        super(errorCodeProperty, httpStatus, t);
    }
    
    public FatalApplicationException(String errorCodeProperty, HttpStatus httpStatus) {
        super(errorCodeProperty, httpStatus);
    }
    
    public FatalApplicationException(String errorCodeProperty, Priority priority) {
        super(errorCodeProperty, priority, null, FATAL_APPLICATION_DEFAULT_HTTP_STATUS);
    }

    public FatalApplicationException(String errorCodeProperty, Priority priority, HttpStatus httpStatus) {
        super(errorCodeProperty, priority, httpStatus);
    }

    public FatalApplicationException(String errorCodeProperty, Throwable t) {
        super(errorCodeProperty, DEFAULT_PRIORITY, t, FATAL_APPLICATION_DEFAULT_HTTP_STATUS);
    }
    
    public FatalApplicationException(String errorCodeProperty, Priority priority, Throwable t) {
        super(errorCodeProperty, priority, t, FATAL_APPLICATION_DEFAULT_HTTP_STATUS);
    }

    public FatalApplicationException(String errorCodeProperty, Priority priority, Throwable t,
            HttpStatus httpStatus) {
        super(errorCodeProperty, priority, t, httpStatus);
    }
    
    /**
     * Override the log method to ensure we log errors for
     * FatalApplicationExceptions.
     */
    @Override
    protected void log(String errorCodeProperty, Throwable t) {
        // Log the original exception if we had one, otherwise just log the message
        if (null == t) {
            LOG.error(MSG, errorCodeProperty);
        } else {
            LOG.error("{}. Exception: {}", MSG, errorCodeProperty, t);
        }
    }
}
