package au.com.coles.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;

import com.microsoft.applicationinsights.TelemetryConfiguration;
import com.microsoft.applicationinsights.web.internal.WebRequestTrackingFilter;

@Configuration
@ConditionalOnProperty({ "azure.application-insights.instrumentation-key" })
public class AppInsightsConfig {

    @Bean
    public String telemetryConfig(
            @Value("${azure.application-insights.instrumentation-key}") final String instrumentaionKey) {

        if (instrumentaionKey != null) {
            TelemetryConfiguration.getActive().setInstrumentationKey(instrumentaionKey);
        }
        return instrumentaionKey;
    }

    /**
     * Programmatically registers a FilterRegistrationBean to register
     * WebRequestTrackingFilter
     *
     * @param webRequestTrackingFilter
     * @return Bean of type {@link FilterRegistrationBean}
     */
    @Bean
    public FilterRegistrationBean<WebRequestTrackingFilter> webRequestTrackingFilterRegistrationBean(
            final WebRequestTrackingFilter webRequestTrackingFilter) {

        FilterRegistrationBean<WebRequestTrackingFilter> registration = new FilterRegistrationBean<>();
        registration.setFilter(webRequestTrackingFilter);
        registration.addUrlPatterns("/*");
        registration.setOrder(Ordered.HIGHEST_PRECEDENCE + 10);
        return registration;
    }

    /**
     * Creates bean of type WebRequestTrackingFilter for request tracking
     *
     * @param applicationName Name of the application to bind filter to
     * @return {@link Bean} of type {@link WebRequestTrackingFilter}
     */
    @Bean
    @ConditionalOnMissingBean
    public WebRequestTrackingFilter webRequestTrackingFilter(
            @Value("${spring.application.name:application:coles-microservice}") final String applicationName) {

        return new WebRequestTrackingFilter(applicationName);
    }

}