package au.com.coles.platform.errorhandling;

public class ErrorHandlingConstants {

    // Only used for uncaught exceptions
    public static final String DEFAULT_ERROR_CODE = "99";
    public static final String DEFAULT_ERROR_DESCRIPTION = "This error has not been mapped.";
    
    public enum Priority {
        LOW, MEDIUM, HIGH
    }
    
    public static final String PROFILE_INVALID_ERROR_MSG = "Invalid Profile";
}
