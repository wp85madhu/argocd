package au.com.coles.config.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Holder for JWT related properties.
 */
@Component
@ConfigurationProperties("jwt")
public class JWTConfigProperties {

    /**
     * Flag indicates if JWT is to be enabled.
     */
    private boolean enabled = false;

    /**
     * Aud (audience) claim that must be matched.
     */
    private String aud;

    /**
     * URI to fetch the JWK's.
     */
    private String jwkUri;

    /**
     * Iss (issuer) claim that must be matched.
     */
    private String iss;

    /**
     * Url pattern for paths to apply the JWT filter.
     */
    private String[] filterPattern;

    /**
     * JWT Cache properties.
     */
    private Cache cache = new Cache();

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getAud() {
        return aud;
    }

    public void setAud(String aud) {
        this.aud = aud;
    }

    public String getJwkUri() {
        return jwkUri;
    }

    public void setJwkUri(String jwkUri) {
        this.jwkUri = jwkUri;
    }

    public String getIss() {
        return iss;
    }

    public void setIss(String iss) {
        this.iss = iss;
    }

    public String[] getFilterPattern() {
        return filterPattern;
    }

    public void setFilterPattern(String[] filterPattern) {
        this.filterPattern = filterPattern;
    }

    public Cache getCache() {
        return cache;
    }

    public void setCache(Cache cache) {
        this.cache = cache;
    }

    /**
     * Cache properties holder.
     */
    public static class Cache {

        /**
         * JWK cache size, default 5
         */
        private long size = 5;

        /**
         * Expiry time (in hrs) of the JWK cache, default 24 hours.
         */
        private long expiry = 24;

        public long getSize() {
            return size;
        }

        public void setSize(long size) {
            this.size = size;
        }

        public long getExpiry() {
            return expiry;
        }

        public void setExpiry(long expiry) {
            this.expiry = expiry;
        }
    }
}
