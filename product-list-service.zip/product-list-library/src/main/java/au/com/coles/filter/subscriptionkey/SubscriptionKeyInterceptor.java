package au.com.coles.filter.subscriptionkey;

import static org.slf4j.LoggerFactory.getLogger;

import java.io.IOException;
import java.net.URI;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;

/**
 * Interceptor for all requests to handle the subscription keys added
 * to headers.
 * <p>
 * Multiple subscription keys are supported, each key will have a current
 * active status, only active keys will be attempted to be used.
 * <p>
 * Usage should hopefully stay pretty straight forward, in that for now,
 * APIM URI's are prefixed with the platform before the version number
 * i.e ../merchandise/V1/..., if in the properties files property of
 * name 'microservice.apim.merchandise.subscription.keys' is defined
 * then it will be automatically picked up as the sub key to use.  This this
 * proves not to be the case then we can add support for specifying the key
 * at a later date.
 *
 * Update 01/02/2019
 * This code subtracts the URL string between the host name and version number, then replaces "/" into ".", converts to lower case
 * Example: (more examples in the unit testing)
 * - http://localhost:8080/digital/utils/v1/stores?a=true
 *   result: digital.utils
 *   property name: microservice.apim.digital.utils.subscription.keys
 * - http://localhost:8080/platform/V99999/stores?a=true
 *   result: platform
 *   property name: microservice.apim.platform.subscription.keys
 * - http://dev1apigw.cmltd.net.au/example/hello/world/v555/member/6008943000000018?login=true
 *   result: example.hello.world
 *   property name: microservice.apim.example.hello.world.subscription.keys
 * - https://dev1apigw.cmltd.net.au/MERChandise/d365/V321/products/items/itemnumbers
 *   result: merchandise.d365
 *   property name: microservice.apim.merchandise.d365.subscription.keys
 */
@Component
public final class SubscriptionKeyInterceptor implements ClientHttpRequestInterceptor {
	
	private static final Logger LOG = getLogger(SubscriptionKeyInterceptor.class.getName());
	
    private static final String APIM_KEY_HEADER = "Ocp-Apim-Subscription-Key";
    
    /**
     * Keys will be masked when logged, this indicates the number of digits to show.
     */
    private static final int NUM_KEY_CHARS_TO_SHOW = 6;
    
    @Autowired
    private SubscriptionKeyCache subscriptionKeyCache;

	
    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {

    	String platformId = getPlatformFromUri(request.getURI());
    	
    	LOG.debug("Retrieved platformId: {}", platformId);
    	
    	if((platformId == null) || !platformId.isEmpty()) {
	        Set<SubscriptionKey> subscriptionKeys = subscriptionKeyCache.getActiveSubscriptionKeys(platformId);
	        
	        if(!subscriptionKeys.isEmpty()) {
	        	return executeWithSubscriptionKeys(request, body, execution, subscriptionKeys);
	        }
	        
	        LOG.debug("No active subscription keys found for platformId: {}", platformId);
    	}
    	
    	// fire it off without the subscription key
    	return execution.execute(request, body);
    }
    
    /**
     * Attempts to execute the request, using the given set of SubscriptionKeys.  Each key will be attempted, the
     * first successful request will be returned.  SubscriptionKeys will be marked as inactive or active depending
     * on the result of the call.
     */
    private ClientHttpResponse executeWithSubscriptionKeys(HttpRequest request, byte[] body, ClientHttpRequestExecution execution, Set<SubscriptionKey> subscriptionKeys) throws IOException {
    	
    	HttpHeaders headers = request.getHeaders();
        
    	ClientHttpResponse httpResponse = null;
    	
    	for(SubscriptionKey subscriptionKey : subscriptionKeys) {
    		headers.set(APIM_KEY_HEADER, subscriptionKey.getKey());

    		httpResponse = execution.execute(request, body);
    		
    		String maskedKey = maskSubscriptionKey(subscriptionKey.getKey());
    		
    		if(HttpStatus.UNAUTHORIZED.equals(httpResponse.getStatusCode())) {
    			LOG.debug("Request with subscription key {} failed.", maskedKey);
    			
    			subscriptionKey.setActive(false);
    			
    			// close response, probably required to free any resources etc
    			httpResponse.close();
    		} else {
    			LOG.debug("Request with subscription key {} success.", maskedKey);
    			
    			subscriptionKey.setActive(true);
    			
    			break;
    		}
    	}
    	
    	return httpResponse;
    }
    
    /**
     * Retrieves the platform identifier from request URI.  For now we will
     * "assume" (yeh this might not got to plan) that the current implementation
     * of the subscription keys are based on the platform, and the platform prefix's
     * the version in the url.
     * 
     * @param uri the request url
     * 
     * @return String platform identifier, or null if we could not retrieve it
     */
    private String getPlatformFromUri(URI uri) {

    	if(uri != null) {
	    	String uriStr = uri.getPath();
	        Pattern pattern = Pattern.compile("[\\/][Vv]{1}[0-9]+(;rev=[0-9]+)?[\\/]");
	        Matcher matcher = pattern.matcher(uriStr);
	        
	        if(matcher.find()){
	        	return uriStr.substring(1, matcher.start()).replaceAll("/", ".").toLowerCase();
	        }
        }
    	
    	return null;
    }
    
    /**
     * Returns a string representation of the given subscription key masked to only
     * show a certain number of chars.
     * 
     * @param subscriptionKey the subscription key to mask
     * 
     * @return String the masked subscription key
     */
    private String maskSubscriptionKey(String subscriptionKey) {
    	return StringUtils.overlay(subscriptionKey, StringUtils.repeat("*", subscriptionKey.length() - NUM_KEY_CHARS_TO_SHOW), 0, subscriptionKey.length() - NUM_KEY_CHARS_TO_SHOW);
    }
}
