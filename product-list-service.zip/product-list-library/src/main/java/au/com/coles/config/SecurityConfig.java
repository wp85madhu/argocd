package au.com.coles.config;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.auth0.jwt.impl.PublicClaims;

import au.com.coles.config.properties.JWTConfigProperties;
import au.com.coles.filter.security.jwt.JwtValidationFilter;

/**
 * Security Configuration.
 * <p>
 * Sets the JWT token validation filter, currently on all paths,
 * JWT security is done at an app level for now (might need a more
 * granular approach i.e endpoint level later).
 * <p>
 * Will need to look at how we enable/disable across services, for now
 * we'll just use all required props being defined as the switch to enable.
 * <p>
 * A JWT token is valid if:
 * <ul>
 * <li> JWT token within Authorization header
 * <li> Audience (aud) claim matches
 * <li> Expiry Date is valid
 * <li> Issuer (iss) claim matches
 * <li> Signature valid
 * </ul>
 */
@Configuration
@ConditionalOnProperty({ "jwt.enabled" })
public class SecurityConfig {

	@Autowired
	private JWTConfigProperties jwtProperties;

	
	@Bean
	public FilterRegistrationBean<JwtValidationFilter> jwtValidationFilter() throws MalformedURLException {
		FilterRegistrationBean<JwtValidationFilter> filterRegBean = new  FilterRegistrationBean<>();
		
		Map<String, Object> claims = new HashMap<>();
		claims.put(PublicClaims.AUDIENCE, jwtProperties.getAud());
		claims.put(PublicClaims.ISSUER, jwtProperties.getIss());
		
		filterRegBean.addUrlPatterns(jwtProperties.getFilterPattern());
		
		filterRegBean.setFilter(new JwtValidationFilter(claims,
													   jwtProperties.getJwkUri(),
													   jwtProperties.getCache().getSize(),
													   jwtProperties.getCache().getExpiry()));
		
		return filterRegBean;	
	}
}
