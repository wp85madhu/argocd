package au.com.coles.platform.util;

import java.io.IOException;
import java.math.BigDecimal;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

/**
 * NOTE:  3 decimal place formatting is required, as confirmed with Steve, an
 * example would be size of a can of coke i.e 375ml, would be 0.375 of a litre.
 */
public class CustomBigDecimalSerializer extends JsonSerializer<BigDecimal> {
    
    private static final Integer BIG_DECIMAL_NO_OF_DECIMALS = 3;
    
    /**
     * Method serializes BigDecimal with 3 decimal points
     *
     * @param value
     * @param jgen
     * @param provider
     * @throws IOException
     */
    @Override
    public void serialize(BigDecimal value, JsonGenerator jgen, SerializerProvider provider)
            throws IOException {
        jgen.writeString(value.setScale(BIG_DECIMAL_NO_OF_DECIMALS, BigDecimal.ROUND_HALF_UP).toString());
    }
}
