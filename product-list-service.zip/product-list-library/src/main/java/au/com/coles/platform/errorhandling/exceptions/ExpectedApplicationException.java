package au.com.coles.platform.errorhandling.exceptions;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;

import au.com.coles.platform.errorhandling.ErrorHandlingConstants.Priority;

public class ExpectedApplicationException extends ApplicationException {

    private static final long serialVersionUID = 571733299904514605L;

    private Map<String, String> properties = new HashMap<>();

    public ExpectedApplicationException(String errorCodeProperty) {
        super(errorCodeProperty);
    }

    public ExpectedApplicationException(String errorCodeProperty, HttpStatus httpStatus) {
        super(errorCodeProperty, httpStatus);
    }

    public ExpectedApplicationException(String errorCodeProperty, Priority priority) {
        super(errorCodeProperty, priority);
    }

    public ExpectedApplicationException(String errorCodeProperty, Priority priority, HttpStatus httpStatus) {
        super(errorCodeProperty, priority, httpStatus);
    }

    public ExpectedApplicationException(String errorCodeProperty, Throwable t) {
        super(errorCodeProperty, t);
    }

    public ExpectedApplicationException(String errorCodeProperty, Priority priority, Throwable t) {
        super(errorCodeProperty, priority, t);
    }

    public ExpectedApplicationException(String errorCodeProperty, Priority priority, Throwable t,
            HttpStatus httpStatus) {
        super(errorCodeProperty, priority, t, httpStatus);
    }

    @Override
    public Map<String, String> getProperties() {
        return properties;
    }

    public void addProperty(String key, String value) {
        this.properties.put(key, value);
    }

}
