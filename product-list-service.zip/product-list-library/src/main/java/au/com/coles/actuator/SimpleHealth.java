package au.com.coles.actuator;

import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.health.CompositeHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.actuate.health.OrderedHealthAggregator;
import org.springframework.stereotype.Component;

@Component
@Endpoint(id = "simple-health")
public class SimpleHealth {

    private static final String DB_INDICATOR = "dbHealthIndicator";
    private static final String DISK_INDICATOR = "diskSpaceHealthIndicator";

    @Autowired
    private Map<String, HealthIndicator> indicators;

    private HealthIndicator simpleIndicator;

    @PostConstruct
    public void setup() {
        indicators.remove(DB_INDICATOR);
        indicators.remove(DISK_INDICATOR);
        simpleIndicator = new CompositeHealthIndicator(new OrderedHealthAggregator(), indicators);
    }

    @ReadOperation
    public Health health() {
        return simpleIndicator.health();
    }
}
