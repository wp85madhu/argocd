package au.com.coles.platform.errorhandling;

public class ErrorCode {
    
    private String code;
    private String description;

    public ErrorCode(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }
    
    public String getDescription() {
        return description;
    }
    
    @Override
    public String toString() {
        return "ErrorCode [code=" + code + ", description=" + description + "]";
    }
    
}
