package au.com.coles.config;

import com.fasterxml.jackson.annotation.JsonProperty;

public class JWTTokenResponse {
    @JsonProperty("not_before")
    private String notBefore;
    
    @JsonProperty("resource")
    private String resource;

    @JsonProperty("expires_in")
    private String expiresIn;

    @JsonProperty("token_type")
    private String tokenType;

    @JsonProperty("expires_on")
    private String expiresOn;

    @JsonProperty("access_token")
    private String accessToken;

    @JsonProperty("ext_expires_in")
    private String extExpires;
    
    public String getNotBefore() {
        return notBefore;
    }
    
    public void setNotBefore(String notBefore) {
        this.notBefore = notBefore;
    }
    
    public String getResource() {
        return resource;
    }
    
    public void setResource(String resource) {
        this.resource = resource;
    }
    
    public String getExpiresIn() {
        return expiresIn;
    }
    
    public void setExpiresIn(String expiresIn) {
        this.expiresIn = expiresIn;
    }
    
    public String getTokenType() {
        return tokenType;
    }
    
    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }
    
    public String getExpiresOn() {
        return expiresOn;
    }
    
    public void setExpiresOn(String expiresOn) {
        this.expiresOn = expiresOn;
    }
    
    public String getAccessToken() {
        return accessToken;
    }
    
    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }
    
    public String getExtExpires() {
        return extExpires;
    }
    
    public void setExtExpires(String extExpires) {
        this.extExpires = extExpires;
    }
    
}
