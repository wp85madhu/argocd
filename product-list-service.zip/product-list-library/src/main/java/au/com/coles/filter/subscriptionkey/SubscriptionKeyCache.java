package au.com.coles.filter.subscriptionkey;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * Basic cache for the SubscriptionKeys.
 * <p>
 * Keys will be attempted to be retrieved from the keyCache map, if
 * they don't exist aka not loaded yet, then will be attempted to
 * be fetched from the app properties.
 * <p>
 * Calling getActiveSubscriptionKeys will return all the known
 * active keys, should all keys be marked as inactive, then all keys
 * will be returned, in an attempt to recycle through them (guard
 * against outages etc).
 */
@Component
final class SubscriptionKeyCache {

	/*
	 * prefix and suffix of the platform key prop names
	 */
	static final String SUBSCRIPTION_KEY_PROP_PREFIX = "microservice.apim.";
	static final String SUBSCRIPTION_KEY_PROP_SUFFIX = ".subscription.keys";
	
	/**
	 * Cache of the platform id, to set of SubscriptionKey's
	 */
	private Map<String, Set<SubscriptionKey>> keyCache;
	
	@Autowired
	private Environment environment;


	/**
	 * Constructor
	 */
	public SubscriptionKeyCache() {
		super();
		
		keyCache = new HashMap<>();
	}
	
	/**
	 * Returns the subscription keys that are currently marked as active, should all
	 * current keys be inactive, then all known keys will be return to attempt again (covers
	 * outage scenarios etc).
	 * 
	 * @param platform the platform id to retrieve keys for
	 * 
	 * @return Set<SubscriptionKey> set of all known active keys, or all inactive keys if
	 * all have previously been marked as inactive.
	 */
	public Set<SubscriptionKey> getActiveSubscriptionKeys(String platform) {
		Set<SubscriptionKey> activeKeySet = getSubscriptionKeys(platform).stream().filter(SubscriptionKey::isActive).collect(Collectors.toSet());
		
		if(activeKeySet.isEmpty()) {
			return getSubscriptionKeys(platform);
		}
		
		return activeKeySet;
	}
	
	/**
	 * Returns the set of SubscriptionKeys for the given platform within the cache.  If the platform
	 * doesnt exist within the case, then keys will be attempted to be fetched from the properties.
	 * 
	 * @param platform @param platform the platform id to retrieve keys for
	 * 
	 * 
	 * @return Set<SubscriptionKey> set of all known active keys
	 */
	private Set<SubscriptionKey> getSubscriptionKeys(String platform) {
		if(!keyCache.containsKey(platform)) {
			fetchSubscriptionKeyConfig(platform);
		}
		
		return keyCache.get(platform);
	}
	
	/**
	 * Attempts to fetch the subscription keys from the properties files for the 
	 * given platform identifier.
	 * 
	 * @param platform String identifying the platform i.e merchindise, digital etc
	 */
	private void fetchSubscriptionKeyConfig(String platform) {
		String subKeysStr = environment.getProperty(SUBSCRIPTION_KEY_PROP_PREFIX + platform + SUBSCRIPTION_KEY_PROP_SUFFIX);
		
		Set<SubscriptionKey> keySet = new LinkedHashSet<>();
		
		if((subKeysStr != null) && !subKeysStr.isEmpty()) {
			
			for(String subKey : subKeysStr.split(",")) {
				keySet.add(new SubscriptionKey(subKey));
			}
		}
		
		// add the empty place holder anyway, save attempting to refetch them
		keyCache.put(platform, keySet);
	}
}
