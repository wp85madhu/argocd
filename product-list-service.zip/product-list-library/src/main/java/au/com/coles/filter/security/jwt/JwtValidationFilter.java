package au.com.coles.filter.security.jwt;

import static org.slf4j.LoggerFactory.getLogger;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.interfaces.RSAPublicKey;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.web.filter.GenericFilterBean;

import com.auth0.jwk.Jwk;
import com.auth0.jwk.JwkException;
import com.auth0.jwk.JwkProvider;
import com.auth0.jwk.JwkProviderBuilder;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.impl.PublicClaims;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.Verification;

/**
 * Validates a JWT Token.
 * <p>
 * JWT is valid when within expiry date, all expected claims match and the
 * signature is verified.
 * <p>
 * 401 UNAUTHORIZED will be returned whenever validation fails.
 * <p>
 * Uses the java-jwt and jwks-rsa (auth0) libs, as they support JWK.
 *
 */
public final class JwtValidationFilter extends GenericFilterBean {

    private static final Logger LOG = getLogger(JwtValidationFilter.class.getName());

    /**
     * Authorization header that contains the JWT.
     */
    static final String AUTH_HEADER = "Authorization";

    /**
     * JWT Prefix, aka all JWT's start off 'Bearer xxxxxx....'
     */
    static final String TOKEN_PREFIX = "Bearer ";

    /**
     * Cached JwtProvider.
     */
    private final JwkProvider jwkProvider;

    /**
     * Map of all claims and there values that are to be used within the validation
     * of the token.
     */
    private final Map<String, Object> claims;

    /**
     * Constructor
     * <p>
     * Sets up the JwkProvider.
     * 
     * @param claims     the claims that are to be validated within the JWT.
     * @param jwkUri     URI to fetch the JWK's.
     * @param cacheSize  JWK cache size
     * @param expiryTime Expiry time (in hrs) of the JWK cache
     * 
     * @throws MalformedURLException
     */
    public JwtValidationFilter(Map<String, Object> claims,
            String jwkUri,
            long cacheSize,
            long expiryTime) throws MalformedURLException {

        this(claims, new JwkProviderBuilder(new URL(jwkUri)).cached(cacheSize, expiryTime, TimeUnit.HOURS).build());
    }

    /**
     * Constructor
     * <p>
     * Uses the given JwkProvider
     * 
     * @param claims      the claims that are to be validated within the JWT.
     * @param jwkProvider JwkProvider to use
     */
    JwtValidationFilter(Map<String, Object> claims,
            JwkProvider jwkProvider) {

        super();

        this.claims = new HashMap<>(claims);

        this.jwkProvider = jwkProvider;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        try {
            String authHeader = ((HttpServletRequest) request).getHeader(AUTH_HEADER);

            if ((authHeader == null) || !authHeader.startsWith(TOKEN_PREFIX)) {
                LOG.debug("No vaild 'Authorization' header in request.");

                ((HttpServletResponse) response).sendError(HttpStatus.UNAUTHORIZED.value());

                return;
            }

            validate(authHeader.substring(TOKEN_PREFIX.length()));

            chain.doFilter(request, response);
        } catch (Exception ex) {
            LOG.error("Error whilst validating JWT", ex);

            ((HttpServletResponse) response).sendError(HttpStatus.UNAUTHORIZED.value());
        }
    }

    /**
     * Validates the given token. A valid token is one that:
     * <ul>
     * <li>expected claims all match
     * <li>token has not expired
     * <li>signature is verified
     * </ul>
     * 
     * @param token JWT to validate
     * 
     * @return DecodedJWT the decoded JWT, returned only if valid
     * 
     * @throws JwkException thrown if any issues verifying token
     */
    private DecodedJWT validate(String token) throws JwkException {
        DecodedJWT jwtUnchecked = JWT.decode(token);

        Algorithm algorithm = Algorithm.RSA256((RSAPublicKey) getJwk(jwtUnchecked.getKeyId()).getPublicKey(), null);

        Verification verification = JWT.require(algorithm);

        for (Map.Entry<String, Object> entry : claims.entrySet()) {
            addClaim(verification, entry.getKey(), entry.getValue());
        }

        return verification.build().verify(token);
    }

    /**
     * Returns the JWK that matches the given kidId.
     * <p>
     * Underlying implementation uses the GuavaCachedJwkProvider to cache the JWK's.
     * 
     * @param kid kid from the token to fetch JWK for.
     * 
     * @return Jwk Jwk that represents the given kid
     * 
     * @throws JwkException Thrown if JWK cannot be found for the given kid
     */
    private Jwk getJwk(String kid) throws JwkException {

        return jwkProvider.get(kid);
    }

    /**
     * Adds the given claim to the Verification. Only values of type String,
     * Boolean, Integer, Long, Double and Date are supported, others will be
     * ignored.
     * <p>
     * NOTE: This is messy but for now will do.
     * 
     * @param verification Verification to add rule to
     * @param name         the claim name
     * @param value        the claim value
     */
    private void addClaim(Verification verification, String name, Object value) {
        // has to be done this way as aud and issuer are expected to have a list of strings
        if (PublicClaims.AUDIENCE.equals(name)) {
            verification.withAudience((String) value);
        } else if (PublicClaims.ISSUER.equals(name)) {
            verification.withIssuer((String) value);
        } else if (value instanceof String) {
            verification.withClaim(name, (String) value);
        } else if (value instanceof Integer) {
            verification.withClaim(name, (Integer) value);
        } else if (value instanceof Boolean) {
            verification.withClaim(name, (Boolean) value);
        } else if (value instanceof Long) {
            verification.withClaim(name, (Long) value);
        } else if (value instanceof Double) {
            verification.withClaim(name, (Double) value);
        } else if (value instanceof Date) {
            verification.withClaim(name, (Date) value);
        }

        LOG.debug("Unsupported claim: {}, value: {}", name, value);
    }
}
