package au.com.coles.platform.util;

import static org.slf4j.LoggerFactory.getLogger;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;

/**
 * Horrible Date Util.
 * 
 * I pulled this out of the Products Service so at least it won't be pasted
 * everywhere. We should just be defaulting date inputs to today if that is the
 * expected behaviour.
 *
 */
public class DateUtil {

    private static final Logger LOG = getLogger(DateUtil.class.getName());

    private DateUtil() {

    }

    /**
     * Returns the date string as a Date, if not given or unable to convert then
     * returns current date.
     *
     * @param dateStr date string to convert
     *
     * @return Date
     */
    public static Date convertToDateOrToday(String dateStr) {
        Date date = null;

        try {
            if (dateStr != null) {
                date = new SimpleDateFormat(CommonConsts.DATE_TIME_FORMAT).parse(dateStr);
            }
        } catch (Exception ex) {
            LOG.warn("Error parsing date. Returning currrent date.", ex);
        }

        return date != null ? date : new Date();
    }
}
