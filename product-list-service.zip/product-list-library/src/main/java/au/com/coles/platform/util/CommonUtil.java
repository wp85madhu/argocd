package au.com.coles.platform.util;

import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

public class CommonUtil {

    public static final String STORE_ID_LEADING_ZERO = "%04d";

    private static final Pattern AUSTRALIAN_MOBILE_NO_PATTERN = Pattern.compile("\\A(\\+614|614|04|4{1})(\\d{8})\\z");

    private CommonUtil() {
    }

    /**
     * Method appends 0 at the front of StoreId if its only 3 digits.
     *
     * @param storeId Store Id - 3 or 4 digits
     * @return - Store Id - 4 digits (if 3 digits, will be prefixed with 0)
     */
    public static String formatStoreId(final String storeId) {
        return String.format(STORE_ID_LEADING_ZERO, Integer.parseInt(storeId));
    }

    public static String maskCreditCardNumber(final String creditCardNumber) {
        if (creditCardNumber != null) {
            final String s = creditCardNumber.replaceAll("\\D", "");
            final int start = 4;
            final int end = s.length() - 4;
            final String overlay = StringUtils.repeat("x", end - start);
            return StringUtils.overlay(s, overlay, start, end);
        }
        return creditCardNumber;
    }

    public static boolean isAustralianMobileNumber(final String number) {
        if (StringUtils.isBlank(number)) {
            return false;
        }
        return AUSTRALIAN_MOBILE_NO_PATTERN.matcher(number.replaceAll("\\s", "")).find();
    }

}
