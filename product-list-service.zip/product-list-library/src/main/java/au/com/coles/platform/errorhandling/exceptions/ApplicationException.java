package au.com.coles.platform.errorhandling.exceptions;

import static org.slf4j.LoggerFactory.getLogger;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.springframework.http.HttpStatus;

import au.com.coles.platform.errorhandling.ErrorHandlingConstants;
import au.com.coles.platform.errorhandling.ErrorHandlingConstants.Priority;

/**
 * General Exception which encapsulates all error handling. The only required
 * parameter is errorCodeProperty which must map to two application properties.
 * Both properties must be prefixed with 'microservice.errors' and end with
 * 'code' or 'desc'.
 *
 *
 * @author kim
 *
 */
public abstract class ApplicationException extends RuntimeException {
    
    private static final Logger LOG = getLogger(ApplicationException.class.getName());
    private static final long serialVersionUID = -2669120511667257614L;
    
    protected static final Priority DEFAULT_PRIORITY = ErrorHandlingConstants.Priority.HIGH;
    protected static final HttpStatus DEFAULT_HTTP_STATUS = HttpStatus.BAD_REQUEST;
    public static final String MSG = "Threw Expected Exception. Error Property was: {}. ";

    // Required Param
    private final String errorCodePropertyName;
    
    // Optional Params
    private final ErrorHandlingConstants.Priority priority;
    private final HttpStatus httpStatus;
    @SuppressWarnings("squid:S1165")
    private Throwable originalException;

    public ApplicationException(String errorCodeProperty) {
        this(errorCodeProperty, DEFAULT_PRIORITY, null, DEFAULT_HTTP_STATUS);
    }
    
    public ApplicationException(String errorCodeProperty, HttpStatus httpStatus) {
        this(errorCodeProperty, DEFAULT_PRIORITY, null, httpStatus);
    }
    
    public ApplicationException(String errorCodeProperty, HttpStatus httpStatus, Throwable t) {
        this(errorCodeProperty, DEFAULT_PRIORITY, t, httpStatus);
    }
    
    public ApplicationException(String errorCodeProperty, Priority priority) {
        this(errorCodeProperty, priority, null, DEFAULT_HTTP_STATUS);
    }

    public ApplicationException(String errorCodeProperty, Priority priority, HttpStatus httpStatus) {
        this(errorCodeProperty, priority, null, httpStatus);
    }

    public ApplicationException(String errorCodeProperty, Throwable t) {
        this(errorCodeProperty, DEFAULT_PRIORITY, t, DEFAULT_HTTP_STATUS);
    }
    
    public ApplicationException(String errorCodeProperty, Priority priority, Throwable t) {
        this(errorCodeProperty, priority, t, DEFAULT_HTTP_STATUS);
    }

    public ApplicationException(String errorCodeProperty, Priority priority, Throwable t,
            HttpStatus httpStatus) {

        this.log(errorCodeProperty, t);
        
        this.originalException = t;
        this.errorCodePropertyName = errorCodeProperty;
        this.priority = priority;
        this.httpStatus = httpStatus;
    }

    public String getErrorCodePropertyName() {
        return errorCodePropertyName;
    }

    public ErrorHandlingConstants.Priority getPriority() {
        return priority;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }
    
    public Throwable getOriginalException() {
        return originalException;
    }
    
    public Map<String, String> getProperties() {
    	return new HashMap<>();
    }

    protected void log(String errorCodeProperty, Throwable t) {
        // Log the original exception if we had one, otherwise just log the message
        if (null == t) {
            LOG.debug(MSG, errorCodeProperty);
        } else {
            LOG.debug("{}. Exception: {}", MSG, errorCodeProperty, t);
        }
    }
    
}
