package au.com.coles.platform.errorhandling;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonIgnore;

import au.com.coles.platform.errorhandling.ErrorHandlingConstants.Priority;

public class ErrorResponseObject {
    
    private String errorCode;
    private String message;
    private Priority priority;
    private Map<String, String> properties;
    
    @JsonIgnore
    private HttpStatus status;

    @JsonIgnore
    private Throwable originalException;

    /**
     * Required for Deserialization
     */
    ErrorResponseObject() {
        super();
    }

    public ErrorResponseObject(ErrorCode error, Priority priority, HttpStatus status) {
        this.errorCode = error.getCode();
        this.message = error.getDescription();
        this.priority = priority;
        this.status = status;
        this.properties = new HashMap<>();
    }

    public ErrorResponseObject(String errorCode, String message, Priority priority, HttpStatus status) {
        this.errorCode = errorCode;
        this.message = message;
        this.priority = priority;
        this.status = status;
        this.properties = new HashMap<>();
    }
    
    public ErrorResponseObject(String errorCode, String message, Priority priority, HttpStatus status, Map<String, String> properties) {
        this.errorCode = errorCode;
        this.message = message;
        this.priority = priority;
        this.status = status;
        this.properties = properties;
    }

    public ErrorResponseObject(Throwable ex) {
        
        this.errorCode = ErrorHandlingConstants.DEFAULT_ERROR_CODE;
        this.message = ex.getMessage();
        this.status = HttpStatus.INTERNAL_SERVER_ERROR;
        this.priority = ErrorHandlingConstants.Priority.HIGH;
        this.originalException = ex;
        this.properties = new HashMap<>();
    }

    public HttpStatus getStatus() {
        return status;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public String getMessage() {
        return message;
    }

    public Priority getPriority() {
        return priority;
    }

    public Throwable getOriginalException() {
        return originalException;
    }

    public void setStatus(HttpStatus status) {
        this.status = status;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setPriority(Priority priority) {
        this.priority = priority;
    }

    public void setOriginalException(Throwable originalException) {
        this.originalException = originalException;
    }

	public Map<String, String> getProperties() {
		return properties;
	}

	public void setProperties(Map<String, String> properties) {
		this.properties = properties;
	}
    
}
