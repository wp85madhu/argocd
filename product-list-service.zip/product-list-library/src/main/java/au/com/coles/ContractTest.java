package au.com.coles;

public interface ContractTest {
    
}
