package au.com.coles.platform.errorhandling;

import static au.com.coles.platform.errorhandling.ErrorHandlingConstants.DEFAULT_ERROR_CODE;
import static org.slf4j.LoggerFactory.getLogger;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import au.com.coles.platform.errorhandling.exceptions.PayloadValidationException;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import au.com.coles.platform.errorhandling.ErrorHandlingConstants.Priority;
import au.com.coles.platform.errorhandling.exceptions.ApplicationException;
import au.com.coles.platform.errorhandling.exceptions.ValidationException;
import au.com.coles.platform.util.TraceUtil;

@Order(value = Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class CustomErrorHandler extends ResponseEntityExceptionHandler {

    private static final Logger LOG = getLogger(CustomErrorHandler.class.getName());

    @Autowired
    private TraceUtil traceUtil;

    @Autowired
    private ErrorCodes errorCodes;

    @ExceptionHandler(value = ValidationException.class)
    ResponseEntity<ErrorResponse> handleValidationException(ValidationException ex, WebRequest request) {

        ErrorResponse response = new ErrorResponse();
        response.setTraceId(traceUtil.getTraceId());

        // Create an error for each validation issue
        org.springframework.validation.Errors validationErrors = ex.getValidationErrors();

        String key = ex.getErrorCodePropertyName();
        ErrorCode error = errorCodes.getError(key);
        for (ObjectError o : validationErrors.getAllErrors()) {
            // Append the validation message to the description
            String description = error.getDescription().concat(" ")
                    .concat(o.getObjectName()).concat(" ")
                    .concat(o.getDefaultMessage());
            ErrorResponseObject errorResponseObject = new ErrorResponseObject(error.getCode(), description,
                    ex.getPriority(), ex.getHttpStatus());
            response.addError(errorResponseObject);
        }

        return new ResponseEntity<>(response, ex.getHttpStatus());
    }


    @ExceptionHandler(value = PayloadValidationException.class)
    ResponseEntity<ErrorResponse> handlePayloadValidationException(PayloadValidationException ex, WebRequest request){

            String key = ex.getErrorCodePropertyName();
            ErrorCode error = errorCodes.getError(key);
            ErrorResponseObject errorResponseObject = new ErrorResponseObject(error.getCode(), error.getDescription(),
                    ex.getPriority(), ex.getHttpStatus(), ex.getProperties());
            ErrorResponse response = addTraceAndWrap(errorResponseObject);

            return new ResponseEntity<>(response, ex.getHttpStatus());
        }
    /**
     * Method to handle any ApplicationExceptions. This will show the
     * ErrorResponseObject which includes the traceId and the error Code/Description
     * which is configured in application properties.
     *
     * @param ex
     * @param request
     * @return ErrorResponseObject
     */
    @ExceptionHandler(value = ApplicationException.class)
    ResponseEntity<ErrorResponse> handleApplicationException(ApplicationException ex, WebRequest request) {

        String key = ex.getErrorCodePropertyName();
        ErrorCode error = errorCodes.getError(key);
        if (null == error) {
            return new ResponseEntity<>(unmappedError(key), INTERNAL_SERVER_ERROR);
        }

        ErrorResponseObject errorResponseObject = new ErrorResponseObject(error.getCode(), error.getDescription(),
                ex.getPriority(), ex.getHttpStatus(), ex.getProperties());
        ErrorResponse response = addTraceAndWrap(errorResponseObject);

        return new ResponseEntity<>(response, ex.getHttpStatus());
    }

    @ExceptionHandler(value = ConstraintViolationException.class)
    ResponseEntity<ErrorResponse> handleValidationError(ConstraintViolationException ex, WebRequest request) {

        ErrorCode error = errorCodes.getError(CommonErrorCodes.VALIDATION);

        if (null == error) {
            // for now, if there's no error code defined then default to the uppercase of
            // the code key. This allows us to not have to have this defined in all apps,
            // and really we should only have the one code for all validation errors and
            // the message explicitly describe the issue
            error = new ErrorCode(CommonErrorCodes.VALIDATION.toUpperCase(), "");
        }

        ErrorResponse response = new ErrorResponse();
        response.setTraceId(traceUtil.getTraceId());

        for (ConstraintViolation<?> constraint : ex.getConstraintViolations()) {
            String msg = ((PathImpl) constraint.getPropertyPath()).getLeafNode().getName() + ": "
                    + constraint.getMessage();

            ErrorResponseObject errorResponseObject = new ErrorResponseObject(error.getCode(), msg, Priority.HIGH,
                    HttpStatus.BAD_REQUEST);

            response.getErrors().add(errorResponseObject);

            LOG.info("Handling validation exception {} raised by {} responding with {}", ex, request,
                    errorResponseObject);
        }

        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = Throwable.class)
    ResponseEntity<ErrorResponse> handleUnexpectedError(Throwable ex, WebRequest request) {
        return getErrorResponseObjectResponseEntity(ex, HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

    private ResponseEntity<ErrorResponse> getErrorResponseObjectResponseEntity(Throwable ex,
            HttpStatus internalServerError, WebRequest request) {

        LOG.error("Caught unwrapped exception: {}", ex);

        ErrorCode error = errorCodes.getError(CommonErrorCodes.GENERAL_ERROR);
        if (null == error) {
            return new ResponseEntity<>(unmappedError(CommonErrorCodes.GENERAL_ERROR), internalServerError);
        }
        ErrorResponseObject errorResponseObject = new ErrorResponseObject(error.getCode(), error.getDescription(),
                Priority.HIGH, HttpStatus.BAD_REQUEST);
        request.setAttribute("javax.servlet.error.exception", ex, 0);

        ErrorResponse response = this.addTraceAndWrap(errorResponseObject);

        return new ResponseEntity<>(response, internalServerError);
    }

    /**
     * Written in specific for Profiles Validation - Spring throws
     * HttpMessageNotReadableException if it cant convert a invalid string to Enum
     * Profile
     */
    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
            HttpHeaders headers, HttpStatus status, WebRequest request) {
        ErrorResponseObject errorResponseObject = new ErrorResponseObject(ex);

        ErrorResponse response = addTraceAndWrap(errorResponseObject);

        LOG.info("Handling validation exception {} raised by {} responding with {}", ex, request, errorResponseObject);
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    @Override
    protected ResponseEntity<Object> handleMissingServletRequestParameter(MissingServletRequestParameterException ex,
            HttpHeaders headers, HttpStatus status, WebRequest request) {

        return createMissingParameterResponse(ex, status);
    }

    @Override
    protected ResponseEntity<Object> handleNoHandlerFoundException(final NoHandlerFoundException ex,
            final HttpHeaders headers, final HttpStatus status, final WebRequest request) {

        ErrorResponseObject errorResponseObject = new ErrorResponseObject(ex);
        ErrorResponse response = this.addTraceAndWrap(errorResponseObject);
        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
    }

    private ErrorResponse addTraceAndWrap(ErrorResponseObject error) {

        ErrorResponse response = new ErrorResponse();
        response.setTraceId(traceUtil.getTraceId());
        response.addError(error);

        return response;
    }

    /**
     * If an error code was not mapped then return this.
     *
     * @param errorKey
     * @return
     */
    private ErrorResponse unmappedError(String errorKey) {

        String description = String.format("Error Code '%s' is not mapped.", errorKey);
        LOG.error(description);

        ErrorResponseObject errorResponseObject = new ErrorResponseObject(DEFAULT_ERROR_CODE, description,
                Priority.HIGH,
                HttpStatus.INTERNAL_SERVER_ERROR);

        return addTraceAndWrap(errorResponseObject);
    }

    @Override
    protected ResponseEntity<Object> handleServletRequestBindingException(ServletRequestBindingException ex,
            HttpHeaders headers,
            HttpStatus status,
            WebRequest request) {

        return createMissingParameterResponse(ex, status);
    }

    /**
     * Handles the missing ServletRequestBindingException (missing param, header
     * etc) and wraps it in a ErrorResponseObject.
     * 
     * @param ex     the exception
     * @param status the selected response status
     * 
     * @return ResponseEntity response with the ErrorResponseObject indicating
     *         missing param
     */
    private ResponseEntity<Object> createMissingParameterResponse(ServletRequestBindingException ex,
            HttpStatus status) {
        ErrorCode error = errorCodes.getError(CommonErrorCodes.MISSING_PARAMS);

        if (null == error) {
            // for now, if there's no error code defined then default to the uppercase of
            // the code key. This allows us to not have to have this defined in all apps,
            // and really we should only have the one code for all validation errors and
            // the message explicitly describe the issue
            error = new ErrorCode(CommonErrorCodes.MISSING_PARAMS.toUpperCase(), "");
        }

        ErrorResponseObject errorResponseObject = new ErrorResponseObject(error.getCode(), ex.getLocalizedMessage(),
                Priority.HIGH,
                HttpStatus.BAD_REQUEST);

        ErrorResponse response = this.addTraceAndWrap(errorResponseObject);

        return new ResponseEntity<>(response, status);
    }
}
