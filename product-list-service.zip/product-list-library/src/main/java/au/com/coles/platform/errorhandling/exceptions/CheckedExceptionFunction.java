package au.com.coles.platform.errorhandling.exceptions;

@FunctionalInterface
public interface CheckedExceptionFunction<T,R> {
    R apply(T t) throws Exception;
}