package au.com.coles.platform.util;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.joda.time.LocalDateTime;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

import au.com.coles.platform.errorhandling.CommonErrorCodes;
import au.com.coles.platform.errorhandling.exceptions.ExpectedApplicationException;

public class CustomLocalDateTimeDeserializer extends JsonDeserializer<LocalDateTime> {
    
    private SimpleDateFormat formatter = new SimpleDateFormat(CommonConsts.DATE_TIME_FORMAT);
    
    @Override
    public LocalDateTime deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        String date = p.getText();
        try {
            return LocalDateTime.fromDateFields(formatter.parse(date));
        } catch (ParseException e) {
            throw new ExpectedApplicationException(CommonErrorCodes.DATE_DESERIALIZER);
        }
    }
}
