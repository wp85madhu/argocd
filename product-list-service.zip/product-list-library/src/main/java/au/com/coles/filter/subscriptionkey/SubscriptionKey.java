package au.com.coles.filter.subscriptionkey;

/**
 * Represents a Subscription Key, basically holds the key and
 * active status i.e a key whose status active status is false
 * should not be used i.e has been used in a previous attempt and
 * failed security check.
 */
class SubscriptionKey {

	/**
	 * Subscription key value
	 */
	private String key;
	
	/**
	 * Active status of the key active aka good = true.
	 */
	private boolean active;
	

	/**
	 * Creates the SubscriptionKey with active defaulted to true.
	 * 
	 * @param key Subscription Key
	 */
	public SubscriptionKey(String key) {
		this(key, true);
	}
	
	/**
	 * Creates the SubscriptionKey with the active status given.
	 * 
	 * @param key Subscription Key
	 * @param active active status, true = active/good
	 */
	public SubscriptionKey(String key, boolean active) {
		super();
		
		this.key = key;
		this.active = active;
	}
	
	public String getKey() {
		return key;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}
 }
