package au.com.coles.platform.errorhandling.exceptions;

import au.com.coles.platform.errorhandling.ErrorHandlingConstants;
import org.springframework.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

public class PayloadValidationException extends ApplicationException{

    private Map<String, String> properties = new HashMap<>();

    public PayloadValidationException(String errorCodeProperty) {
        super(errorCodeProperty);
    }

    public PayloadValidationException(String errorCodeProperty, HttpStatus httpStatus) {
        super(errorCodeProperty, httpStatus);
    }

    public PayloadValidationException(String errorCodeProperty, ErrorHandlingConstants.Priority priority) {
        super(errorCodeProperty, priority);
    }

    public PayloadValidationException(String errorCodeProperty, ErrorHandlingConstants.Priority priority, HttpStatus httpStatus) {
        super(errorCodeProperty, priority, httpStatus);
    }

    public PayloadValidationException(String errorCodeProperty, Throwable t) {
        super(errorCodeProperty, t);
    }

    public PayloadValidationException(String errorCodeProperty, ErrorHandlingConstants.Priority priority, Throwable t) {
        super(errorCodeProperty, priority, t);
    }

    public PayloadValidationException(String errorCodeProperty, ErrorHandlingConstants.Priority priority, Throwable t,
                                        HttpStatus httpStatus) {
        super(errorCodeProperty, priority, t, httpStatus);
    }

    @Override
    public Map<String, String> getProperties() {
        return properties;
    }

    public void addProperty(String key, String value) {
        this.properties.put(key, value);
    }

}
