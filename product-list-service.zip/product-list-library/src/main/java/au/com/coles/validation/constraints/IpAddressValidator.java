package au.com.coles.validation.constraints;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.google.common.net.InetAddresses;

public class IpAddressValidator implements ConstraintValidator<IpAddress, String> {

    @Override
    public boolean isValid(final String object, final ConstraintValidatorContext constraintContext) {
        if (InetAddresses.isInetAddress(object)) {
            return true;
        }
        return false;
    }
}
