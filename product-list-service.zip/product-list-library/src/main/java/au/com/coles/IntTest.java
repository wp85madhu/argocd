package au.com.coles;

public interface IntTest {
    
}
