package au.com.coles.platform.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import brave.Tracer;

/**
 * Autowire me to get the current thread's trace Id
 * 
 * @author kbratzel
 *
 */
@Component
public class TraceUtil {

    @Autowired
    private Tracer tracer;

    public String getTraceId() {
        if (null == this.tracer || null == this.tracer.currentSpan() || null == this.tracer.currentSpan().context()) {
            return "";
        }
        return this.tracer.currentSpan().context().traceIdString();
    }

}
