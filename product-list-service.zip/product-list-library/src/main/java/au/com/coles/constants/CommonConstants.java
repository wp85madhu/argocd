package au.com.coles.constants;

public class CommonConstants {
    
    private CommonConstants() {
        // Constants class
    }

    public static final String CACHE_CONTROL_HEADER = "Cache-Control";
    public static final String CACHE_HEADER_MAX_AGE = "max-age=";
    
    public static final String SENSITIVE_FIELDS_HEADER = "X-COLES-SENSITIVE-FIELDS";
    public static final String GEOLOCATION_HEADER = "X-COLES-GEOLOCATION-GROUP-1";
    
}
