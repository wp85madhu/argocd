# Microservices Common

This project implements common functions used in many Coles' microservices APIs.

You don't need to import this project directly. It is a transitive dependency of [microservices parent pom](https://bitbucket/projects/API/repos/microservices-parent-pom)


### JWT Validation

JWT Validation can be enabled automatically be specifying the following properties:

 * ```jwt.enabled``` - Flag turns JWT verification on/off
 * ```jwt.aud``` - Must match that of the JWT aud claim (i.e. Azure AD App URI)
 * ```jwt.iss``` - Must match that of the JWT iss claim (i.e. Azzure AD Tennant ID)
 * ```jwt.jwk-uri``` - URI to fetch the JWK's

The following are optional properties:

 * ```jwk.cache.size``` - JWK cache size, default 5
 * ```jwk.cache.expiry``` - Expiry time (in hrs) of the JWK cache, default 24 hours.
 * ```jwt.filter-pattern``` - Url pattern for applying the filter

A JWT token is valid if:

 * JWT token within Authorization header
 * Audience (aud) claim matches
 * Expiry Date is valid
 * Issuer (iss) claim matches
 * Signature valid


### Request Headers

#### Subscription Keys

Subscription keys will automatically be sent when makingt requests with a RestTemplate bean.

Apim subscription keys can be set using a comma separated string in the property file using *microservice.apim.[platform].subscription.keys* where [platform] = the platform in the URL for the service requiring the key (i.e. digital/merchandise/stores).

If the first key fails it will be marked as stale and the request will be retried with the next key in the array.


### Response Headers

#### Caching

The *Cache-Control: max-age* header is automatically added to every response. The time defaults to 900 seconds but can be overridden in each microservice using the 
```cache.control.header.time``` property.


### Logging

Common logging levels and patterns are defined in *src/main/resources/logback-spring.xml*


### OWASP Dependency Check

The OWASP Dependency Check checks all binary dependencies defined via the project pom.xml for known common security vulnerability.

You can run it in any project using

``mvn dependency-check:check``

You can supress dependencies in *src/main/resources/project-suppression.xml*. This file is copied to each project during the build phase.

You can also add project specific suppress dependencies in *src/main/resources/project-suppression.xml*


### Azure Application Insights

Azure Application Insights with Telemetry which monitors back-end calls made by RestTemplate will be automatically enabled if the *instrumentation-key* is found in applcation.properties.