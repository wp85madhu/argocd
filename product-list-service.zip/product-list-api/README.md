# Introduction 
TODO: Give a short introduction of your project. Let this section explain the objectives or the motivation behind this project. 

# Swagger
Open api is enabled in local only. To get swagger json call

`GET http://127.0.0.1:20004/v2/api-docs`
 ### swagger local URL
`http://localhost:20004/swagger-ui/index.html`

1. Make reasonable names for controller methods since they will be a key in swagger operations.


Below is the code developed for CAP-1218 using WebFlux
* UserListController.java

```
package au.com.coles.productlistapi.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import javax.validation.constraints.NotNull;

@RestController
//@RequestMapping(path = "/me/lists")
public class UserListController {

    @GetMapping(value = "/me/lists", produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<String> getList(@RequestHeader(value = "UserAuthorization", required = true) String userAuthorizationToken, @NotNull @RequestParam(required = true) String type) {

        //Stubbed Data for Testiing only
        String responseBody = "[\n" +
                "  {\n" +
                "    \"listId\": \"string\",\n" +
                "    \"listName\": \"string\",\n" +
                "    \"type\": \"string\",\n" +
                "    \"isPreferred\": true,\n" +
                "    \"lastUpdated\": \"string\"\n" +
                "  }\n" +
                "]";
        return Mono.just(responseBody);
    }

    @GetMapping(value = "/me/test", produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<String> test(@RequestHeader(value = "UserAuthorization", required = true) String userAuthorizationToken, @NotNull @RequestParam(required = true) String type) {
    @GetMapping(value = "/user/test", produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<String> test() {

        //Stubbed Data for Testiing only
        String responseBody = "[\n" +
                "  {\n" +
                "    \"listId\": \"string\",\n" +
                "    \"listName\": \"string\",\n" +
                "    \"type\": \"string\",\n" +
                "    \"isPreferred\": true,\n" +
                "    \"lastUpdated\": \"string\"\n" +
                "  }\n" +
                "]";
        return Mono.just(responseBody);
    }
}
```
* UserListItemController.java
```
package au.com.coles.productlistapi.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import javax.validation.constraints.NotNull;

@RestController
@RequestMapping(path = "/me/lists/")
public class UserListItemController {

    @GetMapping(value = "{listId}/items", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getListItems(@RequestHeader(value = "UserAuthorization", required = true) String userAuthorizationToken, @NotNull @PathVariable(value = "listId", required = true) String listId) {
    public Mono<String> getListItems(@RequestHeader(value = "UserAuthorization", required = true) String userAuthorizationToken, @NotNull @PathVariable(value = "listId", required = true) String listId) {

        //Stubbed Data for Testiing only
        String responseBody = "{\n" +
                "  \"listId\": \""+listId+"\",\n" +
                "  \"items\": [\n" +
                "    {\n" +
                "      \"brandName\": \"string\",\n" +
                "      \"productName\": \"string\",\n" +
                "      \"quantity\": 0,\n" +
                "      \"productId\": \"string\",\n" +
                "      \"averageSize\": 0,\n" +
                "      \"unitOfMeasure\": \"string\",\n" +
                "      \"listItemId\": \"string\",\n" +
                "      \"status\": \"UNCHECKED\",\n" +
                "      \"lastUpdated\": \"string\"\n" +
                "    }\n" +
                "  ]\n" +
                "}";
        return new ResponseEntity<>(responseBody, HttpStatus.OK);
        return Mono.just(responseBody);
    }
}
```
* UserListItemControllerTest
```
package au.com.coles.productlistapi.controller;

import au.com.coles.UnitTest;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.Assert.assertEquals;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class UserListItemControllerTest {

    @InjectMocks
    private UserListItemController controllerUnderTest;

    @Test
    public void getListItems() {
        String userAuthorizationToken = "test_token";
        String listId = "123";
        ResponseEntity<String> jsonResponse = controllerUnderTest.getListItems(userAuthorizationToken, listId);
        assertEquals(jsonResponse.getStatusCode(), HttpStatus.OK);
        String jsonResponse = controllerUnderTest.getListItems(userAuthorizationToken, listId).block();
        assert(!jsonResponse.isEmpty());
    }
}
```
* UserListControllerTest
```
package au.com.coles.productlistapi.controller;

import au.com.coles.UnitTest;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.Assert.assertEquals;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class UserListControllerTest {

    @InjectMocks
    private UserListController controllerUnderTest;

    @Test
    public void getListItems() {
        String userAuthorizationToken = "test_token";
        String type = "SHOPPING_LIST";
        ResponseEntity<String> jsonResponse = controllerUnderTest.getList(userAuthorizationToken, type);
        assertEquals(jsonResponse.getStatusCode(), HttpStatus.OK);
        String jsonResponse = controllerUnderTest.getList(userAuthorizationToken, type).block();
        assert(!jsonResponse.isEmpty());
    }
}
```
* UserAuthorizationFilter
```
package au.com.coles.productlistapi.filter;

import au.com.coles.productlistapi.config.UserAuthProperties;
import com.auth0.jwk.JwkProvider;
import com.auth0.jwk.JwkProviderBuilder;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.Verification;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.maven.wagon.authorization.AuthorizationException;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.RequestPath;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import org.springframework.web.util.pattern.PathPattern;
import org.springframework.web.util.pattern.PathPatternParser;
import reactor.core.publisher.Mono;

import java.net.MalformedURLException;
import java.net.URL;
import java.security.interfaces.RSAPublicKey;
import java.util.ArrayList;
import java.util.List;

import static org.slf4j.LoggerFactory.getLogger;

@Component
public class UserAuthorizationFilter implements WebFilter {
    private static final Logger LOG = getLogger(UserAuthorizationFilter.class.getName());

    static final String AUTH_HEADER = "UserAuthorization";

    /**
     * JWT Prefix, aka all JWT's start off 'Bearer xxxxxx....'
     */
    static final String TOKEN_PREFIX = "Bearer ";

    private final JwkProvider jwkProvider;

    private final String jwtAudience;
    private final String jwtIssuer;
    private final String jwtScope;

    @Autowired
    private UserAuthProperties userAuthProperties;

    List<PathPattern> pathPatternList;

    @Autowired
    public UserAuthorizationFilter(@Value("https://coles-dev.au.auth0.com/") String iss,
                                   @Value("customer-services") String aud,
                                   @Value("read:profile") String scope) throws MalformedURLException {
        this(iss, aud, scope, new JwkProviderBuilder(new URL(iss+".well-known/jwks.json")).build());

        System.out.println("I am in constructor");
    }

    public UserAuthorizationFilter(String iss, String aud, String scope, JwkProvider jwkProvider) {
        this.jwtAudience = aud;
        this.jwtIssuer = iss;
        this.jwtScope = scope;
        this.jwkProvider = jwkProvider;
        PathPattern pathPattern1 = new PathPatternParser()
                .parse("/me/lists");
        PathPattern pathPattern2 = new PathPatternParser().parse("/me/test");
        pathPatternList = new ArrayList<>();
        pathPatternList.add(pathPattern1);
        pathPatternList.add(pathPattern2);
        System.out.println("I am in constructor");
    }

    @Override
    public Mono<Void> filter(ServerWebExchange serverWebExchange, WebFilterChain webFilterChain) {

        RequestPath path = serverWebExchange.getRequest().getPath();

        if (pathPatternList.stream().anyMatch(pathPattern -> pathPattern.matches(path.pathWithinApplication()))) {

            List<String> authHeaders = serverWebExchange.getRequest().getHeaders().get(AUTH_HEADER);
            if (CollectionUtils.isEmpty(authHeaders)) {
                serverWebExchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            }
            String authHeader = authHeaders.get(0);
            System.out.println("authHeader=" + authHeader);

            if (!StringUtils.startsWith(authHeader, TOKEN_PREFIX)) {
                System.out.println("No valid UserAuthorization header in request");
                LOG.debug("No valid UserAuthorization header in request");
                //throw new AuthorizationException("No valid UserAuthorization header in request");
                serverWebExchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                //return Mono.error(new AuthorizationException("No valid UserAuthorization header in request"));
            }

            try {

                serverWebExchange.getResponse().getHeaders().set(
                        "profileId",
                        getProfileId(authHeader.substring(TOKEN_PREFIX.length()))
                );

            } catch (AuthorizationException ae) {
                serverWebExchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            }
        }

        return webFilterChain.filter(serverWebExchange);
    }

    private String getProfileId(String token) throws AuthorizationException {
        String profileId;
        DecodedJWT decodedJWT = JWT.decode(token);

        try {
            RSAPublicKey publicKey = (RSAPublicKey) jwkProvider.get(decodedJWT.getKeyId()).getPublicKey();
            Algorithm algorithm = Algorithm.RSA256(publicKey, null);

            Verification verification = JWT.require(algorithm);

            verification.withAudience(jwtAudience);
            verification.withIssuer(jwtIssuer);
            if (!decodedJWT.getClaim("scope").asString().contains(jwtScope)) {
                throw new AuthorizationException("Invalid UserAuthorization header");
            }

            verification.build().verify(token);

            profileId = decodedJWT.getClaim("https://ccp/profileId").asString();

        } catch (Exception e) {
            throw new AuthorizationException("Invalid UserAuthorization header", e);
        }

        return profileId;
    }
}
```
