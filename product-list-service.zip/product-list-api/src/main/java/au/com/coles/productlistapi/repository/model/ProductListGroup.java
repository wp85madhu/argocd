package au.com.coles.productlistapi.repository.model;

import com.azure.spring.data.cosmos.core.mapping.Container;
import com.azure.spring.data.cosmos.core.mapping.PartitionKey;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Container(containerName = "productlist", autoCreateContainer = false)
public class ProductListGroup {

    @Id @PartitionKey
    private String profileId;
    private List<ProductList> productLists;
    @Version
    private String _etag;
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder(toBuilder = true)
    public static class ProductList {
        private String listId;
        private ProductListType type;
        @JsonDeserialize(using = LocalDateTimeDeserializer.class)
        private LocalDateTime created;
        @JsonDeserialize(using = LocalDateTimeDeserializer.class)
        private LocalDateTime lastUpdated;
        private boolean isPreferred;
        private String permissions;
        private String createdBy;
        private boolean disabled;
        private String colour;

    }
}
