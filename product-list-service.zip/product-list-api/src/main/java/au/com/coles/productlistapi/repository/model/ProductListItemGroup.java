package au.com.coles.productlistapi.repository.model;

import com.azure.spring.data.cosmos.core.mapping.Container;
import com.azure.spring.data.cosmos.core.mapping.PartitionKey;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Container(containerName = "productlistitem", autoCreateContainer = false)
public class ProductListItemGroup {

    @Id @PartitionKey
    private String listId;
    private String listName;
    private ProductListType listType;
    private List<ListItem> listItems;
    @Version
    private String _etag;
    @Data
    @Builder(toBuilder = true)
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ListItem {
        private String listItemId;
        private String brandName;
        private String productName;
        private Integer productId;
        private int averageSize;
        private String unitOfMeasure;
        private int quantity;
        private ProductListItemStatusEnum status;
        private LocalDateTime created;
        private LocalDateTime lastUpdated;

    }
}
