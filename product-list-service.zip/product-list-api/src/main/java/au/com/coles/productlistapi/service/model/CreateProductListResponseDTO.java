package au.com.coles.productlistapi.service.model;

import au.com.coles.productlistapi.repository.model.ProductListType;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder(toBuilder = true)
public class CreateProductListResponseDTO {

    private String listId;
    private String listName;
    private ProductListType type;
    @JsonProperty("isPreferred")
    private boolean isPreferred;
    private String lastUpdated;

    @JsonInclude(Include.NON_EMPTY)
    private String colour;
    @JsonProperty("isDisabled")
    private boolean isDisabled;

}
