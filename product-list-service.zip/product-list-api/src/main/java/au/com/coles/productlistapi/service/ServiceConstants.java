package au.com.coles.productlistapi.service;

import au.com.coles.productlistapi.exception.FailedRetryAttemptException;
import com.azure.spring.data.cosmos.exception.CosmosAccessException;
import org.slf4j.Logger;
import reactor.util.retry.Retry;
import reactor.util.retry.RetryBackoffSpec;

import java.time.Duration;
import java.time.temporal.ChronoUnit;

public class ServiceConstants {
    public static RetryBackoffSpec retry(Logger log) {
        return Retry.backoff(3, Duration.of(15, ChronoUnit.MILLIS))
                .doBeforeRetry(retrySignal -> {
                    if (retrySignal.failure() != null) {
                        log.warn("Error during update of document, attempt: #" + (retrySignal.totalRetries() + 1), retrySignal.failure().getCause());
                    }
                })
                .filter(throwable -> throwable instanceof CosmosAccessException)
                .onRetryExhaustedThrow((retryBackoffSpec, retrySignal) -> new FailedRetryAttemptException(" Failed to replay message even after retries"));
    }
}
