package au.com.coles.productlistapi.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("user.auth")
public class UserAuthProperties {

    /**
     * Flag indicates if UserAuth is to be enabled.
     */
    private boolean enabled = false;

    /**
     * URI to fetch the JWK's.
     */
    private String jwkUri;

    /**
     * Iss (issuer) claim that must be matched.
     */
    private String iss;

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getJwkUri() {
        return jwkUri;
    }

    public void setJwkUri(String jwkUri) {
        this.jwkUri = jwkUri;
    }

    public String getIss() {
        return iss;
    }

    public void setIss(String iss) {
        this.iss = iss;
    }
}
