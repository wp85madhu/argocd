package au.com.coles.productlistapi.dto;

import au.com.coles.productlistapi.repository.model.ProductListType;
import au.com.coles.productlistapi.service.model.ProductListItem;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ProductListItemResponse {
    private String listId;
    private String listName;
    private ProductListType listType;
    private List<ProductListItem> items;
}
