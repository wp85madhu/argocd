package au.com.coles.productlistapi.repository;

import au.com.coles.productlistapi.repository.model.ProductListItemGroup;
import com.azure.spring.data.cosmos.repository.ReactiveCosmosRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

import java.util.List;

@Repository
public interface ProductListItemGroupRepository extends ReactiveCosmosRepository<ProductListItemGroup, String> {
    Flux<ProductListItemGroup> findByListIdIn(List<String> listIds);
}