package au.com.coles.productlistapi.config.swagger;

import io.swagger.models.Scheme;
import io.swagger.models.Swagger;
import io.swagger.models.auth.ApiKeyAuthDefinition;
import io.swagger.models.auth.In;
import lombok.Builder;
import lombok.Data;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.swagger2.web.SwaggerTransformationContext;
import springfox.documentation.swagger2.web.WebMvcSwaggerTransformationFilter;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

import static java.util.Arrays.asList;
import static java.util.Collections.singletonList;
import static springfox.documentation.swagger.common.SwaggerPluginSupport.SWAGGER_PLUGIN_ORDER;

@Component
@Order(SWAGGER_PLUGIN_ORDER)
public class OverrideSwagger implements WebMvcSwaggerTransformationFilter {
    /**
     * Base path to be used in APIM
     */
    public static final String BASE_PATH = "/digital/product-list/v1";
    /**
     * Kubernetes base path. Its the same value as in shared/form/service.yaml:name
     */
    public static final String KUBE_BASE_PATH = "product-list-api/";
    public static final String LOCALHOST = "localhost";
    public static final String EMPTY_STRING = "";
    public static final String X_SERVERS = "x-servers";
    public static final String APIM = "APIM";

    @Override
    public Swagger transform(SwaggerTransformationContext<HttpServletRequest> context) {

        var swagger = context.getSpecification()
                .basePath(getBasePath(context.getSpecification().getHost()))
                .schemes(singletonList(getSchema(context.getSpecification().getHost())));
        var securityDefinitions = new ApiKeyAuthDefinition("Ocp-Apim-Subscription-Key", In.HEADER);
        securityDefinitions.setDescription("The APIM subscription key");
        swagger.vendorExtension("x-servers", asList(
                XServerObject.builder().url("https://dev2apigw.cmltd.net.au").description("dev").build(),
                XServerObject.builder().url("https://test2apigw.cmltd.net.au").description("test").build(),
                XServerObject.builder().url("https://svt2apigw.cmltd.net.au").description("svt").build(),
                XServerObject.builder().url("https://prodapigw.cmltd.net.au").description("prod").build()
        ))
                .host(EMPTY_STRING)
                .securityDefinition(APIM, securityDefinitions);
        var paths = swagger.getPaths();
        for (var path : paths.values()) {
            if (path.getGet() != null) {
                path.getGet().setVendorExtension(X_SERVERS, getXServers(KUBE_BASE_PATH));
            }
            if (path.getPost() != null) {
                path.getPost().setVendorExtension(X_SERVERS, getXServers(KUBE_BASE_PATH));
            }
            if (path.getPatch() != null) {
                path.getPatch().setVendorExtension(X_SERVERS, getXServers(KUBE_BASE_PATH));
            }
            if (path.getDelete() != null) {
                path.getDelete().setVendorExtension(X_SERVERS, getXServers(KUBE_BASE_PATH));
            }
        }
        return swagger;
    }

    private String getBasePath(String host) {
        if (host!= null && host.contains(LOCALHOST)) {
            return EMPTY_STRING;
        }

        return BASE_PATH;
    }

    private Scheme getSchema(String host) {
        if (host!= null && host.contains(LOCALHOST)) {
            return Scheme.HTTP;
        }
        return Scheme.HTTPS;

    }

    private List<XServerObject> getXServers(String basePath) {
        return asList(
                XServerObject.builder().url("https://csrv.dev.k8s.dgxp.aue.azr.cmltd.net.au/" + basePath).description("dev").build(),
                XServerObject.builder().url("https://csrv.sit.k8s.dgxp.aue.azr.cmltd.net.au/" + basePath).description("test").build(),
                XServerObject.builder().url("https://csrv.svt.k8s.dgxp.aue.azr.cmltd.net.au/" + basePath).description("svt").build(),
                XServerObject.builder().url("https://csrv.prod.k8s.dgxp.aue.azr.cmltd.net.au/" + basePath).description("prod").build()
        );
    }

    @Override
    public boolean supports(DocumentationType documentationType) {
        return DocumentationType.SWAGGER_2.equals(documentationType);
    }

    @Builder(toBuilder = true)
    @Data
    public static class XServerObject {
        private String url;
        private String description;
    }
}