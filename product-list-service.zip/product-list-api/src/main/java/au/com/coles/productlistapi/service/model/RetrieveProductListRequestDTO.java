package au.com.coles.productlistapi.service.model;

import au.com.coles.productlistapi.repository.model.ProductListType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RetrieveProductListRequestDTO {
    private String profileId;
    private ProductListType type;
}
