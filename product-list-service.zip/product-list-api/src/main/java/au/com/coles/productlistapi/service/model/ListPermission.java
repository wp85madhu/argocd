package au.com.coles.productlistapi.service.model;

public enum ListPermission {

    OWNER("owner");

    private String name;

    ListPermission(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
