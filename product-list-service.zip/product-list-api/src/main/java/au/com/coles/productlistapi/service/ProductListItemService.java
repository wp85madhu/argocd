package au.com.coles.productlistapi.service;

import au.com.coles.platform.errorhandling.CommonErrorCodes;
import au.com.coles.platform.errorhandling.ErrorHandlingConstants;
import au.com.coles.platform.errorhandling.exceptions.CheckedExceptionFunction;
import au.com.coles.platform.errorhandling.exceptions.PayloadValidationException;
import au.com.coles.productlistapi.dto.ProductListItemResponse;
import au.com.coles.productlistapi.dto.ProductListResponse;
import au.com.coles.productlistapi.exception.FailedRetryAttemptException;
import au.com.coles.productlistapi.repository.ProductListGroupRepository;
import au.com.coles.productlistapi.repository.ProductListItemGroupRepository;
import au.com.coles.productlistapi.repository.model.ProductListGroup;
import au.com.coles.productlistapi.repository.model.ProductListItemGroup;
import au.com.coles.productlistapi.repository.model.ProductListItemStatusEnum;
import au.com.coles.productlistapi.service.model.*;
import com.azure.cosmos.models.PartitionKey;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.maven.shared.utils.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;
import reactor.util.function.Tuple3;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@Slf4j
public class ProductListItemService {
    public static final String NAME = "name";
    public static final String PARAM_NAMES = "colour,disable,listname";
    public static final String VALUE = "value";
    public static final String PARAM_VALUES = "null";

    private ProductListGroupRepository listGroupRepo;
    private ProductListItemGroupRepository itemGroupRepo;

    @Autowired
    public ProductListItemService(ProductListItemGroupRepository itemGroupRepo,
                                  ProductListGroupRepository listGroupRepo) {
        this.itemGroupRepo = itemGroupRepo;
        this.listGroupRepo = listGroupRepo;
    }

    public Mono<ProductListItemResponse> getProductListItems(String profileId, String listId) {
        return Mono.zip(listGroupRepo.findById(profileId), itemGroupRepo.findById(listId))
                .flatMap(ProductListItemService::createProductListItemResponse);
    }

    private static Integer convInteger(Integer input) {
        if (input != null && input == 0)
            return null;
        return input;
    }

    private static Mono<ProductListItemResponse> createProductListItemResponse(@NotNull Tuple2<ProductListGroup, ProductListItemGroup> objects) {
        ProductListGroup productList = objects.getT1();
        ProductListItemGroup productListItemGroup = objects.getT2();
        boolean hasPermissions = productList.getProductLists()
                .stream()
                .anyMatch(pl -> (pl.getListId().equals(productListItemGroup.getListId())));

        if (hasPermissions) {
            List<ProductListItem> listItems = productListItemGroup.getListItems()
                    .stream()
                    .map(listItem -> ProductListItem
                            .builder()
                            .brandName(listItem.getBrandName())
                            .averageSize(listItem.getAverageSize())
                            .lastUpdated(listItem.getLastUpdated())
                            .productId((convInteger(listItem.getProductId())))
                            .productName(listItem.getProductName())
                            .quantity(listItem.getQuantity())
                            .status(listItem.getStatus())
                            .unitOfMeasure(listItem.getUnitOfMeasure())
                            .listItemId(listItem.getListItemId())
                            .build())
                    .collect(Collectors.toList());
            return Mono.just(ProductListItemResponse.builder()
                    .listId(productListItemGroup.getListId())
                    .listType(productListItemGroup.getListType())
                    .listName(productListItemGroup.getListName())
                    .items(listItems)
                    .build());
        } else {
            return Mono.empty();
        }
    }

    private @NotNull Mono<ProductListItemGroup> mergeSaveItems(@NotNull Tuple3<ProductListGroup,ProductListItemGroup, List<CreateProductListItemRequest>> data) {
        ProductListGroup productListGroup = data.getT1();
        ProductListItemGroup itemGroup = data.getT2();
        List<CreateProductListItemRequest> request = data.getT3();
        var response = getListIdForProfileId(productListGroup, itemGroup)
                .map(e -> {
                    itemGroup.setListItems(Stream.concat(itemGroup.getListItems().stream(),
                            request.stream().map(item ->
                                    ProductListItemGroup.ListItem.builder()
                                            .listItemId(UUID.randomUUID().toString())
                                            .brandName(item.getBrandName())
                                            .productName(item.getProductName())
                                            .productId(convInteger(item.getProductId()))
                                            .averageSize(item.getAverageSize())
                                            .unitOfMeasure(item.getUnitOfMeasure())
                                            .quantity(item.getQuantity())
                                            .status(item.getStatus() != null ? item.getStatus() : ProductListItemStatusEnum.UNCHECKED)
                                            .created(LocalDateTime.now())
                                            .lastUpdated(LocalDateTime.now())
                                            .build())
                    ).collect(Collectors.toList()));
                    Mono<ProductListItemGroup> value = itemGroupRepo.save(itemGroup);
                    e.setLastUpdated(LocalDateTime.now());
                    listGroupRepo.save(productListGroup).subscribe();
                    return value;
                });
        return response.get();
    }

    @NotNull
    private Optional<ProductListGroup.ProductList> getListIdForProfileId(@NotNull ProductListGroup productListGroup, ProductListItemGroup itemGroup) {
        return productListGroup.getProductLists().stream().filter(pl -> (pl.getListId().equals(itemGroup.getListId())))
                .findFirst();
    }

    public Mono<List<ProductListItemGroup.ListItem>> addProductsToShoppingList(String profileId, String listId, List<CreateProductListItemRequest> addToList) {
        return Mono
                .defer(() -> Mono.zip(listGroupRepo.findById(profileId), itemGroupRepo.findById(listId), Mono.just(addToList))
                        .flatMap(this::mergeSaveItems))
                .retryWhen(ServiceConstants.retry(log))
                .map(ProductListItemGroup::getListItems);
    }

    private @NotNull Mono<List<ProductListItemGroup.ListItem>> overwriteSaveItems(@NotNull Tuple3<ProductListGroup, ProductListItemGroup, List<UpdateProductListItemRequest>> data) {
        ProductListGroup productListGroup = data.getT1();
        ProductListItemGroup itemGroup = data.getT2();
        List<UpdateProductListItemRequest> request = data.getT3();

        var response = getListIdForProfileId(productListGroup, itemGroup)
                .map(e -> {
                    AtomicBoolean itemUpdated = new AtomicBoolean(false);
                    Map<String, UpdateProductListItemRequest> itemMap = request.stream()
                            .collect(Collectors.toMap(UpdateProductListItemRequest::getListItemId, item -> item));
                    itemGroup.getListItems().forEach(oldItem -> {
                        UpdateProductListItemRequest newItem = itemMap.get(oldItem.getListItemId());
                        if (newItem != null) {
                            if (newItem.getQuantity() != oldItem.getQuantity())
                                oldItem.setQuantity(newItem.getQuantity());
                            if (newItem.getStatus() != null) oldItem.setStatus(newItem.getStatus());
                            oldItem.setLastUpdated(LocalDateTime.now());
                            itemUpdated.set(true);
                        }
                    });
                    Mono<List<ProductListItemGroup.ListItem>> mono = Mono.empty();
                    if (itemUpdated.get()) {
                        e.setLastUpdated(LocalDateTime.now());
                        listGroupRepo.save(productListGroup).subscribe();
                        mono = itemGroupRepo.save(itemGroup)
                                .map(saved -> saved.getListItems().stream()
                                        .filter(savedItem -> itemMap.containsKey(savedItem.getListItemId()))
                                        .collect(Collectors.toList()));
                    }
                    return mono;
                });
        return response.get();
    }

    public Mono<List<ProductListItemGroup.ListItem>> updateProductListItem(String profileId, String listId, List<UpdateProductListItemRequest> updateToList) {
        return Mono
                .defer(() -> Mono.zip(listGroupRepo.findById(profileId), itemGroupRepo.findById(listId), Mono.just(updateToList))
                        .flatMap(this::overwriteSaveItems))
                .retryWhen(ServiceConstants.retry(log));
    }

    public Mono<ProductListResponse> updateProductListItemGroup(String profileId, String listId, UpdateProductList updateProductList) {
        return Mono
                .defer(() -> Mono.zip(listGroupRepo.findById(profileId), itemGroupRepo.findById(listId), Mono.just(updateProductList))
                        .flatMap(wrap(this::overwriteProductItemGroup)))
                .retryWhen(ServiceConstants.retry(log))
                .doOnError(FailedRetryAttemptException.class,
                        (msg) -> log.error("Failed to save message even after retries to Failed Message Table for profileId"
                                + profileId + " and list id " + listId
                                + "message is : " + msg.getMessage()));
    }

    private Mono<ProductListResponse> overwriteProductItemGroup(@NotNull Tuple3<ProductListGroup, ProductListItemGroup, UpdateProductList> data) throws PayloadValidationException {
        ProductListGroup listGroup = data.getT1();

        var itemGroup = data.getT2();
        var color = data.getT3().getColour();
        var disable = data.getT3().getDisable();
        var listName = data.getT3().getListName();
        Optional<ProductListGroup.ProductList> productListToUpdate = Optional.empty();
        if (StringUtils.isEmpty(color) && ObjectUtils.isEmpty(disable)  && StringUtils.isEmpty(listName)) {
            buildErrorResponse();
        }else{
            productListToUpdate = getListIdForProfileId(listGroup, itemGroup);
            productListToUpdate.map(m -> {
                        var mono = Mono.empty();
                        if (StringUtils.isNotEmpty(color)) {
                            m.setColour(color);
                            m.setLastUpdated(LocalDateTime.now());
                        }
                        if (null != disable) {
                            m.setDisabled(disable);
                            m.setLastUpdated(LocalDateTime.now());
                        }
                        if (StringUtils.isNotEmpty(listName)) {
                            itemGroup.setListName(listName);
                            m.setLastUpdated(LocalDateTime.now());
                            mono = Mono.just(Objects.requireNonNull(itemGroupRepo.save(itemGroup).subscribe())).map(r -> true);
                        }
                mono = Mono.just(listGroupRepo.save(listGroup).subscribe()).map(r->true);
                return mono;
            });


        }
        return getProductListResponse(data.getT2(), productListToUpdate);
    }

    private void buildErrorResponse() {
        PayloadValidationException payloadValidationException =  new PayloadValidationException(CommonErrorCodes.ALL_NULL_PARAMS, ErrorHandlingConstants.Priority.HIGH, HttpStatus.BAD_REQUEST);
        payloadValidationException.addProperty(NAME, PARAM_NAMES);
        payloadValidationException.addProperty(VALUE,PARAM_VALUES);
        throw payloadValidationException;
    }

    public Mono<Boolean> deleteProductListItems(String profileId, String listId, ProductListItemDeleteRequest request) {
        return Mono
                .defer(() -> Mono.zip(listGroupRepo.findById(profileId), itemGroupRepo.findById(listId), Mono.just(request))
                        .flatMap(this::deleteListItemsAndSave))
                .retryWhen(ServiceConstants.retry(log));

    }

    private @NotNull Mono<Boolean> deleteListItemsAndSave(@NotNull Tuple3<ProductListGroup, ProductListItemGroup, ProductListItemDeleteRequest> objects) {
        ProductListGroup productList = objects.getT1();
        ProductListItemGroup productListItemGroup = objects.getT2();
        ProductListItemDeleteRequest request = objects.getT3();
        var response = getListIdForProfileId(productList, productListItemGroup)
                .map(list -> {
                    var re = productListItemGroup.getListItems()
                            .removeIf(listItem -> request.getListItemId().contains(listItem.getListItemId()));
                    if (re) {
                        list.setLastUpdated(LocalDateTime.now());
                    }
                    return re;
                }).map(value -> {
                    if (value) {
                        itemGroupRepo.save(productListItemGroup).subscribe();
                        listGroupRepo.save(productList).subscribe();
                    }
                    return value;
                });
        return Mono.just(response.get());
    }

    public Mono<Boolean> deleteProductListGroup(String profileId) {
        return Mono.defer(() -> listGroupRepo.findById(profileId).flatMap(this::deleteAllProductLists))
                .retryWhen(ServiceConstants.retry(log));
    }

    private @NotNull Mono<Boolean> deleteAllProductLists(@NotNull ProductListGroup listGroup) {
        /// delete all item groups (and all the items in them) and the parent list group
        return Flux.fromIterable(listGroup.getProductLists())
                .flatMap(productList -> itemGroupRepo.deleteById(productList.getListId(), new PartitionKey(productList.getListId())))
                .concatWith(listGroupRepo.delete(listGroup))
                .all(productList -> true);
    }

    public static <T,R> Function<T,R> wrap(CheckedExceptionFunction<T,R> checkedExceptionFunction) {
        return t -> {
            try {
                return checkedExceptionFunction.apply(t);
            }catch (PayloadValidationException payloadValidationException){
                throw payloadValidationException;
            }
            catch (Exception e) {
                throw new RuntimeException(e);
            }
        };
    }

    private Mono<ProductListResponse> getProductListResponse(ProductListItemGroup productListItemGroup, Optional<ProductListGroup.ProductList> updatedProductList) {
        if (updatedProductList.isPresent()) {
            ProductListGroup.ProductList list = updatedProductList.get();
            return Mono.just(ProductListResponse.builder()
                    .listId(list.getListId())
                    .listName(productListItemGroup.getListName())
                    .isPreferred(list.isPreferred())
                    .isDisabled(list.isDisabled())
                    .colour(list.getColour())
                    .type(productListItemGroup.getListType())
                    .lastUpdated(list.getLastUpdated())
                    .build());
        }
        return Mono.just(ProductListResponse.builder().build());

    }
}