package au.com.coles.productlistapi.interceptor;

import au.com.coles.productlistapi.annotation.AllowedScope;
import au.com.coles.productlistapi.config.UserAuthProperties;
import au.com.coles.productlistapi.exception.UserAuthException;
import com.auth0.jwk.JwkException;
import com.auth0.jwk.JwkProvider;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.Verification;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.security.interfaces.RSAPublicKey;

import static org.slf4j.LoggerFactory.getLogger;

public class UserAuthorizationInterceptor implements HandlerInterceptor {
    private static final Logger LOG = getLogger(UserAuthorizationInterceptor.class.getName());

    @Autowired
    private UserAuthProperties userAuthProperties;

    static final String AUTH_HEADER = "UserAuthorization";

    /**
     * JWT Prefix, aka all JWT's start off 'Bearer xxxxxx....'
     */
    static final String TOKEN_PREFIX = "Bearer ";

    @Autowired
    @Qualifier("userJwkProvider")
    private JwkProvider jwkProvider;

    private static final String jwtAudience = "customer-services";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        try {
            HandlerMethod hm = (HandlerMethod) handler;
            Method method = hm.getMethod();

            AllowedScope allowedScope = method.getAnnotation(AllowedScope.class);

            if(allowedScope != null) {

                String authHeader = request.getHeader(AUTH_HEADER);

                if (!StringUtils.startsWith(authHeader, TOKEN_PREFIX)) {
                    LOG.error("No valid UserAuthorization header in request");
                    response.sendError(HttpStatus.UNAUTHORIZED.value());
                    return false;
                }
                String profileId = getProfileId(authHeader.substring(TOKEN_PREFIX.length()), allowedScope.value());
                request.setAttribute("profileId", profileId);

            }

        } catch (UserAuthException | JwkException e) {
            LOG.warn("UserAuthorization validation failed: "+e.getMessage());
            response.sendError(HttpStatus.UNAUTHORIZED.value());
            return false;
        } catch (Exception e) {
            LOG.error("UserAuthorization unexpected error: ", e);
            response.sendError(HttpStatus.UNAUTHORIZED.value());
            return false;
        }
        return true;
    }

    private String getProfileId(String token, String jwtScope) throws UserAuthException, JwkException {
        String profileId;
        final String jwtIssuer = userAuthProperties.getIss();

        DecodedJWT decodedJWT = JWT.decode(token);
        if(!decodedJWT.getIssuer().equalsIgnoreCase(jwtIssuer) || !decodedJWT.getAudience().contains(jwtAudience)) {
            LOG.error("UserAuthorization has invalid issuer {} or audience {}", decodedJWT.getIssuer(), String.join(", ", decodedJWT.getAudience()));
            throw new UserAuthException("Invalid JWT issuer or audience");
        }


        RSAPublicKey publicKey = (RSAPublicKey) jwkProvider.get(decodedJWT.getKeyId()).getPublicKey();
        Algorithm algorithm = Algorithm.RSA256(publicKey, null);

        Verification verification = JWT.require(algorithm);

        verification.withAudience(jwtAudience);
        verification.withIssuer(jwtIssuer);
        if (!decodedJWT.getClaim("scope").asString().contains(jwtScope)) {
            throw new UserAuthException("Invalid JWT scope");
        }

        try {
            verification.build().verify(token);
        } catch (JWTVerificationException e) {
            throw new UserAuthException("Invalid JWT token: " + e.getMessage());
        }

        profileId = decodedJWT.getClaim("https://ccp/profileId").asString();
        return profileId;
    }

}
