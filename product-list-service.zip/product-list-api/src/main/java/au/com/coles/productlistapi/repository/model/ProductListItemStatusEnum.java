package au.com.coles.productlistapi.repository.model;

public enum ProductListItemStatusEnum {
    UNCHECKED, CHECKED
}
