package au.com.coles.productlistapi.dto;

import au.com.coles.productlistapi.repository.model.ProductListType;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ProductListResponse {
    private String listId;
    private String listName;
    private ProductListType type;
    private LocalDateTime lastUpdated;
    private boolean isPreferred;

    @JsonProperty("isDisabled")
    private boolean isDisabled;

    @JsonInclude(Include.NON_EMPTY)
    private String colour;
}
