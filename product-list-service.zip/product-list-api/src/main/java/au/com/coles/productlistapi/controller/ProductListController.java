package au.com.coles.productlistapi.controller;

import au.com.coles.productlistapi.annotation.AllowedScope;
import au.com.coles.productlistapi.dto.ProductListItemResponse;
import au.com.coles.productlistapi.dto.ProductListResponse;
import au.com.coles.productlistapi.repository.model.ProductListItemGroup;
import au.com.coles.productlistapi.repository.model.ProductListType;
import au.com.coles.productlistapi.service.ProductListCreationService;
import au.com.coles.productlistapi.service.ProductListItemService;
import au.com.coles.productlistapi.service.ProductListService;
import au.com.coles.productlistapi.service.model.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import springfox.documentation.annotations.ApiIgnore;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@Api(tags = "Product lists")
@RestController
@RequestMapping("/me/lists")
@Slf4j
public class ProductListController {

    private ProductListService productListService;
    private ProductListCreationService productListCreationService;
    private ProductListItemService productListItemService;

    @Autowired
    public ProductListController(ProductListService productListService, ProductListItemService productListItemService, ProductListCreationService productListCreationService) {
        this.productListService = productListService;
        this.productListItemService = productListItemService;
        this.productListCreationService = productListCreationService;
    }

    @ApiOperation(value = "Return product lists of requested type", nickname = "getProductLists")
    @AllowedScope("read:product-list")
    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<List<RetrieveProductListResponseDTO>> getProductList(
            @ApiParam(
                    name = "type",
                    value = "One of [SHOPPING_LIST, WATCH_LIST]",
                    example = "SHOPPING_LIST",
                    type = "String",
                    required = true)
            @NotNull @RequestParam String type,
            @ApiIgnore @NotNull @RequestAttribute String profileId) {
        RetrieveProductListRequestDTO retrieveProductListRequestDTO =
                RetrieveProductListRequestDTO.builder().profileId(profileId).type(ProductListType.valueOf(type)).build();
        return productListService.getProductList(retrieveProductListRequestDTO);
    }

    @ApiOperation(value = "Return product list", nickname = "getProductList")
    @AllowedScope("read:product-list")
    @GetMapping(path = "{listId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<ResponseEntity<ProductListResponse>> getList(
            @ApiParam(
                    name = "listId",
                    value = "Unique List Id",
                    example = "08128d8f-d60c-40d3-a1d9-214c8daee974",
                    type = "String",
                    required = true)
            @NotNull @PathVariable String listId,
            @ApiIgnore @NotNull @RequestAttribute String profileId) {
        return productListService.getProductList(profileId, listId)
                .map(list -> new ResponseEntity<>(list, HttpStatus.OK))
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    @ApiOperation(value = "Return product list", nickname = "updateProductList")
    @AllowedScope("update:product-list")
    @PatchMapping(path = "{listId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<ResponseEntity<ProductListResponse>> updateProductList(
            @ApiParam(
                    name = "listId",
                    value = "Unique List Id",
                    example = "08128d8f-d60c-40d3-a1d9-214c8daee974",
                    type = "String",
                    required = true)
            @NotNull @PathVariable String listId,
            @ApiIgnore @NotNull @RequestAttribute String profileId,
            @NotNull @Valid @RequestBody UpdateProductList updateProductList) {
        return productListItemService.updateProductListItemGroup(profileId, listId, updateProductList)
                .map(list -> new ResponseEntity<>(list, HttpStatus.OK))
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    @ApiOperation(value = "Create product list", nickname = "createProductList")
    @AllowedScope("update:product-list")
    @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<ResponseEntity<CreateProductListResponseDTO>> createProductList(@ApiParam(name = "UserAuthorization", required = true)
                                                                                @ApiIgnore @NotNull @RequestAttribute String profileId,
                                                                                @Valid @RequestBody CreateProductListRequestDTO requestDTO) {
        return this.productListCreationService.createList(profileId, requestDTO)
                .map(responseDto -> new ResponseEntity<>(responseDto, HttpStatus.CREATED));
    }

    @ApiOperation(value = "Return list items", nickname = "getProductListItems")
    @AllowedScope("read:product-list")
    @GetMapping(path = "{listId}/items", produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<ResponseEntity<ProductListItemResponse>> getListItems(
            @ApiParam(
                    name = "listId",
                    value = "Unique List Id",
                    example = "08128d8f-d60c-40d3-a1d9-214c8daee974",
                    type = "String",
                    required = true)
            @NotNull @PathVariable String listId,
            @ApiIgnore @NotNull @RequestAttribute String profileId) {
        return productListItemService.getProductListItems(profileId, listId)
                .map(list -> new ResponseEntity<>(list, HttpStatus.OK))
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    @ApiOperation(value = "Add product list item", nickname = "addProductListItem")
    @AllowedScope("update:product-list")
    @PostMapping(path = "{listId}/items", produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<ResponseEntity<List<ProductListItemGroup.ListItem>>> addProductListItem(
            @ApiParam(
                    name = "listId",
                    value = "Unique List Id",
                    example = "08128d8f-d60c-40d3-a1d9-214c8daee974",
                    type = "String",
                    required = true)
            @NotNull @PathVariable String listId,
            @ApiIgnore @NotNull @RequestAttribute String profileId,
            @NotNull @Valid @RequestBody List<CreateProductListItemRequest> addProductListItemRequest) {
        return productListItemService.addProductsToShoppingList(profileId, listId, addProductListItemRequest)
                .map(list -> new ResponseEntity<>(list, HttpStatus.OK))
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    @ApiOperation(value = "Update product list item", nickname = "updateProductListItem")
    @AllowedScope("update:product-list")
    @PatchMapping(path = "{listId}/items", produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<ResponseEntity<List<ProductListItemGroup.ListItem>>> updateProductListItem(
            @ApiParam(
                    name = "listId",
                    value = "Unique List Id",
                    example = "08128d8f-d60c-40d3-a1d9-214c8daee974",
                    type = "String",
                    required = true)
            @NotNull @PathVariable String listId,
            @ApiIgnore @NotNull @RequestAttribute String profileId,
            @NotNull @Valid @RequestBody List<UpdateProductListItemRequest> updateProductListItemRequest) {
        return productListItemService.updateProductListItem(profileId, listId, updateProductListItemRequest)
                .map(list -> new ResponseEntity<>(list, HttpStatus.OK));
    }

    @ApiOperation(value = "Delete product list item", nickname = "deleteProductListItem")
    @AllowedScope("update:product-list")
    @DeleteMapping(path = "{listId}/items", produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<ResponseEntity<Boolean>> deleteListItems(
            @ApiParam(
                name = "listId",
                value = "Unique List Id",
                example = "08128d8f-d60c-40d3-a1d9-214c8daee974",
                type = "String",
                required = true)
            @NotNull @PathVariable String listId,
            @ApiIgnore @NotNull @RequestAttribute String profileId,
            @NotNull @Valid @RequestBody ProductListItemDeleteRequest request) {
        return productListItemService.deleteProductListItems(profileId, listId, request)
                .map(list -> new ResponseEntity<>(list, HttpStatus.NO_CONTENT))
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }
}