package au.com.coles.productlistapi.repository.model;

public enum ProductListType {
    SHOPPING_LIST, WATCH_LIST;
}
