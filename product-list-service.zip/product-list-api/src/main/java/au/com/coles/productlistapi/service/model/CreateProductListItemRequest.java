package au.com.coles.productlistapi.service.model;

import au.com.coles.productlistapi.repository.model.ProductListItemStatusEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateProductListItemRequest {
    private String brandName;
    private String productName;
    private int quantity;
    private Integer productId;
    private int averageSize;
    private ProductListItemStatusEnum status;
    private String unitOfMeasure;
}
