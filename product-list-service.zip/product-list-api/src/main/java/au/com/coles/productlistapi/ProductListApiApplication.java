package au.com.coles.productlistapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.couchbase.CouchbaseAutoConfiguration;
import org.springframework.boot.autoconfigure.data.couchbase.CouchbaseDataAutoConfiguration;


@SpringBootApplication(scanBasePackages = {"au.com.coles"},
		exclude = { CouchbaseAutoConfiguration.class, CouchbaseDataAutoConfiguration.class })
public class ProductListApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductListApiApplication.class, args);
	}
}
