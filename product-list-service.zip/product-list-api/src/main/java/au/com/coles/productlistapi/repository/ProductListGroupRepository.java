package au.com.coles.productlistapi.repository;

import au.com.coles.productlistapi.repository.model.ProductListGroup;
import com.azure.spring.data.cosmos.repository.ReactiveCosmosRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductListGroupRepository extends ReactiveCosmosRepository<ProductListGroup, String> {
}
