package au.com.coles.productlistapi.config;

import com.azure.cosmos.CosmosClientBuilder;
import com.azure.cosmos.DirectConnectionConfig;
import com.azure.spring.data.cosmos.config.AbstractCosmosConfiguration;
import com.azure.spring.data.cosmos.config.CosmosConfig;
import com.azure.spring.data.cosmos.repository.config.EnableReactiveCosmosRepositories;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
@EnableReactiveCosmosRepositories(basePackages = "au.com.coles.productlistapi.repository")
public class CosmosDBConfiguration extends AbstractCosmosConfiguration {
    @Value("${azure.cosmosdb.uri}")
    private String uri;

    @Value("${azure.cosmosdb.key}")
    private String key;

    @Getter
    @Value("${azure.cosmosdb.database}")
    private String dbName;

    @Value("${azure.cosmosdb.useproxy:false}")
    private Boolean useProxy;

    @Bean
    public CosmosClientBuilder cosmosClientBuilder() {

        var builder = new CosmosClientBuilder()
                .endpoint(this.uri)
                .key(this.key);
        if (useProxy) {
            builder.gatewayMode();
        } else {
            builder.directMode(DirectConnectionConfig.getDefaultConfig());
        }
        return builder;
    }

    @Bean
    public CosmosConfig cosmosConfig() {
        return CosmosConfig.builder().build();
    }

    @Override
    protected String getDatabaseName() {
        return this.dbName;
    }
}