package au.com.coles.productlistapi.config.swagger;

import com.fasterxml.classmate.TypeResolver;
import java.util.ArrayList;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.ResponseEntity;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.AlternateTypeRules;
import springfox.documentation.schema.WildcardType;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.service.SecurityScheme;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;


@Configuration
@EnableSwagger2
@Profile({"local", "local-sit"})
public class SpringFoxConfig {

    public static final String AUTHORIZATION_TOKEN_LABEL = "Authorization-token";
    public static final String USER_AUTHORIZATION_TOKEN_LABEL = "User-Authorization-token";
    public static final String HEADER = "header";
    public static final String GLOBAL = "global";
    public static final String ACCESS_EVERYTHING = "accessEverything";
    @Autowired
    private TypeResolver resolver;


    private static final String AUTHORIZATION_TOKEN = "Authorization";

    private static final String USER_AUTHORIZATION_TOKEN = "UserAuthorization";

    @Bean
    public Docket api() {
        var docket = new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiInfo())
                .securitySchemes(apiKey())
                .securityContexts(Collections.singletonList(securityContext()))
                .directModelSubstitute(LocalDateTime.class, String.class)
                .directModelSubstitute(LocalDate.class, String.class)
                .directModelSubstitute(LocalTime.class, String.class)
                .directModelSubstitute(ZonedDateTime.class, String.class)
                .select()
                .apis(RequestHandlerSelectors.basePackage("au.com.coles"))
                .paths(PathSelectors.any())

                .build()
                .alternateTypeRules(new RecursiveAlternateTypeRule(resolver,
                        Arrays.asList(AlternateTypeRules.newRule(
                                        resolver.resolve(Mono.class, WildcardType.class),
                                        resolver.resolve(WildcardType.class)),
                                AlternateTypeRules.newRule(
                                        resolver.resolve(ResponseEntity.class, WildcardType.class),
                                        resolver.resolve(WildcardType.class)))))
                .alternateTypeRules(
                        new RecursiveAlternateTypeRule(resolver, Arrays.asList(
                                AlternateTypeRules.newRule(
                                        resolver.resolve(Flux.class, WildcardType.class),
                                        resolver.resolve(List.class, WildcardType.class)),
                                AlternateTypeRules.newRule(
                                        resolver.resolve(ResponseEntity.class, WildcardType.class),
                                        resolver.resolve(WildcardType.class)))));
        return docket;
    }

    private ApiInfo apiInfo() {
        return new ApiInfo("Product List Api",
                "Service which allow customers to save their shopping list preference",
                "1.0",
                Strings.EMPTY,
                null,
                "Coles Authorised Internal Use Only",
                Strings.EMPTY,
                Collections.emptyList());
    }
    private List<SecurityScheme> apiKey() {
        List<SecurityScheme> apiKeys = new ArrayList<>();
        apiKeys.add(new ApiKey(AUTHORIZATION_TOKEN_LABEL, AUTHORIZATION_TOKEN, HEADER));
        apiKeys.add(new ApiKey(USER_AUTHORIZATION_TOKEN_LABEL, USER_AUTHORIZATION_TOKEN, HEADER));
        return apiKeys;
    }
    private SecurityContext securityContext() {
        return SecurityContext.builder()
                .securityReferences(defaultAuth())
                .build();
    }
    private List<SecurityReference> defaultAuth() {
        AuthorizationScope authorizationScope = new AuthorizationScope(GLOBAL,
                ACCESS_EVERYTHING);
        AuthorizationScope[] authorizationScopes = new AuthorizationScope[1];
        authorizationScopes[0] = authorizationScope;
        List tokens = new ArrayList();
        tokens.add(new SecurityReference(AUTHORIZATION_TOKEN_LABEL, authorizationScopes));
        tokens.add(new SecurityReference(USER_AUTHORIZATION_TOKEN_LABEL, authorizationScopes));
        return tokens;
    }
}
