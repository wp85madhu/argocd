package au.com.coles.productlistapi.service.model;

import au.com.coles.productlistapi.repository.model.ProductListItemStatusEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateProductListItemRequest {
    private String listItemId;
    private int quantity;
    private ProductListItemStatusEnum status;
}
