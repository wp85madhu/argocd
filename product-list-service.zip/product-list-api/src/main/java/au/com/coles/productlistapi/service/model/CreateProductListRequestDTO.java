package au.com.coles.productlistapi.service.model;

import au.com.coles.productlistapi.repository.model.ProductListType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.NoArgsConstructor;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class CreateProductListRequestDTO {

    @NotEmpty
    private String listName;

    @NotNull
    private ProductListType type;

    @NotNull
    private boolean isPreferred;

    private String colour;

}
