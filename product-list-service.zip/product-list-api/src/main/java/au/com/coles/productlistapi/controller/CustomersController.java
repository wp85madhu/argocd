package au.com.coles.productlistapi.controller;

import au.com.coles.productlistapi.dto.ProductListItemResponse;
import au.com.coles.productlistapi.repository.model.ProductListItemGroup;
import au.com.coles.productlistapi.service.ProductListItemService;
import au.com.coles.productlistapi.service.ProductListService;
import au.com.coles.productlistapi.service.model.UpdateProductListItemRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@Api(tags = "Customer product lists")
@RestController
@RequestMapping(value = "customers")
public class CustomersController {
    private ProductListItemService productListItemService;
    private ProductListService productListService;

    public CustomersController(ProductListItemService productListItemService, ProductListService productListService) {
        this.productListItemService = productListItemService;
        this.productListService = productListService;
    }

    @ApiOperation(value = "Return customer list items", nickname = "getCustomerListItems")
    @GetMapping(path = "{profileId}/lists/{listId}/items", produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<ResponseEntity<ProductListItemResponse>> getCustomerListItems(@NotNull @PathVariable(value = "listId") String listId,
                                                                              @NotNull @PathVariable(value = "profileId") String profileId) {
        return productListItemService.getProductListItems(profileId, listId)
                .map(list -> new ResponseEntity<>(list, HttpStatus.OK))
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    @ApiOperation(value = "Patch customer list items", nickname = "patchCustomerListItems")
    @PatchMapping(path = "{profileId}/lists/{listId}/items", produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<ResponseEntity<List<ProductListItemGroup.ListItem>>> patchCustomerListItems(@NotNull @PathVariable(value = "listId") String listId,
                                                                                            @NotNull @PathVariable(value = "profileId") String profileId,
                                                                                            @NotNull @Valid @RequestBody List<UpdateProductListItemRequest> updateProductListItemRequest) {
        return productListService.getProductList(profileId, listId)
                .flatMap(v ->
                        productListItemService.updateProductListItem(profileId, listId, updateProductListItemRequest))
                .map(list -> new ResponseEntity<>(list, HttpStatus.OK))
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    @ApiOperation(value = "Delete the product list group and all its content", nickname = "deleteProductListGroup")
    @DeleteMapping(path = "{profileId}/lists", produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<ResponseEntity<Object>> deleteProfileLists(@NotNull @PathVariable(value = "profileId") String profileId) {
        return productListItemService.deleteProductListGroup(profileId)
                .flatMap(result -> Mono.just(result ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build()))
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }
}