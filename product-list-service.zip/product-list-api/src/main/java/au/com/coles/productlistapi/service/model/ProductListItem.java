package au.com.coles.productlistapi.service.model;

import au.com.coles.productlistapi.repository.model.ProductListItemStatusEnum;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductListItem {
    private String brandName;
    private String productName;
    private Integer productId;
    private int averageSize;
    private String unitOfMeasure;
    private String listItemId;
    private int quantity;
    private ProductListItemStatusEnum status;
    private LocalDateTime lastUpdated;
}
