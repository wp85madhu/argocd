package au.com.coles.productlistapi.service;

import au.com.coles.productlistapi.dto.ProductListResponse;
import au.com.coles.productlistapi.repository.ProductListGroupRepository;
import au.com.coles.productlistapi.repository.ProductListItemGroupRepository;
import au.com.coles.productlistapi.repository.model.ProductListGroup;
import au.com.coles.productlistapi.repository.model.ProductListItemGroup;
import au.com.coles.productlistapi.service.model.RetrieveProductListRequestDTO;
import au.com.coles.productlistapi.service.model.RetrieveProductListResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;
import reactor.util.function.Tuple3;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ProductListService {

    private ProductListGroupRepository productListGroupRepository;

    private ProductListItemGroupRepository productListItemGroupRepository;

    @Autowired
    public ProductListService(ProductListGroupRepository productListRepo, ProductListItemGroupRepository productListItemRepo){
        this.productListGroupRepository = productListRepo;
        this.productListItemGroupRepository = productListItemRepo;
    }

    public Mono<ProductListResponse> getProductList(String profileId, String listId) {
        return Mono.zip(productListGroupRepository.findById(profileId), productListItemGroupRepository.findById(listId))
                .flatMap(ProductListService::getProductListResponse);
    }

    private static Mono<ProductListResponse> getProductListResponse(Tuple2<ProductListGroup, ProductListItemGroup> objects) {
        ProductListGroup productList = objects.getT1();
        ProductListItemGroup productListItemGroup = objects.getT2();
        return productList
                .getProductLists()
                .stream()
                .filter(pl -> (pl.getListId().equals(productListItemGroup.getListId())))
                .findFirst()
                .map(m -> Mono.just(ProductListResponse
                        .builder()
                        .listId(productListItemGroup.getListId())
                        .listName(productListItemGroup.getListName())
                        .type(productListItemGroup.getListType())
                        .lastUpdated(m.getLastUpdated())
                        .isPreferred(m.isPreferred())
                        .isDisabled(m.isDisabled())
                        .colour(m.getColour())
                        .build()))
                .orElseGet(Mono::empty);
    }

    private Mono<Tuple3<ProductListGroup, RetrieveProductListRequestDTO, List<ProductListItemGroup>>> retrieveProductLists(Tuple2<ProductListGroup, RetrieveProductListRequestDTO> data){
        List<String> listIds = data.getT1().getProductLists()
                .stream()
                .filter(pl -> pl.getType().equals(data.getT2().getType()))
                .map(pl -> pl.getListId())
                .collect(Collectors.toList());

        return Mono.zip(Mono.just(data.getT1()), Mono.just(data.getT2()),
                listIds.isEmpty() ? Mono.just(new ArrayList<>()) :
                        productListItemGroupRepository.findByListIdIn(listIds).collectList());
    }

    private Mono<List<RetrieveProductListResponseDTO>> buildProductList(Tuple3<ProductListGroup, RetrieveProductListRequestDTO, List<ProductListItemGroup>> data) {
        return Mono.just(data.getT3().stream()
                .map(itemGroup -> {
                    Optional<ProductListGroup.ProductList> productList = data.getT1().getProductLists()
                            .stream()
                            .filter(pl -> pl.getListId().equals(itemGroup.getListId()))
                            .collect(Collectors.reducing((a, b) -> null));

                    return RetrieveProductListResponseDTO.builder()
                            .listId(itemGroup.getListId())
                            .listName(itemGroup.getListName())
                            .type(itemGroup.getListType())
                            .isPreferred(productList.isPresent() ? productList.get().isPreferred() : false)
                            .lastUpdated(productList.isPresent() ? productList.get().getLastUpdated() : null)
                            .colour(productList.isPresent() ? productList.get().getColour(): null)
                            .isDisabled(productList.isPresent() ? productList.get().isDisabled(): false)
                            .build();
                }).collect(Collectors.toList()));
    }

    public Mono<List<RetrieveProductListResponseDTO>> getProductList(RetrieveProductListRequestDTO request) {
        return Mono.zip(productListGroupRepository.findById(request.getProfileId()), Mono.just(request))
                .flatMap(this::retrieveProductLists)
                .flatMap(this::buildProductList)
                .defaultIfEmpty(new ArrayList<>());
    }
}
