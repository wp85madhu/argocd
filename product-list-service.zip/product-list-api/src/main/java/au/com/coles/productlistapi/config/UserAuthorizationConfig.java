package au.com.coles.productlistapi.config;


import au.com.coles.productlistapi.interceptor.UserAuthorizationInterceptor;
import com.auth0.jwk.JwkException;
import com.auth0.jwk.JwkProvider;
import com.auth0.jwk.JwkProviderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.net.MalformedURLException;
import java.net.URL;

@Configuration
@ConditionalOnProperty({ "user.auth.enabled" })
public class UserAuthorizationConfig implements WebMvcConfigurer {

    @Autowired
    private UserAuthProperties userAuthProperties;

    @Bean("userJwkProvider")
    public JwkProvider userJwkProvider() throws MalformedURLException, JwkException {
        JwkProvider jwkProvider = new JwkProviderBuilder(new URL(userAuthProperties.getJwkUri())).build();
        return jwkProvider;
    }

    @Bean
    public UserAuthorizationInterceptor userAuthorizationInterceptor() {
        return new UserAuthorizationInterceptor();
    }

    @Autowired
    private UserAuthorizationInterceptor userAuthorizationInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(userAuthorizationInterceptor).addPathPatterns("/me/**");
    }
}
