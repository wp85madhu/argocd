package au.com.coles.productlistapi.service;

import au.com.coles.productlistapi.repository.ProductListGroupRepository;
import au.com.coles.productlistapi.repository.ProductListItemGroupRepository;
import au.com.coles.productlistapi.repository.model.ProductListGroup;
import au.com.coles.productlistapi.repository.model.ProductListItemGroup;
import au.com.coles.productlistapi.service.model.CreateProductListRequestDTO;
import au.com.coles.productlistapi.service.model.CreateProductListResponseDTO;
import au.com.coles.productlistapi.service.model.ListPermission;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.UUID;

import static java.util.stream.Collectors.toList;

@Service
@Slf4j
public class ProductListCreationService {

    private ProductListGroupRepository productListGroupRepository;

    private ProductListItemGroupRepository productListItemGroupRepository;

    @Autowired
    public ProductListCreationService(ProductListGroupRepository productListGroupRepository, ProductListItemGroupRepository productListItemGroupRepository) {
        this.productListGroupRepository = productListGroupRepository;
        this.productListItemGroupRepository = productListItemGroupRepository;
    }

    public Mono<CreateProductListResponseDTO> createList(String profileId, CreateProductListRequestDTO requestDto) {
        return createProductListItemGroup(requestDto)
                .flatMap(shoppingList -> this.productListItemGroupRepository.save(shoppingList))
                .flatMap(shoppingList -> this.updateProfileWithNewList(shoppingList, profileId, requestDto))
                .flatMap(itemsAndProfile -> createProductListResponseDTO(itemsAndProfile.getT2(), itemsAndProfile.getT1()));
    }

    private Mono<Tuple2<ProductListItemGroup, ProductListGroup>> updateProfileWithNewList(ProductListItemGroup shoppingList, String profileId, CreateProductListRequestDTO requestDto) {
        var readAndUpdateProfile = Mono
                .defer(() ->
                        this.productListGroupRepository.findById(profileId)
                                .defaultIfEmpty(ProductListGroup.builder()
                                        .profileId(profileId)
                                        .productLists(new ArrayList<>())
                                        .build())
                                .flatMap(productListGroup -> {
                                    boolean isTypeExist = productListGroup.getProductLists().stream()
                                            .anyMatch(productList -> requestDto.getType().equals(productList.getType()));
                                    if (!isTypeExist) {
                                        requestDto.setPreferred(true);
                                    }

                                    return updateProductListGroupAndSaveItemGroup(shoppingList, productListGroup, requestDto);
                                })
                )
                .retryWhen(ServiceConstants.retry(log));
        return Mono.zip(Mono.just(shoppingList), readAndUpdateProfile);
    }

    private Mono<ProductListGroup> updateProductListGroupAndSaveItemGroup(ProductListItemGroup shoppingList, ProductListGroup productListGroup, CreateProductListRequestDTO requestDTO) {
        var productLists = productListGroup.getProductLists().stream()
                .peek(productList -> {
                    if (requestDTO.isPreferred() && requestDTO.getType().equals(productList.getType()))
                        productList.setPreferred(false);    // if current request is preferred list, existing ones must be unpreferred
                }).collect(toList());
        productLists.add(createProductListGroupProductList(productListGroup.getProfileId(), shoppingList, requestDTO.isPreferred(), requestDTO.getColour()));
        productListGroup.setProductLists(productLists);
        return this.productListGroupRepository.save(productListGroup);
    }


    private Mono<CreateProductListResponseDTO> createProductListResponseDTO(ProductListGroup productListGroup, ProductListItemGroup productListItemGroup) {

        // find the corresponding list in productListGroup based on productListItemGroup because returned productListGroup's productList might be in different order
        return Flux.fromIterable(productListGroup.getProductLists())
                .filter(productList -> productList.getListId().equals(productListItemGroup.getListId()))
                .next()
                .map(productList ->
                        CreateProductListResponseDTO.builder()
                                .listId(productList.getListId())
                                .listName(productListItemGroup.getListName())
                                .type(productListItemGroup.getListType())
                                .isPreferred(productList.isPreferred())
                                .isDisabled(productList.isDisabled())
                                .colour(productList.getColour())
                                .lastUpdated(productList.getLastUpdated().toString())
                                .build()
                );
    }

    private Mono<ProductListItemGroup> createProductListItemGroup(CreateProductListRequestDTO requestDto) {
        return Mono.just(ProductListItemGroup.builder()
                .listId(UUID.randomUUID().toString())
                .listName(requestDto.getListName())
                .listType(requestDto.getType())
                .listItems(new ArrayList<>())
                .build());
    }

    private ProductListGroup.ProductList createProductListGroupProductList(String profileId, ProductListItemGroup shoppingList, boolean isPreferred, String color) {
        return ProductListGroup.ProductList.builder()
                .listId(shoppingList.getListId())
                .type(shoppingList.getListType())
                .created(LocalDateTime.now())
                .lastUpdated(LocalDateTime.now())
                .isPreferred(isPreferred)
                .colour(StringUtils.isBlank(color) ? null: color)
                .disabled(false)
                .permissions(ListPermission.OWNER.getName())
                .createdBy(profileId)
                .build();
    }
}
