package au.com.coles.productlistapi.exception;

public class UserAuthException extends RuntimeException{

    public UserAuthException(String msg){
        super(msg);
    }
}
