package au.com.coles.productlistapi.exception;

public class FailedRetryAttemptException extends RuntimeException{

    public FailedRetryAttemptException(String msg){
        super(msg);
    }
}
