package au.com.coles.productlistapi.service

import au.com.coles.UnitTest
import au.com.coles.platform.errorhandling.exceptions.PayloadValidationException
import au.com.coles.productlistapi.exception.FailedRetryAttemptException
import au.com.coles.productlistapi.repository.ProductListGroupRepository
import au.com.coles.productlistapi.repository.ProductListItemGroupRepository
import au.com.coles.productlistapi.repository.model.ProductListGroup
import au.com.coles.productlistapi.repository.model.ProductListItemGroup
import au.com.coles.productlistapi.repository.model.ProductListItemStatusEnum
import au.com.coles.productlistapi.repository.model.ProductListType
import au.com.coles.productlistapi.service.model.CreateProductListItemRequest
import au.com.coles.productlistapi.service.model.ProductListItemDeleteRequest
import au.com.coles.productlistapi.service.model.UpdateProductList
import au.com.coles.productlistapi.service.model.UpdateProductListItemRequest
import com.azure.spring.data.cosmos.exception.CosmosAccessException
import org.junit.experimental.categories.Category
import org.springframework.http.HttpStatus
import reactor.core.publisher.Mono
import spock.lang.Specification
import spock.lang.Unroll

import java.time.LocalDateTime

@Category(UnitTest)
class ProductListItemServiceSpockTest extends Specification {
    public static final String COLOUR_DISABLE_LISTNAME = "colour,disable,listname"
    public static final String PARAM_VALUE = "null"

    def productListGroupRepository = Mock(ProductListGroupRepository.class)

    def productListItemGroupRepository = Mock(ProductListItemGroupRepository.class)

    def service = new ProductListItemService(productListItemGroupRepository, productListGroupRepository)

    @Unroll('#scanario')
    def "UpdateProductList - Update color, disabled and listName"() {
        given:
        def list1_Id = "234"
        def list2_Id = "134"
        def profileId = "234"
        def request = new UpdateProductList(listName: listName_1, colour: color, disable: disable)

        def productLists = [
                new ProductListGroup.ProductList(
                        listId: list1_Id, type: ProductListType.SHOPPING_LIST, colour: color, disabled: disable),
                new ProductListGroup.ProductList(
                        listId: list2_Id, type: ProductListType.SHOPPING_LIST, colour: color, disabled: disable)]

        def productListGroup = new ProductListGroup(
                profileId: profileId,
                productLists: productLists)
        def listItemGroups =  new ProductListItemGroup(listId: list1_Id, listType: ProductListType.SHOPPING_LIST, listName: listName_1)

        when:
        productListGroupRepository.findById(profileId) >> Mono.just(productListGroup)
        productListItemGroupRepository.findById(list1_Id) >>
                Mono.just(listItemGroups)

        productListItemGroupRepository.save(listItemGroups) >>> [Mono.just(listItemGroups)]
        productListGroupRepository.save(productListGroup) >>> Mono.just(productListGroup)

        def result = service.updateProductListItemGroup(profileId, list1_Id, request).block()

        then:
        result != null
        result.colour == color
        result.isDisabled() == expectedDisableFlag

        where:
        scanario                                                    | color   | disable  | listName_1 | expectedDisableFlag
        'Color is RED with NULL list name and not NOT DISABLE'      | 'RED'   | false    |  null      | false
        'Colour is empty with NON empty list name and NOT disabled' | null    | true     |  "TEST"    | true
        'Colour is empty with NON empty list name and disabled'     | null    | false    |  "TEST"    | false
    }

    @Unroll('#scanario')
    def "UpdateProductList - Verify error is thrown when colour, disabled and listName are null in Update request"() {
        given:
        def list1_Id = "234"
        def list2_Id = "134"
        def profileId = "234"
        def request = new UpdateProductList(listName: listName_1, colour: color, disable: disable)

        def productLists = [
                new ProductListGroup.ProductList(
                        listId: list1_Id, type: ProductListType.SHOPPING_LIST, colour: color, disabled: disable),
                new ProductListGroup.ProductList(
                        listId: list2_Id, type: ProductListType.SHOPPING_LIST, colour: color, disabled: disable)]

        def productListGroup = new ProductListGroup(
                profileId: profileId,
                productLists: productLists)
        def listItemGroups =  new ProductListItemGroup(listId: list1_Id, listType: ProductListType.SHOPPING_LIST, listName: listName_1)

        when:
        productListGroupRepository.findById(profileId) >> Mono.just(productListGroup)
        productListItemGroupRepository.findById(list1_Id) >>
                Mono.just(listItemGroups)

        productListItemGroupRepository.save(listItemGroups) >>> [Mono.just(listItemGroups)]
        productListGroupRepository.save(productListGroup) >>> Mono.just(productListGroup)

        def result = service.updateProductListItemGroup(profileId, list1_Id, request).block()

        then:
        def e = thrown(PayloadValidationException)
        e.httpStatus== HttpStatus.BAD_REQUEST
        e.properties !=null
        e.properties.get("name") == COLOUR_DISABLE_LISTNAME
        e.properties.get("value") == PARAM_VALUE
        e.priority.name() =="HIGH"


        where:
        scanario                                                    | color   | disable  | listName_1 | expectedDisableFlag
        'Colour is empty with empty list name and disabled as NULL' | null    | null     |  null      | false
    }

    @Unroll('#scanario')
    def "Add item to product List"() {

        given:

        List<CreateProductListItemRequest> addProductListItemRequest = new ArrayList<>()
        def request = new CreateProductListItemRequest(brandName, productName, quantity, productId, averageSize, productListItemStatusEnum, unitOfMeasure)
        addProductListItemRequest.add(request)

        def productLists = [
                new ProductListGroup.ProductList(
                        listId: list1_Id, type: ProductListType.SHOPPING_LIST, colour: "RED", disabled: true)
        ]

        def productListGroup = new ProductListGroup(
                profileId: profileId,
                productLists: productLists)

//        ProductListItemGroup.ListItem item = new ProductListItemGroup.ListItem(Math.random().toString(), brandName, productName, productId, averageSize, unitOfMeasure, quantity, ProductListItemStatusEnum.CHECKED, LocalDateTime.now(), LocalDateTime.now());

        def listItemGroups =  new ProductListItemGroup(listId: list1_Id, listType: ProductListType.SHOPPING_LIST, listName: listName)

        List<ProductListItemGroup.ListItem> listItemList = itemList as List<ProductListItemGroup.ListItem>
        listItemGroups.setListItems(listItemList)

        when:
        productListGroupRepository.findById(profileId) >> Mono.just(productListGroup)
        productListItemGroupRepository.findById(list1_Id) >>
                Mono.just(listItemGroups)

        productListItemGroupRepository.save(listItemGroups) >>> [Mono.just(listItemGroups)]
        productListGroupRepository.save(productListGroup) >>> Mono.just(productListGroup)

        def result = service.addProductsToShoppingList(profileId, list1_Id, addProductListItemRequest).block()

        then:
        result.size() == response
        result.get(0).quantity == quantity

        where:
        scanario                  | brandName   | productName  | quantity | productId | averageSize | productListItemStatusEnum         | unitOfMeasure | profileId | list1_Id | list2_Id |listName |response | itemList
        'Adding new Item to List' | 'Nike'      | 'Shoes'      |  1       | 1233      | 10          | ProductListItemStatusEnum.CHECKED | 'GM' | '123123' | "LIST_1" | "LIST_2" | "LIST_1" | 1 | new ArrayList<>()
    }

    @Unroll('#scanario')
    def "Retry failed list items"() {

        given:

        List<CreateProductListItemRequest> addProductListItemRequest = new ArrayList<>()
        def request = new CreateProductListItemRequest(brandName, productName, quantity, productId, averageSize, productListItemStatusEnum, unitOfMeasure)
        addProductListItemRequest.add(request)

        def productLists = [
                new ProductListGroup.ProductList(
                        listId: list1_Id, type: ProductListType.SHOPPING_LIST, colour: "RED", disabled: true)
        ]

        def productListGroup = new ProductListGroup(
                profileId: profileId,
                productLists: productLists)

        List<ProductListItemGroup.ListItem> listItemList = itemList as List<ProductListItemGroup.ListItem>

        def listItemGroups =  new ProductListItemGroup(listId: list1_Id, listType: ProductListType.SHOPPING_LIST, listName: listName)
        listItemGroups.setListItems(listItemList)

        when:
        productListGroupRepository.findById(profileId) >> Mono.just(productListGroup)
        productListItemGroupRepository.findById(list1_Id) >>
                Mono.just(listItemGroups)

        productListItemGroupRepository.save(listItemGroups) >> { throw new CosmosAccessException("failed to save") }
        productListGroupRepository.save(productListGroup) >>> Mono.just(productListGroup)

        service.addProductsToShoppingList(profileId, list1_Id, addProductListItemRequest).block()

        then:
        def e = thrown(FailedRetryAttemptException)
        e.message.contains("Failed to replay message even after retries")

        where:
        scanario                                           | brandName   | productName  | quantity | productId | averageSize | productListItemStatusEnum         | unitOfMeasure | profileId | list1_Id | list2_Id |listName |response | itemList
        'Adding and throwing exception when item is added' | 'Nike'      | 'Shoes'      |  1       | 1233      | 10          | ProductListItemStatusEnum.CHECKED | 'GM'          | '123123'  | "LIST_1" | "LIST_2" | "LIST_1"| 1       | new ArrayList<>()
    }

    @Unroll('#scanario')
    def "Delete Product List Item"() {

        given:

        def requestItemList = new ArrayList()
        requestItemList.add(newItem)

        ProductListItemDeleteRequest productListItemDeleteRequest = new ProductListItemDeleteRequest(requestItemList)

        def productLists = [
                new ProductListGroup.ProductList(
                        listId: list1_Id, type: ProductListType.SHOPPING_LIST, colour: "RED", disabled: true)
        ]

        def productListGroup = new ProductListGroup(
                profileId: profileId,
                productLists: productLists)

        List<ProductListItemGroup.ListItem> listItemList = new ArrayList<>()
        ProductListItemGroup.ListItem item = new ProductListItemGroup.ListItem(availableItem, brandName, productName, productId, averageSize, unitOfMeasure, quantity, ProductListItemStatusEnum.CHECKED, LocalDateTime.now(), LocalDateTime.now())
        listItemList.add(item)

        def listItemGroups =  new ProductListItemGroup(listId: list1_Id, listType: ProductListType.SHOPPING_LIST, listName: listName)
        listItemGroups.setListItems(listItemList)

        when:
        productListGroupRepository.findById(profileId) >> Mono.just(productListGroup)
        productListItemGroupRepository.findById(list1_Id) >>
                Mono.just(listItemGroups)

        productListItemGroupRepository.save(listItemGroups) >>> [Mono.just(listItemGroups)]
        productListGroupRepository.save(productListGroup) >>> Mono.just(productListGroup)

        def result = service.deleteProductListItems(profileId, list1_Id, productListItemDeleteRequest).block()

        then:
        result.booleanValue() == response

        where:
        scanario                           | brandName   | productName  | quantity | productId | averageSize | productListItemStatusEnum         | unitOfMeasure | profileId | list1_Id | list2_Id |listName |response | itemList         | availableItem | newItem
        'delete an invalid item from list' | 'Nike'      | 'Shoes'      |  1       | 1233      | 10          | ProductListItemStatusEnum.CHECKED | 'GM'          | '123123'  | "LIST_1" | "LIST_2" | "LIST_1"| false   | new ArrayList<>()| "Item1"       | "Item2"
        'delete an valid   item form list' | 'Nike'      | 'Shoes'      |  1       | 1233      | 10          | ProductListItemStatusEnum.CHECKED | 'GM'          | '123123'  | "LIST_1" | "LIST_2" | "LIST_1"| true    | new ArrayList<>()| "Item1"       | "Item1"
    }

    @Unroll('#scanario')
    def "Product List Update Item"() {

        given:

        List<UpdateProductListItemRequest> updateToList = new ArrayList<>()
        UpdateProductListItemRequest productListItemDeleteRequest = new UpdateProductListItemRequest(invalidItemId, quantity, productListItemStatus)
        updateToList.add(productListItemDeleteRequest)

        def productLists = [
                new ProductListGroup.ProductList(
                        listId: list1_Id, type: ProductListType.SHOPPING_LIST, colour: "RED", disabled: true)
        ]

        def productListGroup = new ProductListGroup(
                profileId: profileId,
                productLists: productLists)

        List<ProductListItemGroup.ListItem> listItemList = new ArrayList<>()
        ProductListItemGroup.ListItem item = new ProductListItemGroup.ListItem(listItemId, brandName, productName, productId, averageSize, unitOfMeasure, quantity, ProductListItemStatusEnum.CHECKED, LocalDateTime.now(), LocalDateTime.now())
        listItemList.add(item)

        def listItemGroups =  new ProductListItemGroup(listId: list1_Id, listType: ProductListType.SHOPPING_LIST, listName: "listName")
        listItemGroups.setListItems(listItemList)

        when:
        productListGroupRepository.findById(profileId) >> Mono.just(productListGroup)
        productListItemGroupRepository.findById(list1_Id) >>
                Mono.just(listItemGroups)

        productListItemGroupRepository.save(listItemGroups) >>> [Mono.just(listItemGroups)]
        productListGroupRepository.save(productListGroup) >>> Mono.just(productListGroup)

        def result = service.updateProductListItem(profileId, list1_Id, updateToList).block()

        then:
        result == response

        where:
        scanario                           | brandName   | productName  | quantity | productId | averageSize | productListItemStatusEnum         |unitOfMeasure  |  profileId | list1_Id | listItemId | productListItemStatus               | response      | invalidItemId
        'update a valid item from list'    | 'Nike'      | 'Shoes'      |  1       | 1233      | 10          | ProductListItemStatusEnum.CHECKED | 'GM'          | "123"      |  "123"   |   "123"    | ProductListItemStatusEnum.UNCHECKED | null          | "invalid"
//        'update a invalid item from list'  | 'Nike'      | 'Shoes'      |  1       | 1233      | 10          | ProductListItemStatusEnum.CHECKED | 'GM'          | "123"      |  "123"   |   "123"    | ProductListItemStatusEnum.UNCHECKED | 1         | listItemId
    }
}
