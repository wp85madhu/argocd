package au.com.coles.productlistapi.service

import au.com.coles.UnitTest
import au.com.coles.productlistapi.repository.ProductListGroupRepository
import au.com.coles.productlistapi.repository.ProductListItemGroupRepository
import au.com.coles.productlistapi.repository.model.ProductListGroup
import au.com.coles.productlistapi.repository.model.ProductListItemGroup
import au.com.coles.productlistapi.repository.model.ProductListType
import au.com.coles.productlistapi.service.model.RetrieveProductListRequestDTO
import org.junit.experimental.categories.Category
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono
import spock.lang.Specification
import spock.lang.Unroll

@Category(UnitTest)
class ProductListServiceSpockTest extends Specification {
    def productListGroupRepository = Mock(ProductListGroupRepository.class)

    def productListItemGroupRepository = Mock(ProductListItemGroupRepository.class)

    def service = new ProductListService(productListGroupRepository, productListItemGroupRepository)

    @Unroll('#scanario')
    def "GetProductList - Validate colour and isDisabled fields"() {
        given:
            def profileId = '123'
            def listId = '234'
            def productLists = [
                    new ProductListGroup.ProductList(
                            listId: listId, type: ProductListType.SHOPPING_LIST, colour: listColour, disabled: isDisabled),
                    new ProductListGroup.ProductList(
                            listId: listId + 1, type: ProductListType.WATCH_LIST, colour: 'BROWN')]
            def productListItems = [new ProductListItemGroup.ListItem(
                    listItemId: '4564565', brandName: 'brandName', productName: 'productName')]
        when:
            productListGroupRepository.findById(profileId) >> Mono.just(new ProductListGroup(
                    profileId: profileId, productLists: productLists))

            productListItemGroupRepository.findById(listId) >> Mono.just(new ProductListItemGroup(
                    listId: listId, listName: 'myList', listItems: productListItems, listType: ProductListType.SHOPPING_LIST))

            def result = service.getProductList(profileId, listId).block()

        then:
            result != null
            result.colour == listColour
            result.disabled == isDisabled

        where:
            scanario                           | listColour | isDisabled
            'Colour is RED and disabled'       | 'RED'      | true
            'Colour is GREEN and NOT disabled' | 'GREEN'    | false
    }

    @Unroll('#scanario')
    def "GetProductLists - Validate colour and isDisabled fields"() {
        given:
            def profileId = "123"
            def list1_Id = "234"
            def list2_Id = "345"
            def request = new RetrieveProductListRequestDTO(profileId: profileId, type: ProductListType.SHOPPING_LIST)
            def productLists = [
                    new ProductListGroup.ProductList(
                            listId: list1_Id, type: ProductListType.SHOPPING_LIST, colour: list1_Colour, disabled: list1_isDisabled),
                    new ProductListGroup.ProductList(
                            listId: list2_Id, type: ProductListType.SHOPPING_LIST, colour: list2_Colour, disabled: list2_isDisabled)]
            def productListGroup = new ProductListGroup(
                    profileId: profileId,
                    productLists: productLists)
            def listItemGroups = [new ProductListItemGroup(listId: list1_Id, listType: ProductListType.SHOPPING_LIST, listName: "List_1"),
                                  new ProductListItemGroup(listId: list2_Id, listType: ProductListType.SHOPPING_LIST, listName: "List_2")]

        when:
            productListGroupRepository.findById(profileId) >> Mono.just(productListGroup)
            productListItemGroupRepository.findByListIdIn([list1_Id, list2_Id]) >>
                    Flux.fromIterable(listItemGroups)
            def result = service.getProductList(request).block()

        then:
            result != null
            result.size() == 2
            result[0].colour == list1_Colour
            result[0].disabled == list1_isDisabled
            result[1].colour == list2_Colour
            result[1].disabled == list2_isDisabled

        where:
            scanario                              | list1_Colour | list1_isDisabled | list2_Colour | list2_isDisabled
            'Two lists with color RED and YELLOW' | 'RED'        | true             | 'YELLOW'     | false
            'Colour is GREEN and NOT disabled'    | 'GREEN'      | false            | 'BLUE'       | true

    }
}
