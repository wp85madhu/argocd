package au.com.coles.productlistapi.service

import au.com.coles.productlistapi.repository.model.ProductListType
import au.com.coles.productlistapi.service.model.CreateProductListRequestDTO
import au.com.coles.productlistapi.service.model.RetrieveProductListRequestDTO
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.scheduling.annotation.EnableAsync
import org.springframework.test.context.ActiveProfiles
import reactor.test.StepVerifier
import spock.lang.Specification
import spock.lang.Unroll

@EnableAsync
@SpringBootTest
@ActiveProfiles("integration")
class ProductListServiceSpocIntTest extends Specification {

    @Autowired
    ProductListService productListService;

    @Autowired
    ProductListCreationService productListCreationService;

    @Unroll('#scenario')
    def "Save productList and fetch it"() {
        when:
            def profileId = 'profileId' + UUID.randomUUID()
            def createResult = productListCreationService.createList(
                    profileId, new CreateProductListRequestDTO(type: type, colour: colour)).block()
            def result = productListService.getProductList(profileId, createResult.listId)

        and:
            StepVerifier
                    .create(result)
                    .expectSubscription()
                    .consumeNextWith({
                        // no explicit mock assertions necessary
                        assert it.colour == expectedColour
                        assert it.disabled == false
                        assert it.type == type
                    })
                    .verifyComplete()

        then:
            result != null

        where:
            scenario                          | colour   | type                          | expectedColour
            'SHOPPING_LIST with colour GREEN' | 'GREEN'  | ProductListType.SHOPPING_LIST | 'GREEN'
            'WATCH_LIST with colour YELLOW'   | 'YELLOW' | ProductListType.WATCH_LIST    | 'YELLOW'
            'Colour is null'                  | null     | ProductListType.SHOPPING_LIST | null
            'Colour is empty'                 | '  '     | ProductListType.SHOPPING_LIST | null
    }

    @Unroll('#scenario')
    def "Save multiple productLists and fetch all"() {
        when:
            def profileId = 'profileId' + UUID.randomUUID()
            def createList1Result = productListCreationService.createList(
                    profileId, new CreateProductListRequestDTO(type: list1_type, colour: list1_colour)).block()
            def createList2Result = productListCreationService.createList(
                    profileId, new CreateProductListRequestDTO(type: list2_type, colour: list2_colour)).block()
            def result = productListService.getProductList(new RetrieveProductListRequestDTO(profileId: profileId, type: findType))

        and:
            StepVerifier
                .create(result)
                .expectSubscription()
                .consumeNextWith({

                    assert it[0].listId == createList1Result.listId
                    assert it[0].colour == list1_colour
                    assert it[0].isDisabled == false
                    assert it[0].type == list1_type

                    assert it[1].listId == createList2Result.listId
                    assert it[1].colour == list2_colour
                    assert it[1].isDisabled == false
                    assert it[1].type == list2_type
                })
                    .expectComplete()
                    .verify();

        then:
            result != null

        where:
            scenario                     | list1_colour | list1_type                    | list2_colour | list2_type                    | findType
            'Test 1 with multiple lists' | 'GREEN'      | ProductListType.SHOPPING_LIST | 'RED'        | ProductListType.SHOPPING_LIST | ProductListType.SHOPPING_LIST
            'Test 2 with multiple lists' | 'PURPLE'     | ProductListType.WATCH_LIST    | 'YELLOW'     | ProductListType.WATCH_LIST    | ProductListType.WATCH_LIST
        }
}
