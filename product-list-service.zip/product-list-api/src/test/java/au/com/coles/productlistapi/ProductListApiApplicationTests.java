package au.com.coles.productlistapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

class ProductListApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
