package au.com.coles.productlistapi.controller;

import au.com.coles.productlistapi.repository.ProductListGroupRepository;
import au.com.coles.productlistapi.repository.ProductListItemGroupRepository;
import au.com.coles.productlistapi.repository.model.ProductListGroup;
import au.com.coles.productlistapi.repository.model.ProductListItemGroup;
import au.com.coles.productlistapi.service.ProductListItemService;
import au.com.coles.productlistapi.service.ProductListService;
import org.junit.Before;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import reactor.core.publisher.Mono;

import static org.codehaus.groovy.runtime.InvokerHelper.asList;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@Disabled
@Import({ProductListItemService.class, ProductListService.class})
@WebMvcTest(CustomersController.class)
public class CustomersControllerTest {
    @MockBean
    private ProductListGroupRepository profileRepo;
    @MockBean
    private ProductListItemGroupRepository listRepo;


    //@Autowired
    //private WebTestClient client;

    @Autowired
    private MockMvc mvc;

    @Before
    public void setup() {
    }

    @Test
    public void shouldReturnProductList() throws Exception {
        var listId = "listId";
        var profileId = "profileId";
        Mockito
                .when(profileRepo.findById(eq(profileId)))
                .thenReturn(Mono.just(ProductListGroup.builder()
                        .profileId(profileId)
                        .productLists(asList(ProductListGroup.ProductList.builder()
                                .listId(listId)
                                .build()))
                        .build()));
        Mockito
                .when(listRepo.findById(eq(listId)))
                .thenReturn(Mono.just(ProductListItemGroup.builder()
                        .listId(listId)
                        .listItems(asList(ProductListItemGroup.ListItem.builder()
                                .brandName("test")
                                .build())).build()));
        var request = MockMvcRequestBuilders
                .get("/customers/" + profileId + "/lists/" + listId + "/items")
                .contentType(MediaType.APPLICATION_JSON);
        mvc.perform(request)
                .andExpect(status().isOk());
    }

    /*@Test
    public void shouldReturn404() throws Exception {
        var listId = "listId";
        var profileId = "profileId";
        Mockito
                .when(profileRepo.findById(eq(profileId)))
                .thenReturn(Mono.empty());
        Mockito
                .when(listRepo.findById(eq(listId)))
                .thenReturn(Mono.empty());
        var request = MockMvcRequestBuilders
                .get("/customers/" + profileId + "/lists/" + listId + "/items")
                .contentType(MediaType.APPLICATION_JSON);
        mvc.perform(request)
                .andExpect(status().isNotFound());
    }*/
}
