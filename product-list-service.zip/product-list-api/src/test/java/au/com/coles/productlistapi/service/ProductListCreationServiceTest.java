package au.com.coles.productlistapi.service;

import au.com.coles.productlistapi.exception.FailedRetryAttemptException;
import au.com.coles.productlistapi.repository.ProductListGroupRepository;
import au.com.coles.productlistapi.repository.ProductListItemGroupRepository;
import au.com.coles.productlistapi.repository.model.ProductListGroup;
import au.com.coles.productlistapi.repository.model.ProductListItemGroup;
import au.com.coles.productlistapi.repository.model.ProductListType;
import au.com.coles.productlistapi.service.model.CreateProductListRequestDTO;
import au.com.coles.productlistapi.service.model.CreateProductListResponseDTO;
import au.com.coles.productlistapi.service.model.ListPermission;
import com.azure.cosmos.BridgeInternal;
import com.azure.spring.data.cosmos.exception.CosmosAccessException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static java.util.stream.Collectors.toList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class ProductListCreationServiceTest {

    @InjectMocks
    private ProductListCreationService serviceUnderTest;

    @Mock
    private ProductListGroupRepository mockedProductListGroupRepo;

    @Mock
    private ProductListItemGroupRepository mockedProductListItemGroupRepo;

    @Captor
    private ArgumentCaptor<ProductListGroup> productListGroupArgCaptor;

    @Captor
    private ArgumentCaptor<ProductListItemGroup> productListItemGroupArgCaptor;

    @Captor
    private ArgumentCaptor<String> profileIdArgCaptor;

    private final String CREATE_LIST_PROFILE_ID = "abc123";
    private final String CREATE_LIST_LIST_NAME = "mylist";
    private final ProductListType CREATE_SHOPPING_LIST_TYPE = ProductListType.SHOPPING_LIST;
    private final ProductListType CREATE_WATCH_LIST_TYPE = ProductListType.WATCH_LIST;
    private final String CREATE_LIST_LIST_ID = "list1234";
    private final String CREATE_LIST_DUMMY_DATE_TIME = "2020-10-02T10:20:15";
    private final LocalDateTime CREATE_LIST_DUMMY_DATE_TIME_OBJ = LocalDateTime.parse(CREATE_LIST_DUMMY_DATE_TIME);

    @ParameterizedTest
    @ValueSource(booleans = {true, false}) // for request isPreferred field
    public void givenRequestToCreateProductListWithNewProfileId_whenRequestPayloadIsValidAndProfileIdNotExist_thenCreateANewPreferredListInRepo(boolean isPreferred) {

        // Mocking
        when(mockedProductListGroupRepo.findById(anyString())).thenReturn(Mono.empty());
        when(mockedProductListGroupRepo.save(any(ProductListGroup.class))).thenReturn(Mono.just(createProductListGroup()));
        when(mockedProductListItemGroupRepo.save(any(ProductListItemGroup.class))).thenReturn(Mono.just(createProductListItemGroup()));

        // call targeted service
        Mono<CreateProductListResponseDTO> actualResponse = serviceUnderTest.createList(CREATE_LIST_PROFILE_ID, getCreateProductListRequestDTO().toBuilder().isPreferred(isPreferred).build());

        // verification
        assertThat(actualResponse.block()).isEqualTo(getCreateProductListResponseDTO());
        verify(mockedProductListGroupRepo, atMostOnce()).findById(anyString());
        verify(mockedProductListGroupRepo, atMostOnce()).save(any(ProductListGroup.class));
        verify(mockedProductListItemGroupRepo, atMostOnce()).save(any(ProductListItemGroup.class));

        verify(mockedProductListGroupRepo).findById(profileIdArgCaptor.capture());
        assertThat(profileIdArgCaptor.getValue()).isEqualTo(CREATE_LIST_PROFILE_ID);

        verify(mockedProductListGroupRepo).save(productListGroupArgCaptor.capture());
        assertThat(productListGroupArgCaptor.getValue().getProfileId()).isEqualTo(CREATE_LIST_PROFILE_ID);
        assertThat(productListGroupArgCaptor.getValue().getProductLists().size()).isEqualTo(1);
        assertThat(productListGroupArgCaptor.getValue().getProductLists().get(0).getType()).isEqualTo(CREATE_SHOPPING_LIST_TYPE);
        assertThat(productListGroupArgCaptor.getValue().getProductLists().get(0).isPreferred()).isEqualTo(true);
        assertThat(productListGroupArgCaptor.getValue().getProductLists().get(0).getListId()).isNotEmpty();
        assertThat(productListGroupArgCaptor.getValue().getProductLists().get(0).getLastUpdated()).isNotNull();
        assertThat(productListGroupArgCaptor.getValue().getProductLists().get(0).getPermissions()).isEqualTo(ListPermission.OWNER.getName());
        assertThat(productListGroupArgCaptor.getValue().getProductLists().get(0).getCreated()).isNotNull();
        assertThat(productListGroupArgCaptor.getValue().getProductLists().get(0).getCreatedBy()).isEqualTo(CREATE_LIST_PROFILE_ID);

        verify(mockedProductListItemGroupRepo).save(productListItemGroupArgCaptor.capture());
        assertThat(productListItemGroupArgCaptor.getValue()).isEqualToIgnoringGivenFields(ProductListItemGroup.builder()
                .listId(CREATE_LIST_LIST_ID)
                .listName(CREATE_LIST_LIST_NAME)
                .listType(CREATE_SHOPPING_LIST_TYPE)
                .listItems(Arrays.asList())
                .build(), "listId");
    }

    @Test
    public void givenRequestToCreateProductListWithNewProfileId_whenRequestPayloadIsValidAndProfileIdNotExistAndNotPreferredList_thenCreateANewPreferredListInRepo() {

        // Mocking
        when(mockedProductListGroupRepo.findById(anyString())).thenReturn(Mono.empty());
        when(mockedProductListGroupRepo.save(any(ProductListGroup.class))).thenReturn(Mono.just(createProductListGroup()));
        when(mockedProductListItemGroupRepo.save(any(ProductListItemGroup.class))).thenReturn(Mono.just(createProductListItemGroup()));

        // call targeted service
        CreateProductListRequestDTO requestDTOWithNotPreferredList = getCreateProductListRequestDTO().toBuilder().isPreferred(false).build();
        Mono<CreateProductListResponseDTO> actualResponse = serviceUnderTest.createList(CREATE_LIST_PROFILE_ID, requestDTOWithNotPreferredList);

        // verification
        assertThat(actualResponse.block()).isEqualTo(getCreateProductListResponseDTO());
        verify(mockedProductListGroupRepo).save(productListGroupArgCaptor.capture());
        assertThat(productListGroupArgCaptor.getValue().getProfileId()).isEqualTo(CREATE_LIST_PROFILE_ID);
        assertThat(productListGroupArgCaptor.getValue().getProductLists().size()).isEqualTo(1);
        assertThat(productListGroupArgCaptor.getValue().getProductLists().get(0).isPreferred()).isEqualTo(true); // should be TRUE if there is only one list
    }

    @Test
    public void givenSaveFailRetryShouldHappen(){
        Mono<ProductListGroup> error = Mono.error(new CosmosAccessException("", BridgeInternal.createCosmosException(412)));
        when(mockedProductListGroupRepo.findById(anyString())).thenReturn(Mono.empty());
        when(mockedProductListItemGroupRepo.save(any(ProductListItemGroup.class)))
                .thenAnswer(invocationOnMock -> Mono.just(invocationOnMock.getArgument(0)));

        AtomicInteger mockedProductListGroupRepoSaveCount = new AtomicInteger();
        //return error, error, success
        when(mockedProductListGroupRepo.save(any(ProductListGroup.class)))
                .thenAnswer(invocationOnMock -> mockedProductListGroupRepoSaveCount.getAndIncrement() < 2 ? error : Mono.just(invocationOnMock.getArgument(0)));

        // call targeted service
        CreateProductListRequestDTO requestDTOWithNotPreferredList = getCreateProductListRequestDTO().toBuilder().isPreferred(false).build();
        Mono<CreateProductListResponseDTO> actualResponse = serviceUnderTest.createList(CREATE_LIST_PROFILE_ID, requestDTOWithNotPreferredList);

        assertThat(actualResponse.block()).isEqualToIgnoringGivenFields(getCreateProductListResponseDTO(), "listId", "lastUpdated");

        verify(mockedProductListGroupRepo, times(3)).save(productListGroupArgCaptor.capture());
        verify(mockedProductListGroupRepo, times(3)).findById(anyString());
        var productLists = productListGroupArgCaptor.getAllValues()
                .stream()
                .map(p->p.getProductLists().stream().map(ProductListGroup.ProductList::getListId).collect(toList()))
                .flatMap(Collection::stream)
                .distinct()
                .collect(toList());
        // profile should be updated with same list
        assertThat(productLists.size()).isEqualTo(1);

        verify(mockedProductListItemGroupRepo, times(1)).save(productListItemGroupArgCaptor.capture());
        assertThat(productListItemGroupArgCaptor.getValue().getListId()).isEqualTo(productLists.stream().findFirst().get());
    }

    @Test
    public void givenSaveFailRetryShouldFailAfter3times(){
        Mono<ProductListGroup> error = Mono.error(new CosmosAccessException(""));
        when(mockedProductListGroupRepo.findById(anyString())).thenReturn(Mono.empty());
        when(mockedProductListItemGroupRepo.save(any(ProductListItemGroup.class))).thenReturn(Mono.just(createProductListItemGroup()));
        when(mockedProductListGroupRepo.save(any(ProductListGroup.class))).thenReturn(error);

        // call targeted service
        CreateProductListRequestDTO requestDTOWithNotPreferredList = getCreateProductListRequestDTO().toBuilder().isPreferred(false).build();
        Mono<CreateProductListResponseDTO> actualResponse = serviceUnderTest.createList(CREATE_LIST_PROFILE_ID, requestDTOWithNotPreferredList);

        var exception = org.junit.jupiter.api.Assertions.assertThrows(FailedRetryAttemptException.class, actualResponse::block);

        assertThat(exception).isInstanceOf(FailedRetryAttemptException.class);

        verify(mockedProductListGroupRepo, times(4)).save(any());
        verify(mockedProductListGroupRepo, times(4)).findById(anyString());
        verify(mockedProductListItemGroupRepo, times(1)).save(any());
    }

    @Test
    public void givenRequestToCreateProductListWithExistingProfileId_whenRequestPayloadIsValidAndProfileIdExistAndNotPreferredList_thenCreateANewNotPreferredListInRepo() {

        // mocking
        ProductListGroup existingProductListGroupInRepo = createProductListGroup();
        when(mockedProductListGroupRepo.findById(anyString())).thenReturn(Mono.just(existingProductListGroupInRepo));

        String newListId = "newid123";
        String newListName = "mynewlist";
        ProductListGroup productListGroupWithNotPreferredList = createProductListGroup();
        ProductListGroup.ProductList notPreferredProductList = createProductList().toBuilder().listId(newListId).isPreferred(false).build();
        productListGroupWithNotPreferredList.getProductLists().add(notPreferredProductList);
        when(mockedProductListGroupRepo.save(any(ProductListGroup.class))).thenReturn(Mono.just(productListGroupWithNotPreferredList));

        ProductListItemGroup newProductListItemGroup = createProductListItemGroup().toBuilder().listId(newListId).listName(newListName).build();
        when(mockedProductListItemGroupRepo.save(any(ProductListItemGroup.class))).thenReturn(Mono.just(newProductListItemGroup));

        // call targeted service
        CreateProductListRequestDTO requestDto = getCreateProductListRequestDTO().toBuilder().listName(newListName).isPreferred(false).build();
        Mono<CreateProductListResponseDTO> actualResponse = serviceUnderTest.createList(CREATE_LIST_PROFILE_ID, requestDto);

        // verification
        CreateProductListResponseDTO responseDTO = getCreateProductListResponseDTO().toBuilder().listId(newListId).listName(newListName).isPreferred(false).build();
        assertThat(actualResponse.block()).isEqualToIgnoringGivenFields(responseDTO, "listId");
        verify(mockedProductListGroupRepo, atMostOnce()).findById(anyString());
        verify(mockedProductListGroupRepo, atMostOnce()).save(any(ProductListGroup.class));
        verify(mockedProductListItemGroupRepo, atMostOnce()).save(any(ProductListItemGroup.class));

        verify(mockedProductListGroupRepo).findById(profileIdArgCaptor.capture());
        assertThat(profileIdArgCaptor.getValue()).isEqualTo(CREATE_LIST_PROFILE_ID);

        verify(mockedProductListGroupRepo).save(productListGroupArgCaptor.capture());
        assertThat(productListGroupArgCaptor.getValue().getProfileId()).isEqualTo(CREATE_LIST_PROFILE_ID);
        assertThat(productListGroupArgCaptor.getValue().getProductLists().size()).isEqualTo(2);
        assertThat(productListGroupArgCaptor.getValue().getProductLists().get(1).getType()).isEqualTo(CREATE_SHOPPING_LIST_TYPE);
        assertThat(productListGroupArgCaptor.getValue().getProductLists().get(1).isPreferred()).isEqualTo(false);
        assertThat(productListGroupArgCaptor.getValue().getProductLists().get(1).getListId()).isNotEmpty();
        assertThat(productListGroupArgCaptor.getValue().getProductLists().get(1).getLastUpdated()).isNotNull();
        assertThat(productListGroupArgCaptor.getValue().getProductLists().get(1).getPermissions()).isEqualTo(ListPermission.OWNER.getName());
        assertThat(productListGroupArgCaptor.getValue().getProductLists().get(1).getCreated()).isNotNull();
        assertThat(productListGroupArgCaptor.getValue().getProductLists().get(1).getCreatedBy()).isEqualTo(CREATE_LIST_PROFILE_ID);

        verify(mockedProductListItemGroupRepo).save(productListItemGroupArgCaptor.capture());
        assertThat(productListItemGroupArgCaptor.getValue()).isEqualToIgnoringGivenFields(ProductListItemGroup.builder()

                .listName(newListName)
                .listType(CREATE_SHOPPING_LIST_TYPE)
                .listItems(Arrays.asList())
                .build(), "listId");
    }

    @Test
    public void givenRequestToCreateProductListWithExistingProfileId_whenRequestPayloadIsValidAndProfileIdExistAndPreferredList_thenCreateANewPreferredListAndUnpreferredExistingOneInRepo() {

        // mocking
        ProductListGroup existingProductListGroupInRepo = createProductListGroup();
        when(mockedProductListGroupRepo.findById(anyString())).thenReturn(Mono.just(existingProductListGroupInRepo));

        String newListId = "newid123";
        String newListName = "mynewlist";
        ProductListGroup requestedProductListGroup = createProductListGroup();
        ProductListGroup.ProductList preferredProductList = createProductList().toBuilder().listId(newListId).isPreferred(true).build();
        requestedProductListGroup.getProductLists().add(preferredProductList);
        // since new request list is a preferred list, all existing list must set to not preferred
        requestedProductListGroup.getProductLists().get(0).setPreferred(false);
        when(mockedProductListGroupRepo.save(any(ProductListGroup.class))).thenReturn(Mono.just(requestedProductListGroup));

        ProductListItemGroup newProductListItemGroup = createProductListItemGroup().toBuilder().listId(newListId).listName(newListName).build();
        when(mockedProductListItemGroupRepo.save(any(ProductListItemGroup.class))).thenReturn(Mono.just(newProductListItemGroup));

        // call targeted service
        CreateProductListRequestDTO requestDto = getCreateProductListRequestDTO().toBuilder().listName(newListName).isPreferred(true).build();
        Mono<CreateProductListResponseDTO> actualResponse = serviceUnderTest.createList(CREATE_LIST_PROFILE_ID, requestDto);

        // verification
        CreateProductListResponseDTO responseDTO = getCreateProductListResponseDTO().toBuilder().listId(newListId).listName(newListName).isPreferred(true).build();
        assertThat(actualResponse.block()).isEqualTo(responseDTO);

        verify(mockedProductListGroupRepo).save(productListGroupArgCaptor.capture());
        assertThat(productListGroupArgCaptor.getValue().getProfileId()).isEqualTo(CREATE_LIST_PROFILE_ID);
        assertThat(productListGroupArgCaptor.getValue().getProductLists().size()).isEqualTo(2);
        assertThat(productListGroupArgCaptor.getValue().getProductLists().get(1).isPreferred()).isEqualTo(true);    // new request preferred is true
        assertThat(productListGroupArgCaptor.getValue().getProductLists().get(0).isPreferred()).isEqualTo(false);   // existing preferred should become false
    }

    @ParameterizedTest
    @ValueSource(booleans = {true, false}) // for request isPreferred field
    public void givenRequestToCreateProductListWithExistingProfileIdAndNewListType_whenRequestPayloadIsValid_thenCreateANewTypeAsPreferredListInRepo(boolean isPreferred) {

        // mocking
        ProductListGroup existingProductListGroupInRepo = createProductListGroup();
        when(mockedProductListGroupRepo.findById(anyString())).thenReturn(Mono.just(existingProductListGroupInRepo));

        String newListId = "newid123";
        String newListName = "mywatchlist";
        ProductListGroup savedProductListGroup = createProductListGroup();
        ProductListGroup.ProductList newWatchList = createProductList().toBuilder().type(ProductListType.WATCH_LIST).listId(newListId).isPreferred(true).build();
        savedProductListGroup.getProductLists().add(newWatchList);
        when(mockedProductListGroupRepo.save(any(ProductListGroup.class))).thenReturn(Mono.just(savedProductListGroup)); // should have 2 different types - shopping and watch list

        ProductListItemGroup newProductListItemGroup = createProductListItemGroup().toBuilder().listType(ProductListType.WATCH_LIST).listId(newListId).listName(newListName).build();
        when(mockedProductListItemGroupRepo.save(any(ProductListItemGroup.class))).thenReturn(Mono.just(newProductListItemGroup));

        // call targeted service
        CreateProductListRequestDTO requestDto = getCreateProductListRequestDTO().toBuilder().listName(newListName).type(ProductListType.WATCH_LIST).isPreferred(isPreferred).build();
        Mono<CreateProductListResponseDTO> actualResponse = serviceUnderTest.createList(CREATE_LIST_PROFILE_ID, requestDto);

        // verification
        CreateProductListResponseDTO expectedResponse = getCreateProductListResponseDTO().toBuilder().listId(newListId).listName(newListName).type(ProductListType.WATCH_LIST).build();
        assertThat(actualResponse.block()).isEqualTo(expectedResponse);

        verify(mockedProductListGroupRepo).save(productListGroupArgCaptor.capture());
        assertThat(productListGroupArgCaptor.getValue().getProfileId()).isEqualTo(CREATE_LIST_PROFILE_ID);
        assertThat(productListGroupArgCaptor.getValue().getProductLists().size()).isEqualTo(2);
        assertThat(productListGroupArgCaptor.getValue().getProductLists().get(0).getType()).isEqualTo(CREATE_SHOPPING_LIST_TYPE);
        assertThat(productListGroupArgCaptor.getValue().getProductLists().get(0).isPreferred()).isEqualTo(true); // since only 1 shopping list should be true
        assertThat(productListGroupArgCaptor.getValue().getProductLists().get(1).getType()).isEqualTo(CREATE_WATCH_LIST_TYPE);
        assertThat(productListGroupArgCaptor.getValue().getProductLists().get(1).isPreferred()).isEqualTo(true); // since only 1 watch list should be true
    }

    private CreateProductListRequestDTO getCreateProductListRequestDTO() {
        return CreateProductListRequestDTO.builder().listName(CREATE_LIST_LIST_NAME).type(CREATE_SHOPPING_LIST_TYPE).isPreferred(true).build();
    }

    private CreateProductListResponseDTO getCreateProductListResponseDTO() {
        return CreateProductListResponseDTO.builder().listId(CREATE_LIST_LIST_ID).listName(CREATE_LIST_LIST_NAME).type(CREATE_SHOPPING_LIST_TYPE)
                .isPreferred(true).lastUpdated(CREATE_LIST_DUMMY_DATE_TIME).build();
    }

    private ProductListGroup createProductListGroup() {
        List<ProductListGroup.ProductList> productLists = new ArrayList<>();
        productLists.add(createProductList());
        return ProductListGroup.builder().profileId(CREATE_LIST_PROFILE_ID).productLists(productLists).build();
    }

    private ProductListItemGroup createProductListItemGroup() {
        return ProductListItemGroup.builder().listId(CREATE_LIST_LIST_ID).listName(CREATE_LIST_LIST_NAME).listType(CREATE_SHOPPING_LIST_TYPE).listItems(new ArrayList<>()).build();
    }

    private ProductListGroup.ProductList createProductList() {
        return ProductListGroup.ProductList.builder().type(CREATE_SHOPPING_LIST_TYPE).listId(CREATE_LIST_LIST_ID)
                .created(CREATE_LIST_DUMMY_DATE_TIME_OBJ).lastUpdated(CREATE_LIST_DUMMY_DATE_TIME_OBJ).isPreferred(true)
                .permissions(ListPermission.OWNER.getName()).createdBy(CREATE_LIST_PROFILE_ID).build();
    }
}
