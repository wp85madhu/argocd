package au.com.coles.productlistapi.controller;

import au.com.coles.productlistapi.dto.ProductListResponse;
import au.com.coles.productlistapi.repository.model.ProductListItemGroup;
import au.com.coles.productlistapi.repository.model.ProductListItemStatusEnum;
import au.com.coles.productlistapi.repository.model.ProductListType;
import au.com.coles.productlistapi.service.ProductListItemService;
import au.com.coles.productlistapi.service.ProductListService;
import au.com.coles.productlistapi.service.model.*;
import org.junit.Before;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@Disabled
@ExtendWith(MockitoExtension.class)
public class ProductListControllerWithoutWebFluxTest {
    @InjectMocks
    private ProductListController unitUnderTest;

    @Mock
    private ProductListService service;
    @Mock
    private ProductListItemService itemService;

    private static final String LIST_ITEM_ID = "abcitem123";
    private static final String BRAND_NAME = "coles";
    private static final String PRODUCT_NAME = "milk";
    private static final int PRODUCT_ID = 1001;
    private static final int AVERAGE_SIZE = 2;
    private static final String UNIT_OF_MEASUER = "bottle";
    private static final int QUANTITY = 10;
    private static final LocalDateTime LAST_UPDATED = LocalDateTime.of(2020, 1, 2, 14, 0);

    private static final String PROFILE_ID = "abc123";
    private static final String LIST_ID = "123";
    private static final String LIST_NAME = "ABC123";
    private static final LocalDateTime LIST_LASTUPDATED = LocalDateTime.of(2020, 1, 2, 14, 0);

    private static final String AUTH_TOKEN = "test_token";
    private static final String TYPE = "SHOPPING_LIST";

    private RetrieveProductListRequestDTO requestDTO;

    @Before
    public void setup() {
    }

    @Test
    public void shouldGetProductList() {
        RetrieveProductListResponseDTO dto = RetrieveProductListResponseDTO.builder().type(ProductListType.SHOPPING_LIST).build();
        when(service.getProductList(any()))
                .thenReturn(Mono.just(Arrays.asList(dto)));

        List<RetrieveProductListResponseDTO> responseDTOs = unitUnderTest.getProductList(TYPE, "").block();
        assertEquals(1, responseDTOs.size());
        assertEquals(ProductListType.SHOPPING_LIST, responseDTOs.get(0).getType());
    }

    @Test
    public void shouldCreateProductListItem() {
        ProductListResponse listResponse = ProductListResponse.builder()
                .listId(LIST_ID)
                .listName(LIST_NAME)
                .type(ProductListType.SHOPPING_LIST)
                .lastUpdated(LIST_LASTUPDATED)
                .build();

        List<CreateProductListItemRequest> request = Arrays.asList(CreateProductListItemRequest.builder()
                .brandName(BRAND_NAME)
                .productName(PRODUCT_NAME)
                .productId(PRODUCT_ID)
                .averageSize(AVERAGE_SIZE)
                .unitOfMeasure(UNIT_OF_MEASUER)
                .quantity(QUANTITY)
                .build()
        );

        List<ProductListItemGroup.ListItem> listItem = Arrays.asList(ProductListItemGroup.ListItem.builder()
                .listItemId(LIST_ITEM_ID)
                .brandName(BRAND_NAME)
                .productName(PRODUCT_NAME)
                .productId(PRODUCT_ID)
                .averageSize(AVERAGE_SIZE)
                .unitOfMeasure(UNIT_OF_MEASUER)
                .quantity(QUANTITY)
                .status(ProductListItemStatusEnum.UNCHECKED)
                .created(LocalDateTime.now())
                .lastUpdated(LAST_UPDATED)
                .build());

        when(service.getProductList(anyString(), anyString()))
                .thenReturn(Mono.just(listResponse));

        when(itemService.addProductsToShoppingList(anyString(), anyString(), any()))
                .thenReturn(Mono.just(listItem));

        ResponseEntity<List<ProductListItemGroup.ListItem>> response = unitUnderTest.addProductListItem("", LIST_ID, request).block();
        assertThat(response).isEqualTo(new ResponseEntity<>(listItem, HttpStatus.OK));
    }

    @Test
    public void shouldCreateProductListItemReturnNotFound_IfProfileIdListIdCannotMatch() {
        List<CreateProductListItemRequest> request = Arrays.asList(CreateProductListItemRequest.builder()
                .brandName(BRAND_NAME)
                .productName(PRODUCT_NAME)
                .productId(PRODUCT_ID)
                .averageSize(AVERAGE_SIZE)
                .unitOfMeasure(UNIT_OF_MEASUER)
                .quantity(QUANTITY)
                .build()
        );

        when(service.getProductList(anyString(), anyString()))
                .thenReturn(Mono.empty());

        ResponseEntity<List<ProductListItemGroup.ListItem>> response = unitUnderTest.addProductListItem("", LIST_ID, request).block();
        assertThat(response).isEqualTo(ResponseEntity.notFound().build());
    }

    @Test
    public void testDeleteListItems() {
        when(itemService.deleteProductListItems(anyString(), anyString(), any()))
                .thenReturn(Mono.just(true));

        ProductListItemDeleteRequest request = ProductListItemDeleteRequest.builder().listItemId(Arrays.asList(LIST_ITEM_ID)).build();
        ResponseEntity<Boolean> response = unitUnderTest.deleteListItems(LIST_ID, "", request).block();
        assertThat(response).isEqualTo(new ResponseEntity<>(HttpStatus.NO_CONTENT));
    }

    @Test
    public void testDeleteProductListItems_Return404WhenMatchingListNotFound() {
        when(itemService.deleteProductListItems(anyString(), anyString(), any()))
                .thenReturn(Mono.just(false));

        ProductListItemDeleteRequest request = ProductListItemDeleteRequest.builder().listItemId(Arrays.asList(LIST_ITEM_ID)).build();
        ResponseEntity<Boolean> response = unitUnderTest.deleteListItems(LIST_ID, "", request).block();
        assertThat(response).isEqualTo(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @Test
    public void shouldUpdateProductListItem() {
        ProductListResponse listResponse = ProductListResponse.builder()
                .listId(LIST_ID)
                .listName(LIST_NAME)
                .type(ProductListType.SHOPPING_LIST)
                .lastUpdated(LIST_LASTUPDATED)
                .build();

        List<UpdateProductListItemRequest> request = Arrays.asList(UpdateProductListItemRequest.builder()
                .listItemId(LIST_ITEM_ID)
                .quantity(QUANTITY)
                .status(ProductListItemStatusEnum.UNCHECKED)
                .build()
        );

        List<ProductListItemGroup.ListItem> listItem = Arrays.asList(ProductListItemGroup.ListItem.builder()
                .listItemId(LIST_ITEM_ID)
                .brandName(BRAND_NAME)
                .productName(PRODUCT_NAME)
                .productId(PRODUCT_ID)
                .averageSize(AVERAGE_SIZE)
                .unitOfMeasure(UNIT_OF_MEASUER)
                .quantity(QUANTITY)
                .status(ProductListItemStatusEnum.UNCHECKED)
                .created(LocalDateTime.now())
                .lastUpdated(LAST_UPDATED)
                .build());

        when(service.getProductList(anyString(), anyString()))
                .thenReturn(Mono.just(listResponse));

        when(itemService.updateProductListItem(anyString(), anyString(), any()))
                .thenReturn(Mono.just(listItem));

        ResponseEntity<List<ProductListItemGroup.ListItem>> response = unitUnderTest.updateProductListItem(LIST_ID, "", request).block();
        assertThat(response).isEqualTo(new ResponseEntity<>(listItem, HttpStatus.OK));
    }


    @Test
    public void shouldUpdateProductList() {
        ProductListResponse listResponse = ProductListResponse.builder()
                .listId(LIST_ID)
                .listName(LIST_NAME)
                .type(ProductListType.SHOPPING_LIST)
                .lastUpdated(LIST_LASTUPDATED)
                .build();

        UpdateProductList updateProductListRequest = UpdateProductList.builder()
                .listName("ABC123")
                .colour(null)
                .disable(false)
                .build();

        when(itemService.updateProductListItemGroup(anyString(), anyString(), any()))
                .thenReturn(Mono.just(listResponse));

        ProductListResponse productListResponse = ProductListResponse.builder()
                .listId(LIST_ID)
                .lastUpdated(LIST_LASTUPDATED)
                .isPreferred(false)
                .listName("ABC123")
                .colour(null)
                .isDisabled(false)
                .type(ProductListType.SHOPPING_LIST)
                .build();

        ResponseEntity<ProductListResponse> response = unitUnderTest.updateProductList(LIST_ID, PROFILE_ID, updateProductListRequest).block();
        assertThat(response).isEqualTo(new ResponseEntity<>(productListResponse, HttpStatus.OK));
    }


    @Test
    public void shouldUpdateProductListItemReturnNotFound_IfProfileIdListIdCannotMatch() {
        List<UpdateProductListItemRequest> request = Arrays.asList(UpdateProductListItemRequest.builder()
                .listItemId(LIST_ITEM_ID)
                .quantity(QUANTITY)
                .status(ProductListItemStatusEnum.UNCHECKED)
                .build()
        );

        when(service.getProductList(anyString(), anyString()))
                .thenReturn(Mono.empty());

        ResponseEntity<List<ProductListItemGroup.ListItem>> response = unitUnderTest.updateProductListItem(LIST_ID, "", request).block();
        assertThat(response).isEqualTo(ResponseEntity.notFound().build());
    }
}
