package au.com.coles.productlistapi.service;

import au.com.coles.platform.errorhandling.exceptions.PayloadValidationException;
import au.com.coles.productlistapi.dto.ProductListItemResponse;
import au.com.coles.productlistapi.dto.ProductListResponse;
import au.com.coles.productlistapi.repository.ProductListGroupRepository;
import au.com.coles.productlistapi.repository.ProductListItemGroupRepository;
import au.com.coles.productlistapi.repository.model.ProductListGroup;
import au.com.coles.productlistapi.repository.model.ProductListItemGroup;
import au.com.coles.productlistapi.repository.model.ProductListItemStatusEnum;
import au.com.coles.productlistapi.repository.model.ProductListType;
import au.com.coles.productlistapi.service.model.CreateProductListItemRequest;
import au.com.coles.productlistapi.service.model.ProductListItemDeleteRequest;
import au.com.coles.productlistapi.service.model.UpdateProductList;
import au.com.coles.productlistapi.service.model.UpdateProductListItemRequest;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import reactor.core.publisher.Mono;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class ProductListItemServiceTest {
    @InjectMocks
    private ProductListItemService serviceUnderTest;

    @Mock
    private ProductListGroupRepository mockedProductListGroupRepo;
    @Mock
    private ProductListItemGroupRepository mockedProductListItemGroupRepo;

    private static final String BRAND_NAME = "coles";
    private static final String BRAND_NAME2 = "A2";
    private static final String PRODUCT_NAME = "milk";
    private static final String PRODUCT_NAME2 = "milk";
    private static final Integer PRODUCT_ID = 1001;
    private static final Integer PRODUCT_ID2 = 1002;
    private static final int AVERAGE_SIZE = 2;
    private static final String UNIT_OF_MEASURE = "bottle";
    private static final int QUANTITY = 10;
    private static final ProductListItemStatusEnum STATUS = ProductListItemStatusEnum.UNCHECKED;

    private static final int AVERAGE_SIZE2 = 4;
    private static final String UNIT_OF_MEASURE2 = "box";
    private static final int QUANTITY2 = 20;
    private static final ProductListItemStatusEnum STATUS2 = ProductListItemStatusEnum.CHECKED;

    private static final String LIST_ID = "123";
    private static final String LIST_ID_II = "12345";
    private static final ProductListType LIST_TYPE = ProductListType.SHOPPING_LIST;
    private static final String LIST_NAME = "ABC123";

    private static final String LIST_ITEM_ID = "85f53f7e-b047-45f8-a66d-7914abd1ced8";
    private static final String LIST_ITEM_ID2 = "75eb361f-d40e-438e-bf8e-da857b2ab1b2";
    private static final int LIST_ITEM_PRODUCT_ID = 654564;
    private static final String LIST_ITEM_PRODUCT_NAME = "Pancake mix";
    private static final int LIST_ITEM_QUANTITY = 1;
    private static final int LIST_ITEM_AVERAGE_SIZE = 1;
    private static final String LIST_ITEM_BRAND_NAME = "Pancake Parlour";
    private static final ProductListItemStatusEnum LIST_ITEM_STATUS = ProductListItemStatusEnum.CHECKED;
    private static final String LIST_ITEM_UNIT_OF_MEASURE = "ea";
    private static final String PROFILE_ID = "abc123";
    private static final boolean LIST_ISPREFERRED = true;
    private static final String LIST_PERMISSIONS = "owner";
    private static final String LIST_CREATEDBY = "tester";
    private static final LocalDateTime LIST_CREATED = LocalDateTime.of(2020, 1, 2, 14, 0);
    private static final LocalDateTime LIST_LASTUPDATED = LocalDateTime.of(2020, 1, 2, 14, 0);

    @Before
    public void init() throws Exception {
    }

    @Test
    public void testGetProductListItems() {
        ProductListGroup.ProductList list = ProductListGroup.ProductList.builder()
                .listId(LIST_ID)
                .type(LIST_TYPE)
                .created(LIST_CREATED)
                .lastUpdated(LIST_LASTUPDATED)
                .isPreferred(LIST_ISPREFERRED)
                .permissions(LIST_PERMISSIONS)
                .createdBy(LIST_CREATEDBY)
                .build();

        ProductListGroup productListGroup = ProductListGroup.builder()
                .profileId(PROFILE_ID)
                .productLists(Arrays.asList(list))
                .build();

        ProductListItemGroup.ListItem productListItem = ProductListItemGroup.ListItem.builder()
                .productId(LIST_ITEM_PRODUCT_ID)
                .productName(LIST_ITEM_PRODUCT_NAME)
                .averageSize(LIST_ITEM_AVERAGE_SIZE)
                .brandName(LIST_ITEM_BRAND_NAME)
                .lastUpdated(LIST_LASTUPDATED)
                .quantity(LIST_ITEM_QUANTITY)
                .status(LIST_ITEM_STATUS)
                .unitOfMeasure(LIST_ITEM_UNIT_OF_MEASURE)
                .build();

        ProductListItemGroup itemGroup = ProductListItemGroup.builder()
                .listId(LIST_ID)
                .listName(LIST_NAME)
                .listType(LIST_TYPE)
                .listItems(Collections.singletonList(productListItem))
                .build();

        when(mockedProductListItemGroupRepo.findById(anyString())).thenReturn(Mono.just(itemGroup));
        when(mockedProductListGroupRepo.findById(anyString())).thenReturn(Mono.just(productListGroup));

        ProductListItemResponse productListItemResponse = serviceUnderTest.getProductListItems(PROFILE_ID, LIST_ID).block();
        assertThat(productListItemResponse.getListId()).isEqualTo(LIST_ID);
        assertThat(productListItemResponse.getItems().get(0).getAverageSize()).isEqualTo(LIST_ITEM_AVERAGE_SIZE);
        assertThat(productListItemResponse.getItems().get(0).getBrandName()).isEqualTo(LIST_ITEM_BRAND_NAME);
        assertThat(productListItemResponse.getItems().get(0).getLastUpdated()).isEqualTo(LIST_LASTUPDATED);
        assertThat(productListItemResponse.getItems().get(0).getProductId()).isEqualTo(LIST_ITEM_PRODUCT_ID);
        assertThat(productListItemResponse.getItems().get(0).getProductName()).isEqualTo(LIST_ITEM_PRODUCT_NAME);
        assertThat(productListItemResponse.getItems().get(0).getQuantity()).isEqualTo(LIST_ITEM_QUANTITY);
        assertThat(productListItemResponse.getItems().get(0).getStatus()).isEqualTo(LIST_ITEM_STATUS);
        assertThat(productListItemResponse.getItems().get(0).getUnitOfMeasure()).isEqualTo(LIST_ITEM_UNIT_OF_MEASURE);
    }

    @Test
    public void testGetProductListItems_ReturnEmptyResponseWhenNoListItemsFound() {
        ProductListGroup.ProductList list = ProductListGroup.ProductList.builder()
                .listId(LIST_ID)
                .type(LIST_TYPE)
                .created(LIST_CREATED)
                .lastUpdated(LIST_LASTUPDATED)
                .isPreferred(LIST_ISPREFERRED)
                .permissions(LIST_PERMISSIONS)
                .createdBy(LIST_CREATEDBY)
                .build();

        ProductListGroup productListGroup = ProductListGroup.builder()
                .profileId(PROFILE_ID)
                .productLists(Arrays.asList(list))
                .build();

        ProductListItemGroup itemGroup = ProductListItemGroup.builder()
                .listId(LIST_ID)
                .listName(LIST_NAME)
                .listType(LIST_TYPE)
                .listItems(new ArrayList<>())
                .build();

        when(mockedProductListItemGroupRepo.findById(anyString())).thenReturn(Mono.just(itemGroup));
        when(mockedProductListGroupRepo.findById(anyString())).thenReturn(Mono.just(productListGroup));

        ProductListItemResponse productListItemResponse = serviceUnderTest.getProductListItems(PROFILE_ID, LIST_ID).block();
        assertThat(productListItemResponse.getItems()).isEmpty();
    }

    private ProductListItemDeleteRequest setupDeleteItemsTest(){
        ProductListGroup.ProductList list = ProductListGroup.ProductList.builder()
                .listId(LIST_ID)
                .type(LIST_TYPE)
                .created(LIST_CREATED)
                .lastUpdated(LIST_LASTUPDATED)
                .isPreferred(LIST_ISPREFERRED)
                .permissions(LIST_PERMISSIONS)
                .createdBy(LIST_CREATEDBY)
                .build();

        ProductListGroup productListGroup = ProductListGroup.builder()
                .profileId(PROFILE_ID)
                .productLists(Arrays.asList(list))
                .build();

        ProductListItemGroup.ListItem productListItem = ProductListItemGroup.ListItem.builder()
                .productId(LIST_ITEM_PRODUCT_ID)
                .productName(LIST_ITEM_PRODUCT_NAME)
                .averageSize(LIST_ITEM_AVERAGE_SIZE)
                .brandName(LIST_ITEM_BRAND_NAME)
                .lastUpdated(LIST_LASTUPDATED)
                .quantity(LIST_ITEM_QUANTITY)
                .status(LIST_ITEM_STATUS)
                .unitOfMeasure(LIST_ITEM_UNIT_OF_MEASURE)
                .listItemId(LIST_ITEM_ID)
                .build();

        ProductListItemGroup itemGroup = ProductListItemGroup.builder()
                .listId(LIST_ID)
                .listName(LIST_NAME)
                .listType(LIST_TYPE)
                .listItems(new ArrayList<>(Arrays.asList(productListItem)))
                .build();

        when(mockedProductListItemGroupRepo.findById(anyString())).thenReturn(Mono.just(itemGroup));
        when(mockedProductListGroupRepo.findById(anyString())).thenReturn(Mono.just(productListGroup));
        return ProductListItemDeleteRequest.builder().listItemId(Arrays.asList(LIST_ITEM_ID)).build();
    }

    private List<CreateProductListItemRequest> setCreateAddToShoppingListTest(){
        List<CreateProductListItemRequest> request = Arrays.asList(CreateProductListItemRequest.builder()
                .brandName(BRAND_NAME)
                .productName(PRODUCT_NAME)
                .productId(PRODUCT_ID)
                .averageSize(AVERAGE_SIZE)
                .unitOfMeasure(UNIT_OF_MEASURE)
                .quantity(QUANTITY)
                .build());

        ProductListItemGroup productListItemGroup =
                ProductListItemGroup.builder()
                        .listId(LIST_ID)
                        .listName(LIST_NAME)
                        .listType(LIST_TYPE)
                        .listItems(new ArrayList<>())
                        .build();

        when(mockedProductListItemGroupRepo.findById(anyString())).thenReturn(Mono.just(productListItemGroup));
        return request;
    }

    public List<UpdateProductListItemRequest> setupUpdateProductListItem(){
        List<UpdateProductListItemRequest> request = Arrays.asList(UpdateProductListItemRequest.builder()
                .listItemId(LIST_ITEM_ID)
                .quantity(QUANTITY2)
                .status(STATUS2)
                .build());

        ProductListItemGroup productListItemGroup =
                ProductListItemGroup.builder()
                        .listId(LIST_ID)
                        .listName(LIST_NAME)
                        .listType(LIST_TYPE)
                        .listItems(Arrays.asList(
                                ProductListItemGroup.ListItem.builder()
                                        .listItemId(LIST_ITEM_ID)
                                        .brandName(BRAND_NAME)
                                        .productName(PRODUCT_NAME)
                                        .productId(PRODUCT_ID)
                                        .averageSize(AVERAGE_SIZE)
                                        .unitOfMeasure(UNIT_OF_MEASURE)
                                        .quantity(QUANTITY)
                                        .status(STATUS)
                                        .created(LocalDateTime.now())
                                        .lastUpdated(LocalDateTime.now())
                                        .build()
                        )).build();

        when(mockedProductListItemGroupRepo.findById(anyString())).thenReturn(Mono.just(productListItemGroup));
        return request;
    }

    @Test
    public void testDeleteProductListGroup() {
        ProductListGroup.ProductList list = ProductListGroup.ProductList.builder()
                .listId(LIST_ID)
                .type(LIST_TYPE)
                .created(LIST_CREATED)
                .lastUpdated(LIST_LASTUPDATED)
                .isPreferred(LIST_ISPREFERRED)
                .permissions(LIST_PERMISSIONS)
                .createdBy(LIST_CREATEDBY)
                .build();

        ProductListGroup productListGroup = ProductListGroup.builder()
                .profileId(PROFILE_ID)
                .productLists(Arrays.asList(list))
                .build();

        ProductListItemGroup.ListItem productListItem = ProductListItemGroup.ListItem.builder()
                .productId(LIST_ITEM_PRODUCT_ID)
                .productName(LIST_ITEM_PRODUCT_NAME)
                .averageSize(LIST_ITEM_AVERAGE_SIZE)
                .brandName(LIST_ITEM_BRAND_NAME)
                .lastUpdated(LIST_LASTUPDATED)
                .quantity(LIST_ITEM_QUANTITY)
                .status(LIST_ITEM_STATUS)
                .unitOfMeasure(LIST_ITEM_UNIT_OF_MEASURE)
                .listItemId(LIST_ITEM_ID)
                .build();

        ProductListItemGroup itemGroup = ProductListItemGroup.builder()
                .listId(LIST_ID_II)
                .listName(LIST_NAME)
                .listType(LIST_TYPE)
                .listItems(new ArrayList<>(Arrays.asList(productListItem)))
                .build();

        when(mockedProductListGroupRepo.findById(anyString())).thenReturn(Mono.just(productListGroup));
        when(mockedProductListGroupRepo.delete(any())).thenReturn(Mono.empty());
        when(mockedProductListItemGroupRepo.deleteById(anyString(), any())).thenReturn(Mono.empty());

        boolean result = serviceUnderTest.deleteProductListGroup(PROFILE_ID).block();
        verify(mockedProductListItemGroupRepo, times(1)).deleteById(anyString(), any());
        verify(mockedProductListGroupRepo, times(1)).findById(anyString());
        verify(mockedProductListGroupRepo, times(1)).delete(any());
        assertThat(result).isTrue();
    }

    @Test
    public void testUpdateProductListItemGroup() {
        ProductListGroup.ProductList productList = ProductListGroup.ProductList.builder()
                .listId(LIST_ID)
                .type(LIST_TYPE)
                .created(LIST_CREATED)
                .lastUpdated(LIST_LASTUPDATED)
                .isPreferred(LIST_ISPREFERRED)
                .permissions(LIST_PERMISSIONS)
                .colour("BLUE")
                .disabled(false)
                .createdBy(LIST_CREATEDBY)
                .build();

        ProductListGroup productListGroup = ProductListGroup.builder()
                .profileId(PROFILE_ID)
                .productLists(Arrays.asList(productList))
                .build();

        ProductListItemGroup.ListItem productListItem = ProductListItemGroup.ListItem.builder()
                .productId(LIST_ITEM_PRODUCT_ID)
                .productName(LIST_ITEM_PRODUCT_NAME)
                .averageSize(LIST_ITEM_AVERAGE_SIZE)
                .brandName(LIST_ITEM_BRAND_NAME)
                .lastUpdated(LIST_LASTUPDATED)
                .quantity(LIST_ITEM_QUANTITY)
                .status(LIST_ITEM_STATUS)
                .unitOfMeasure(LIST_ITEM_UNIT_OF_MEASURE)
                .build();

        ProductListItemGroup itemGroup = ProductListItemGroup.builder()
                .listId(LIST_ID)
                .listName(LIST_NAME)
                .listType(LIST_TYPE)
                .listItems(Collections.singletonList(productListItem))
                .build();

        UpdateProductList updateProductListRequest =  UpdateProductList.builder()
                .listName("DummyList")
                .colour("RED")
                .disable(true)
                .build();

        ProductListResponse expectedProductListResponse =  ProductListResponse.builder()
                .listId("123")
                .listName("DummyList")
                .type(ProductListType.SHOPPING_LIST)
                .lastUpdated(LocalDateTime.now())
                .isPreferred(true)
                .isDisabled(true)
                .colour("RED")
                .build();

        when(mockedProductListGroupRepo.findById(anyString())).thenReturn(Mono.just(productListGroup));
        when(mockedProductListItemGroupRepo.findById(anyString())).thenReturn(Mono.just(itemGroup));
        when(mockedProductListItemGroupRepo.save(any(ProductListItemGroup.class))).thenReturn(Mono.empty());
        when(mockedProductListGroupRepo.save(any(ProductListGroup.class))).thenReturn(Mono.empty());

        Mono<ProductListResponse> response = serviceUnderTest.updateProductListItemGroup(PROFILE_ID, "test", updateProductListRequest);
        assertThat(response.block()).isInstanceOf(ProductListResponse.class);
        assertThat(response.block().getListId()).isEqualTo("123");
        assertThat(response.block().getListName()).isEqualTo("DummyList");
        assertThat(response.block().getColour()).isEqualTo("RED");
        assertThat(response.block().isPreferred()).isEqualTo(true);
        assertThat(response.block().isDisabled()).isEqualTo(true);
        assertThat(response.block().getType()).isEqualTo(ProductListType.SHOPPING_LIST);
        verify(mockedProductListItemGroupRepo, atLeast(1)).save(any(ProductListItemGroup.class));
        verify(mockedProductListGroupRepo,atLeast(1)).save(any(ProductListGroup.class));
    }

    @Test
    public void testUpdateProductListItemGroup_ThrowExceptionForAllRequestParamsNull() {
        ProductListGroup.ProductList productList = ProductListGroup.ProductList.builder()
                .listId(LIST_ID)
                .type(LIST_TYPE)
                .created(LIST_CREATED)
                .lastUpdated(LIST_LASTUPDATED)
                .isPreferred(LIST_ISPREFERRED)
                .permissions(LIST_PERMISSIONS)
                .colour("BLUE")
                .disabled(false)
                .createdBy(LIST_CREATEDBY)
                .build();

        ProductListGroup productListGroup = ProductListGroup.builder()
                .profileId(PROFILE_ID)
                .productLists(Arrays.asList(productList))
                .build();

        ProductListItemGroup.ListItem productListItem = ProductListItemGroup.ListItem.builder()
                .productId(LIST_ITEM_PRODUCT_ID)
                .productName(LIST_ITEM_PRODUCT_NAME)
                .averageSize(LIST_ITEM_AVERAGE_SIZE)
                .brandName(LIST_ITEM_BRAND_NAME)
                .lastUpdated(LIST_LASTUPDATED)
                .quantity(LIST_ITEM_QUANTITY)
                .status(LIST_ITEM_STATUS)
                .unitOfMeasure(LIST_ITEM_UNIT_OF_MEASURE)
                .build();

        ProductListItemGroup itemGroup = ProductListItemGroup.builder()
                .listId(LIST_ID)
                .listName(LIST_NAME)
                .listType(LIST_TYPE)
                .listItems(Collections.singletonList(productListItem))
                .build();

        UpdateProductList updateProductListRequest =  UpdateProductList.builder()
                .listName(null)
                .colour(null)
                .disable(null)
                .build();

        ProductListResponse expectedProductListResponse =  ProductListResponse.builder()
                .listId("123")
                .listName("DummyList")
                .type(ProductListType.SHOPPING_LIST)
                .lastUpdated(LocalDateTime.now())
                .isPreferred(true)
                .isDisabled(true)
                .colour("RED")
                .build();

        when(mockedProductListGroupRepo.findById(anyString())).thenReturn(Mono.just(productListGroup));
        when(mockedProductListItemGroupRepo.findById(anyString())).thenReturn(Mono.just(itemGroup));
        when(mockedProductListItemGroupRepo.save(any(ProductListItemGroup.class))).thenReturn(Mono.empty());
        when(mockedProductListGroupRepo.save(any(ProductListGroup.class))).thenReturn(Mono.empty());

        Mono<ProductListResponse> response = serviceUnderTest.updateProductListItemGroup(PROFILE_ID, "test", updateProductListRequest);
        var exception = org.junit.jupiter.api.Assertions.assertThrows(PayloadValidationException.class, response::block);

        assertThat(exception).isInstanceOf(PayloadValidationException.class);
        assertThat(exception.getHttpStatus()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(exception.getProperties()).isNotEmpty();
        assertThat(exception.getProperties().get("name")).isEqualTo("colour,disable,listname");
        assertThat(exception.getProperties().get("value")).isEqualTo("null");
        verify(mockedProductListGroupRepo, times(1)).findById(anyString());
        verify(mockedProductListGroupRepo, times(1)).findById(anyString());
        verify(mockedProductListGroupRepo, times(0)).save(any());
        verify(mockedProductListItemGroupRepo, times(0)).save(any());

    }
}
