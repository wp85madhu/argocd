package au.com.coles.productlistapi.integrationTest;

import au.com.coles.productlistapi.repository.ProductListGroupRepository;
import au.com.coles.productlistapi.repository.ProductListItemGroupRepository;
import au.com.coles.productlistapi.repository.model.ProductListGroup;
import au.com.coles.productlistapi.repository.model.ProductListItemGroup;
import au.com.coles.productlistapi.repository.model.ProductListType;
import au.com.coles.productlistapi.service.ProductListService;
import au.com.coles.productlistapi.service.model.RetrieveProductListRequestDTO;
import au.com.coles.productlistapi.service.model.RetrieveProductListResponseDTO;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.Assert.assertTrue;

import org.springframework.test.context.ActiveProfiles;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.File;
import java.util.List;

@Disabled
@ActiveProfiles("integration")
@SpringBootTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class ProductListServiceIntegrationTest {
    private static final String MOCKPRODUCTLISTGROUP_JSON = "abc123-test.json";
    private static final String MOCKPRODUCTLISTITEMGROUP_JSON = "item123.json";
    private static final String PROFILE_ID = "abc123_integrationTest";
    private static final ProductListType LIST_TYPE = ProductListType.SHOPPING_LIST;
    private static final String LIST_ID1 = "listId1";

    @Autowired
    private ProductListGroupRepository productListGroupRepo;

    @Autowired
    private ProductListItemGroupRepository productListItemGroupRepo;


    private ProductListService productListService;

    private ObjectMapper objectMapper = new ObjectMapper();

    @BeforeAll
    public void init() throws Exception{
        productListService = new ProductListService(productListGroupRepo, productListItemGroupRepo);
        assertTrue(setupCosmosDBProductList());
    }

    @AfterAll
    public void cleanUp() throws Exception{
        clearCosmosDBProductList();
    }

    @Test
    public void getProductList_shouldFetchProductListsFromCosmosDBByType() {
        RetrieveProductListRequestDTO request = RetrieveProductListRequestDTO.builder()
                                    .profileId(PROFILE_ID).type(LIST_TYPE).build();
        Mono<List<RetrieveProductListResponseDTO>> response = productListService.getProductList(request);
        StepVerifier.create(response)
                    .expectNextMatches(r -> r.size()==1 && r.get(0).getListId().equals(LIST_ID1))
                    .expectComplete()
                    .verify();
    }

    @Test
    public void getProductList_shouldFetchProductListsFromCosmosDBById() {

    }

    private ProductListGroup createMockProductListGroup(String jsonFile) throws Exception{
        File payLoadFile = new File(getClass().getClassLoader().getResource(jsonFile).getFile());
        ProductListGroup listGroup = objectMapper.readValue(payLoadFile, ProductListGroup.class);
        return listGroup;
    }

    private ProductListItemGroup createMockProductListItemGroup(String jsonFile) throws Exception{
        File payLoadFile = new File(getClass().getClassLoader().getResource(jsonFile).getFile());
        ProductListItemGroup itemGroup = objectMapper.readValue(payLoadFile, ProductListItemGroup.class);
        return itemGroup;
    }

    private boolean setupCosmosDBProductList() throws Exception{
        ProductListGroup ListResponse = productListGroupRepo.save(createMockProductListGroup(MOCKPRODUCTLISTGROUP_JSON)).block();
        ProductListItemGroup itemResponse = productListItemGroupRepo.save(createMockProductListItemGroup(MOCKPRODUCTLISTITEMGROUP_JSON)).block();
        return ListResponse != null && itemResponse != null;
    }

    private void clearCosmosDBProductList() throws Exception{
        productListGroupRepo.delete(createMockProductListGroup(MOCKPRODUCTLISTGROUP_JSON)).block();
        productListItemGroupRepo.delete(createMockProductListItemGroup(MOCKPRODUCTLISTITEMGROUP_JSON)).block();
    }
}
