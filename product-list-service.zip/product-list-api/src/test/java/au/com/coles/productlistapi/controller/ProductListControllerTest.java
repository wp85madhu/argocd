package au.com.coles.productlistapi.controller;

import au.com.coles.platform.errorhandling.ErrorCodes;
import au.com.coles.platform.util.TraceUtil;
import au.com.coles.productlistapi.service.ProductListCreationService;
import au.com.coles.productlistapi.service.ProductListItemService;
import au.com.coles.productlistapi.service.ProductListService;
import au.com.coles.productlistapi.service.model.CreateProductListRequestDTO;
import au.com.coles.productlistapi.service.model.CreateProductListResponseDTO;
import au.com.coles.productlistapi.repository.model.ProductListType;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.reactive.function.BodyInserters;
import reactor.core.publisher.Mono;

import static org.mockito.Mockito.*;

@Disabled
@WebFluxTest(ProductListController.class)
public class ProductListControllerTest {

    @Autowired
    private WebTestClient webClient;

    @MockBean
    private ProductListCreationService mockedProductListCreationService;

    @MockBean
    private ProductListService mockedProductListService;

    @MockBean
    private ProductListItemService mockedProductListItemService;

    @MockBean
    private TraceUtil mockedTraceUtil;

    @MockBean
    private ErrorCodes mockedErrorCodes;

    private String createListEndpoint = "/products/lists";

    @Test
    public void givenHttpRequestToCreateProductList_whenRequestPayloadIsValid_thenReturnHttp201Response() {

        when(mockedProductListCreationService.createList(anyString(), any(CreateProductListRequestDTO.class)))
            .thenReturn(Mono.just(getCreateProductListResponseDTO()));
        String requestProfileId = "myprofileId";

        webClient.post()
                .uri(uriBuilder -> uriBuilder.path(createListEndpoint).queryParam("profileId", requestProfileId).build())
                .contentType(MediaType.APPLICATION_JSON)
                .body(BodyInserters.fromPublisher(Mono.just(getCreateProductListRequestDTO()), CreateProductListRequestDTO.class))
                .exchange()
                .expectStatus().isCreated()
                .expectBodyList(CreateProductListResponseDTO.class)
                .hasSize(1)
                .contains(getCreateProductListResponseDTO());

        verify(mockedProductListCreationService, atMostOnce()).createList(requestProfileId, getCreateProductListRequestDTO());
    }

    @Test
    public void givenHttpRequestToCreateProductList_whenRequestQueryParamIsInvalid_thenReturnHttp500Response() {

        String requestProfileId = "myprofileId";

        webClient.post()
                .uri(uriBuilder -> uriBuilder.path(createListEndpoint).queryParam("profileid", requestProfileId).build()) // profileid is lowercase 'i' - wrong
                .contentType(MediaType.APPLICATION_JSON)
                .body(BodyInserters.fromPublisher(Mono.just(getCreateProductListRequestDTO()), CreateProductListRequestDTO.class)) // valid body
                .exchange()
                .expectStatus()
                .isBadRequest();
    }

    @Test
    public void givenHttpRequestToCreateProductList_whenRequestBodyIsInvalid_thenReturnHttp500Response() {

        String requestProfileId = "myprofileId";

        webClient.post()
                .uri(uriBuilder -> uriBuilder.path(createListEndpoint).queryParam("profileid", requestProfileId).build()) // profileid is lowercase 'i' - wrong
                .contentType(MediaType.APPLICATION_JSON)
                .body(BodyInserters.fromPublisher(Mono.just("some invalid body"), String.class)) // invalid body
                .exchange()
                .expectStatus()
                .isBadRequest()         ;
    }

    @Test
    public void givenHttpRequestToCreateProductList_whenBackendServiceThrowsException_thenReturnHttp500Response() {

        when(mockedProductListCreationService.createList(anyString(), any(CreateProductListRequestDTO.class)))
                .thenThrow(RuntimeException.class);
        String requestProfileId = "myprofileId";

        webClient.post()
                .uri(uriBuilder -> uriBuilder.path(createListEndpoint).queryParam("profileId", requestProfileId).build())
                .contentType(MediaType.APPLICATION_JSON)
                .body(BodyInserters.fromPublisher(Mono.just(getCreateProductListRequestDTO()), CreateProductListRequestDTO.class))
                .exchange()
                .expectStatus()
                .is5xxServerError();
    }

    private CreateProductListRequestDTO getCreateProductListRequestDTO() {
        return CreateProductListRequestDTO.builder().listName("awesomelist").type(ProductListType.SHOPPING_LIST).isPreferred(Boolean.TRUE).build();
    }

    private CreateProductListResponseDTO getCreateProductListResponseDTO() {
        return CreateProductListResponseDTO.builder().listId("mylist123").listName("awesomelist").type(ProductListType.SHOPPING_LIST)
                .isPreferred(Boolean.TRUE).lastUpdated("2020-10-02T10:20:15").build();
    }

}
