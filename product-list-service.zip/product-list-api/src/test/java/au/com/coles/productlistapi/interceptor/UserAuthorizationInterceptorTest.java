package au.com.coles.productlistapi.interceptor;

import au.com.coles.UnitTest;
import au.com.coles.productlistapi.annotation.AllowedScope;
import au.com.coles.productlistapi.config.UserAuthProperties;
import com.auth0.jwk.Jwk;
import com.auth0.jwk.JwkProvider;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
@Category(UnitTest.class)
public class UserAuthorizationInterceptorTest {

    /*
     * Test consts
     */
    private static final String TEST_KID = "rfIgtKohPNdAi75kgD_40";
    private static final String TEST_AUD = "customer-services";
    private static final String TEST_ISS = "https://coles-dev.au.auth0.com/";
    private static final String TEST_JWK_URI = "https://coles-dev.au.auth0.com/.well-known/jwks.json";
    private static final String TEST_SCOPE = "read:profile";

    /**
     * Valid test token
     */
    private static String TEST_TOKEN = UserAuthorizationInterceptor.TOKEN_PREFIX +
            "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6InJmSWd0S29oUE5kQWk3NWtnRF80MCJ9.eyJodHRwczovL2NjcC9wcm9maWxlSWQiOiI5NTIxNTY4YS03YjIwLTQ4MmQtOWZlYS1iYWFmOGJlN2YxOTUiLCJpc3MiOiJodHRwczovL2NvbGVzLWRldi5hdS5hdXRoMC5jb20vIiwic3ViIjoiYXV0aDB8OTUyMTU2OGEtN2IyMC00ODJkLTlmZWEtYmFhZjhiZTdmMTk1IiwiYXVkIjpbImN1c3RvbWVyLXNlcnZpY2VzIiwiaHR0cHM6Ly9jb2xlcy1kZXYuYXUuYXV0aDAuY29tL3VzZXJpbmZvIl0sImlhdCI6MTYwMzA1ODA0MywiZXhwIjoxNjAzMTQ0NDQzLCJhenAiOiJuWTY5eGlmNzIyRzRvRzhNcEpZeUhwTnJuMzk5TlcxWCIsInNjb3BlIjoib3BlbmlkIHJlYWQ6cHJvZmlsZSBvZmZsaW5lX2FjY2VzcyJ9.GYhGZ0iZ_yoU6EtZc1oe7RUYAJDF6c6Ir41c5og-AadeM5lYl1gFBvJg2rOfQIQesHVGkUJRyfLZpdYrJNt6DEuY63sqDtDR4wynrJeM7OyUsr3I7yIPQOydv-AadhoSt8TuRUR6SDctw6vAnNlQtN4c5pvdDRHsZt5O6QnuDYGhcpaWC5X4aUUtR2jGc1UK4bWTf7_OeMNvaE1xvLd2pUuVjiLb1OlQi6SHShzXs3B6mio-ZO2VKlufnEYUSEsoY-LGioqvwFdPd0gWjwm_t5qjtZvmhN6rxDlUoZa39w73kClq7qvc24faTu3wxz8HBKsSNPHmrPlmPL5p-xKwWw";

    /**
     * Test token, already expired
     */
    private static final String TEST_TOKEN_EXPIRED = UserAuthorizationInterceptor.TOKEN_PREFIX
            + "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6InJmSWd0S29oUE5kQWk3NWtnRF80MCJ9.eyJodHRwczov" +
            "L2NjcC9wcm9maWxlSWQiOiI5NTIxNTY4YS03YjIwLTQ4MmQtOWZlYS1iYWFmOGJlN2YxOTUiLCJpc3MiOiJodHRwczov" +
            "L2NvbGVzLWRldi5hdS5hdXRoMC5jb20vIiwic3ViIjoiYXV0aDB8OTUyMTU2OGEtN2IyMC00ODJkLTlmZWEtYmFhZjhi" +
            "ZTdmMTk1IiwiYXVkIjoiY3VzdG9tZXItc2VydmljZXMiLCJpYXQiOjE2MDE0MjY4MjAsImV4cCI6MTYwMTUxMzIyMCwi" +
            "YXpwIjoiUVE0SUptd3c2aTdLWklXZTZRYVFTa0NqWVZ2QnNzckoiLCJzY29wZSI6InJlYWQ6cHJvZmlsZSByZWFkOnBy" +
            "ZWZlcmVuY2VzIHVwZGF0ZTpwYXNzd29yZCB1cGRhdGU6cHJvZmlsZSB1cGRhdGU6cHJlZmVyZW5jZXMiLCJndHkiOiJw" +
            "YXNzd29yZCJ9.NOmn7ChiaKyaf5T-wWhHjqcJAPqyWubzyiXsAqc2PldsXeJB2DGdGkwgp_b2ePXEZyCBotNR2pwCz8m" +
            "kpR9xhA_8cfSAuGWWAh3L7DIUfIB09w95tFtL2Nl8tCSbBFYC0cMV16PYq70cCRtIOv3WhUCF2kOiNcA4ZAE7CzS8vLF" +
            "-nnFiGOImcqiRn8oS8rCw9L-fO4vXwHO-WfAtSA3kDZvWsDmaGt1-s8E3rw-dYwsqtRkOS8nKdsXWZ6PNgXBKh3CoQF-" +
            "Jdxa1KX3r1CVxD2EIw_ll8Ruv8mgoun3ln3kVjUUdM-KYczEPkLKqoPrwh97XRw-B20sIjx6GRKESvQ";

    /**
     * Public key used by both test tokens
     */
    private static String TEST_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyKxiMXx31f" +
            "XewX+I9x9cqTkHlPV/vYrq9PtID6Yg186hVJ5zPA0hByMmwLKKS5JMhbLvs9K/RxB9TwuE6GIRraG4hVmCMyf8m5xuXV" +
            "lrEJ4pFftCjpgX1p48T8CA+Zl40s57QsIjSz58gJP2POMk8i8OX1CvzQU1rWcCbJSZ8hZ9nbMvpXuILJsZCSF3Kndn97" +
            "XjKWVBZa6f9yCO4doUJNAGQKlHNp1ayx33SnEehg/oM/RzoDJgW4yfNaQtycmNLdPPRQjEXegV7SQ6wQmxwV7UpY/DzI" +
            "dnkgWVh/UBYghSjRCM8ueHsn5UzVtv4XvzsYsR4QJfp2b7D4hECIiIEwIDAQAB";

    /**
     * Public key used by both test tokens
     */
    private static String TEST_PUBLIC_KEY_EXPIRED = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyKxiMXx31f" +
            "XewX+I9x9cqTkHlPV/vYrq9PtID6Yg186hVJ5zPA0hByMmwLKKS5JMhbLvs9K/RxB9TwuE6GIRraG4hVmCMyf8m5xuXV" +
            "lrEJ4pFftCjpgX1p48T8CA+Zl40s57QsIjSz58gJP2POMk8i8OX1CvzQU1rWcCbJSZ8hZ9nbMvpXuILJsZCSF3Kndn97" +
            "XjKWVBZa6f9yCO4doUJNAGQKlHNp1ayx33SnEehg/oM/RzoDJgW4yfNaQtycmNLdPPRQjEXegV7SQ6wQmxwV7UpY/DzI" +
            "dnkgWVh/UBYghSjRCM8ueHsn5UzVtv4XvzsYsR4QJfp2b7D4hECIiIEwIDAQAB";


    @Mock
    private HttpServletRequest request;

    @Mock
    private HttpServletResponse response;

    @Mock
    private JwkProvider jwkProvider;

    @Spy
    private UserAuthProperties userAuthProperties = new UserAuthProperties();

    @Spy
    @InjectMocks
    private UserAuthorizationInterceptor unitUnderTest;

    @Autowired
    private RequestMappingHandlerMapping handlerMapping;


    @BeforeClass
    public static void globalSetUp() throws Exception {
        Map<String, Object> rsaKeys = null;

        rsaKeys = getRSAKeys();

        PublicKey publicKey = (PublicKey) rsaKeys.get("public");

        PrivateKey privateKey = (PrivateKey) rsaKeys.get("private");

        TEST_TOKEN = UserAuthorizationInterceptor.TOKEN_PREFIX + generateToken(privateKey);

        TEST_PUBLIC_KEY = Base64.getEncoder().encodeToString(publicKey.getEncoded());

    }

    @Before
    public void setUp() {
        userAuthProperties.setEnabled(true);
        userAuthProperties.setIss(TEST_ISS);
        userAuthProperties.setJwkUri(TEST_JWK_URI);
    }

    @Test
    public void testValidToken() throws Exception {

        Mockito.when(request.getHeader(ArgumentMatchers.eq(UserAuthorizationInterceptor.AUTH_HEADER))).thenReturn(TEST_TOKEN);

        Jwk jwt = mock(Jwk.class);

        Mockito.when(jwkProvider.get(ArgumentMatchers.eq(TEST_KID))).thenReturn(jwt);

        Mockito.when(jwt.getPublicKey()).thenReturn(getPublicKey(TEST_PUBLIC_KEY));

        HandlerMethod handlerMethod = mock(HandlerMethod.class, "handlerMethod");

        Method method = getClass().getDeclaredMethod("mockControllerMethod");
        Mockito.when(handlerMethod.getMethod()).thenReturn(method);

        Map<String, Object> attributes = new HashMap<String, Object>();
        // Mock setAttribute
        Mockito.doAnswer(new Answer<Void>() {
            @Override
            public Void answer(InvocationOnMock invocation) throws Throwable {
                String key = invocation.getArgument(0, String.class);
                Object value = invocation.getArgument(1, Object.class);
                attributes.put(key, value);
                return null;
            }
        }).when(request).setAttribute(Mockito.anyString(), Mockito.anyObject());

        Boolean result  = unitUnderTest.preHandle(request, response, handlerMethod);

        assertTrue(result);

        // Mock getAttribute
        Mockito.doAnswer(new Answer<Object>() {
            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {
                String key = invocation.getArgument(0, String.class);
                Object value = attributes.get(key);
                return value;
            }
        }).when(request).getAttribute(Mockito.anyString());

        assertEquals(request.getAttribute("profileId"), "f9570c74-ba42-4d6b-ae66-1f76e9187447");
    }

    @Test
    public void testExpired() throws Exception {

        when(request.getHeader(ArgumentMatchers.eq(UserAuthorizationInterceptor.AUTH_HEADER))).thenReturn(TEST_TOKEN_EXPIRED);

        Jwk jwt = mock(Jwk.class);

        when(jwkProvider.get(ArgumentMatchers.eq(TEST_KID))).thenReturn(jwt);

        when(jwt.getPublicKey()).thenReturn(getPublicKey(TEST_PUBLIC_KEY_EXPIRED));

        HandlerMethod handlerMethod = mock(HandlerMethod.class, "handlerMethod");

        Method method = getClass().getDeclaredMethod("mockControllerMethod");
        when(handlerMethod.getMethod()).thenReturn(method);

        Boolean result = unitUnderTest.preHandle(request, response, handlerMethod);

        assertFalse(result);

    }

    @Test
    public void testInvalidScopeClaim() throws Exception {
        when(request.getHeader(ArgumentMatchers.eq(UserAuthorizationInterceptor.AUTH_HEADER))).thenReturn(TEST_TOKEN);

        Jwk jwt = mock(Jwk.class);

        when(jwkProvider.get(ArgumentMatchers.eq(TEST_KID))).thenReturn(jwt);

        when(jwt.getPublicKey()).thenReturn(getPublicKey(TEST_PUBLIC_KEY));

        HandlerMethod handlerMethod = mock(HandlerMethod.class, "handlerMethod");

        Method method = getClass().getDeclaredMethod("mockInvalidScopeControllerMethod");
        when(handlerMethod.getMethod()).thenReturn(method);

        Boolean result = unitUnderTest.preHandle(request, response, handlerMethod);

        assertFalse(result);
    }


    @AllowedScope("read:profile")
    public String mockControllerMethod() {
        return "OK";
    }

    @AllowedScope("read:preferences")
    public String mockInvalidScopeControllerMethod() {
        return "OK";
    }

    /**
     * Returns the PublicKey generated from the given string.
     *
     * @param key the string representation of the string.
     *
     * @return PublicKey the Pub
     *
     * @throws InvalidKeySpecException
     * @throws NoSuchAlgorithmException
     */
    private PublicKey getPublicKey(String key) throws InvalidKeySpecException, NoSuchAlgorithmException {
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(key));
        KeyFactory factory = KeyFactory.getInstance("RSA");

        return factory.generatePublic(keySpec);
    }

    /**
     * This is helper method that generates a valid JWT token that expires in 24 hours
     * @param privateKey
     * @return
     */
    private static String generateToken(PrivateKey privateKey) {
        String token;

        Map<String, Object> claims = new HashMap<String, Object>();
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.HOUR, 24);
        Date tomorrow = calendar.getTime();

        claims.put("https://ccp/profileId", "f9570c74-ba42-4d6b-ae66-1f76e9187447");
        claims.put("iss", TEST_ISS);
        claims.put("sub", "auth0|f9570c74-ba42-4d6b-ae66-1f76e9187447");
        claims.put("aud", TEST_AUD);
        claims.put("iat", (new Date()).getTime()/1000L);
        claims.put("exp", tomorrow.getTime()/1000L);
        claims.put("scope", TEST_SCOPE);

        Map<String,Object> headerMap = new HashMap<>();
        headerMap.put("kid",TEST_KID);
        headerMap.put("typ","JWT");
        token = Jwts.builder()
                .setClaims(claims)
                .signWith(SignatureAlgorithm.RS256, privateKey)
                .setHeader(headerMap)
                .compact();

        return token;
    }

    /**
     * This is a helper method that return RSA Public and Private Keys for creating JWT Token
     * @return
     * @throws Exception
     */
    private static  Map<String, Object> getRSAKeys() throws Exception {
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(2048);
        KeyPair keyPair = keyPairGenerator.generateKeyPair();
        PrivateKey privateKey = keyPair.getPrivate();
        PublicKey publicKey = keyPair.getPublic();
        Map<String, Object> keys = new HashMap<String, Object>();
        keys.put("private", privateKey);
        keys.put("public", publicKey);
        return keys;
    }
}
