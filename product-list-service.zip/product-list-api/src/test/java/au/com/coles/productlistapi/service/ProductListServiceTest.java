package au.com.coles.productlistapi.service;

import au.com.coles.productlistapi.dto.ProductListResponse;
import au.com.coles.productlistapi.repository.ProductListGroupRepository;
import au.com.coles.productlistapi.repository.ProductListItemGroupRepository;
import au.com.coles.productlistapi.repository.model.ProductListGroup;
import au.com.coles.productlistapi.repository.model.ProductListItemGroup;
import au.com.coles.productlistapi.repository.model.ProductListType;
import au.com.coles.productlistapi.service.model.RetrieveProductListRequestDTO;
import au.com.coles.productlistapi.service.model.RetrieveProductListResponseDTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ProductListServiceTest {

    @InjectMocks
    private ProductListService serviceUnderTest;

    @Mock
    private ProductListGroupRepository mockedProductListGroupRepo;

    @Mock
    private ProductListItemGroupRepository mockedProductListItemGroupRepo;

    private static final String PROFILE_ID = "abc123";
    private static final String LIST_ID = "123";
    private static final ProductListType LIST_TYPE = ProductListType.SHOPPING_LIST;
    private static final String LIST_NAME = "ABC123";
    private static final boolean LIST_ISPREFERRED = true;
    private static final String LIST_PERMISSIONS = "owner";
    private static final String LIST_CREATEDBY = "tester";
    private static final LocalDateTime LIST_CREATED = LocalDateTime.of(2020, 1, 2, 14, 0);
    private static final LocalDateTime LIST_LASTUPDATED = LocalDateTime.of(2020, 1, 2, 14, 0);

    @Test
    public void testGetProductList() {
        String profileId = "abc123";
        String listId = "123";
        String listName = "list123";
        var type = ProductListType.SHOPPING_LIST;
        LocalDateTime localDateTime = LocalDateTime.now();
        ProductListGroup productListGroup = ProductListGroup.builder().profileId(profileId).productLists(
                Arrays.asList(
                        ProductListGroup.ProductList.builder().listId(listId).type(type)
                                .created(LocalDateTime.now()).lastUpdated(localDateTime).isPreferred(true)
                                .permissions("default").createdBy("admin").build()
                )
        ).build();
        ProductListItemGroup productListItemGroup =
                ProductListItemGroup.builder().listId(listId).listName(listName).listType(type).build();
        when(mockedProductListGroupRepo.findById(anyString())).thenReturn(Mono.just(productListGroup));
        when(mockedProductListItemGroupRepo.findById(anyString())).thenReturn(Mono.just(productListItemGroup));
        ProductListResponse expectedProductListResponse = ProductListResponse.builder()
                .listId(listId)
                .listName(listName)
                .type(type)
                .isPreferred(true)
                .lastUpdated(localDateTime)
                .build();
        ProductListResponse productListResponse = serviceUnderTest.getProductList(profileId, listId).block();
        assertThat(expectedProductListResponse).isEqualTo(productListResponse);
    }

    @Test
    public void testGetProductList_ReturnEmptyResponseWhenMatchingListNotFound() {
        String profileId = "abc123";
        String listId = "123";
        when(mockedProductListGroupRepo.findById(anyString())).thenReturn(Mono.empty());
        when(mockedProductListItemGroupRepo.findById(anyString())).thenReturn(Mono.empty());
        Mono<ProductListResponse> actualResponse = serviceUnderTest.getProductList(profileId, listId);
        assertThat(actualResponse.block()).isEqualTo(null);
    }

    public void givenRequestToCreateProductList_whenRequestPayloadIsValidAndNoListFoundInRepo_thenCreateANewListInRepo() {
        when(mockedProductListGroupRepo.findById(anyString())).thenReturn(Mono.empty());

    }

    private ProductListGroup createExpectedProductListGroup() {
        String dummyDateTime = "2020-10-02T10:20:15";
        String profileId = "abc123";
        ProductListGroup.ProductList productList = ProductListGroup.ProductList.builder().type(ProductListType.SHOPPING_LIST).listId("12345678")
                .created(LocalDateTime.parse(dummyDateTime)).lastUpdated(LocalDateTime.parse(dummyDateTime)).isPreferred(Boolean.TRUE)
                .permissions("owner").createdBy(profileId).build();
        return ProductListGroup.builder().profileId(profileId).productLists(Arrays.asList(productList)).build();
    }

    @Test
    public void testGetProductListByType() {
        ProductListGroup.ProductList list = ProductListGroup.ProductList.builder()
                .listId(LIST_ID)
                .type(LIST_TYPE)
                .created(LIST_CREATED)
                .lastUpdated(LIST_LASTUPDATED)
                .isPreferred(LIST_ISPREFERRED)
                .permissions(LIST_PERMISSIONS)
                .createdBy(LIST_CREATEDBY)
                .build();
        ProductListGroup group = new ProductListGroup().builder()
                .productLists(Arrays.asList(list))
                .build();
        when(mockedProductListGroupRepo.findById(anyString()))
                .thenReturn(Mono.just(group));

        ProductListItemGroup itemGroup = ProductListItemGroup.builder()
                .listId(LIST_ID)
                .listName(LIST_NAME)
                .listType(LIST_TYPE)
                .build();
        when(mockedProductListItemGroupRepo.findByListIdIn(any()))
                .thenReturn(Flux.just(itemGroup));

        List<RetrieveProductListResponseDTO> responseDTOs = serviceUnderTest.getProductList(new RetrieveProductListRequestDTO(PROFILE_ID, LIST_TYPE)).block();
        assertEquals(1, responseDTOs.size());
        assertEquals(LIST_ID, responseDTOs.get(0).getListId());
        assertEquals(LIST_NAME, responseDTOs.get(0).getListName());
        assertEquals(LIST_TYPE, responseDTOs.get(0).getType());
        assertEquals(LIST_LASTUPDATED, responseDTOs.get(0).getLastUpdated());
        assertEquals(LIST_ISPREFERRED, responseDTOs.get(0).isPreferred());
    }

    @Test
    public void testGetProductListByTypeIfNoMatch() {
        when(mockedProductListGroupRepo.findById(anyString()))
                .thenReturn(Mono.empty());

        List<RetrieveProductListResponseDTO> dtos = serviceUnderTest.getProductList(new RetrieveProductListRequestDTO(PROFILE_ID, LIST_TYPE)).block();
        assertTrue(dtos.isEmpty());
    }
}
