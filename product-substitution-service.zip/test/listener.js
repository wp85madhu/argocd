import { check } from 'k6';
import http from 'k6/http';
import encoding from 'k6/encoding';
import { randomIntBetween, randomItem, uuidv4 } from "https://jslib.k6.io/k6-utils/1.4.0/index.js";
import { SharedArray } from 'k6/data';
import papaparse from 'https://jslib.k6.io/papaparse/5.1.1/index.js';

export const options = {
  scenarios: {
    contacts: {
      executor: 'ramping-arrival-rate',
      startRate: 5, // Our test with at a rate of 300 iterations started per `timeUnit` (e.g minute).
      timeUnit: '1s', // It should start `startRate` iterations per second
      preAllocatedVUs: 2, // It should preallocate 2 VUs before starting the test.
      maxVUs: 50, // It is allowed to spin up to 50 maximum VUs in order to sustain the defined constant arrival rate.
      stages: [
        { target: 5, duration: '1m' }, // It should start 300 iterations per `timeUnit` for the first minute.
        { target: 10, duration: '5m' }, // It should linearly ramp-up to starting 600 iterations per `timeUnit` over the following two minutes.
        { target: 10, duration: '15m' }, // It should continue starting 600 iterations per `timeUnit` for the following four minutes.
        { target: 5, duration: '5m' }, // It should linearly ramp-down to starting 60 iterations per `timeUnit` over the last two minute.
      ],
    },
  }
};

/*
Update secrets before running the script
*/
const sas = '' // Genereate SAS from Azure portal

// Shared data for all VUs
const csvData = new SharedArray('user profiles', function () {
  return papaparse.parse(open('./user-profiles.csv'), { header: true }).data;
});

export function setup() {
}

export default function (data) {
  // Pick a random user profile id
  const randomUser = csvData[Math.floor(Math.random() * csvData.length)];
  console.log('Random user: ', JSON.stringify(randomUser.ProfileId));

  let message = {
    "id": uuidv4(),
    "source": "/ecom",
    "timeStamp": new Date().toISOString(),
    "version": "1.0",
    "data": {
      "transactionDateTime": "2022-10-10T12:48:05",
      "orderId": "100000000",
      "profileId": randomUser.ProfileId,
      "products": [
        { "productId": "8766221", "allowSubstitute": Math.random() < 0.5 }, // 50% probability of getting true
        { "productId": "8766222", "allowSubstitute": Math.random() < 0.5 },
        { "productId": "8766223", "allowSubstitute": Math.random() < 0.5 },
        { "productId": "8766224", "allowSubstitute": Math.random() < 0.5 },
        { "productId": "8766225", "allowSubstitute": Math.random() < 0.7 },
        { "productId": "8766226", "allowSubstitute": Math.random() < 0.7 },
        { "productId": "8766227", "allowSubstitute": Math.random() < 0.7 },
        { "productId": "8766228", "allowSubstitute": Math.random() < 0.7 },
        { "productId": "8766229", "allowSubstitute": Math.random() < 0.8 },
        { "productId": "8766230", "allowSubstitute": Math.random() < 0.8 },
        { "productId": "8766231", "allowSubstitute": Math.random() < 0.8 },
        { "productId": "8766232", "allowSubstitute": Math.random() < 0.8 },
        { "productId": "8766233", "allowSubstitute": Math.random() < 0.9 },
        { "productId": "8766234", "allowSubstitute": Math.random() < 0.9 },
        { "productId": "8766235", "allowSubstitute": Math.random() < 0.9 },
        { "productId": "8766236", "allowSubstitute": Math.random() < 0.9 },
        { "productId": "8766237", "allowSubstitute": Math.random() < 0.9 }
      ]
    }
  }

  let url = 'https://stpcsvprssvtw999.queue.core.windows.net/productsubstitution/messages'
  let headers = {
    'Date': new Date().toISOString()
  };
  let body = `
<QueueMessage>  
  <MessageText>${encoding.b64encode(JSON.stringify(message))}</MessageText>  
</QueueMessage>`;

  const res = http.post(url + sas, body, {
    headers: headers
  })

  check(res, {
    'send message successfully': (res) => res.status === 201,
  })
}
