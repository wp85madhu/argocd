import { check } from 'k6';
import http from 'k6/http';
import encoding from 'k6/encoding';
import { randomIntBetween, randomItem, uuidv4 } from "https://jslib.k6.io/k6-utils/1.4.0/index.js";
import { SharedArray } from 'k6/data';
import papaparse from 'https://jslib.k6.io/papaparse/5.1.1/index.js';

export const options = {
  scenarios: {
    contacts: {
      executor: 'ramping-arrival-rate',
      startRate: 5, // Our test with at a rate of 300 iterations started per `timeUnit` (e.g minute).
      timeUnit: '1s', // It should start `startRate` iterations per second
      preAllocatedVUs: 2, // It should preallocate 2 VUs before starting the test.
      maxVUs: 50, // It is allowed to spin up to 50 maximum VUs in order to sustain the defined constant arrival rate.
      stages: [
        { target: 10, duration: '10m' }, // It should start 300 iterations per `timeUnit` for the first minute.
        { target: 55, duration: '5m' }, // It should linearly ramp-up to starting 600 iterations per `timeUnit` over the following two minutes.
        { target: 55, duration: '10m' }, // It should continue starting 600 iterations per `timeUnit` for the following four minutes.
        { target: 10, duration: '5m' }, // It should linearly ramp-down to starting 60 iterations per `timeUnit` over the last two minute.
      ],
    },
  }
}

/*
    API configs, secrects should not be commited to repo
*/
const clientId = '';
const clientSecret = '';
const resourceId = '1dbed5a3-36bd-45f4-96bb-956db0988ee9';
const apimKey = '';

// Shared data for all VUs
const csvData = new SharedArray('user profiles', function () {
  return papaparse.parse(open('./user-profiles.csv'), { header: true }).data;
});

function getAuthorizationToken() {
  let url = 'https://login.microsoftonline.com/82551a12-bbc8-4fed-8b7f-2b758284b5ea/oauth2/token';
  let body = {
      grant_type: 'client_credentials',
      client_id: clientId,
      client_secret: clientSecret,
      resource: resourceId
  }

  let res = http.post(url, body);
  return res.json(['access_token']);
}

export function setup() {
  return {
      authorizationToken: getAuthorizationToken(),
      apimKey: apimKey
  }
}

export default function (data) {
  // Pick a random user profile id
  const randomUser = csvData[Math.floor(Math.random() * 99)];

  let url = 'https://svt2apigw.cmltd.net.au/digital/product-substitution/v1/products';
  let headers = {
    'Ocp-Apim-Subscription-Key': data.apimKey,
    'Authorization': 'Bearer ' + data.authorizationToken,
    'UserAuthorization': 'Bearer ' + randomUser.Token
  };

  const res = http.get(url, { headers: headers });

  check(res, {
    'get product substites successfully': (res) => res.status === 200,
  })
}
