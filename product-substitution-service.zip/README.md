# Product Substitutes API

## Solution Options
For detailed information please see [Solution Options KDD - Architecture & Solution Design](https://colesgroup.atlassian.net/wiki/spaces/EA/pages/3340862550/KDD+Better+Substitutes).

## API, Database & Model Mapping
Click [here](https://colesgroup.atlassian.net/wiki/spaces/CCS/pages/3363406202/Better+Substitutes)

## Environments

### DEV
|      Properties       | Value                                                                                                                 |
|:---------------------:|:----------------------------------------------------------------------------------------------------------------------|
|       Base Url        | https://dev2apigw.cmltd.net.au/digital/product-substitution/v1                                                        |
|  Azure Client Id      | `cd190861-b63e-4861-a103-84820fa883c7`                                                                                  |
| APIM-Subscription-Key | Primary: <br> Secondary:                                                                                              |
|     App Insights      | APPINS-CSV-PRS-DEV-W999                                                                                               |
|        Argo CD        | [Link](https://argocd-aks-dgxp-dgkb-nonprod-aue.azr.cmltd.net.au/applications/product-substitution-service-dev)       |

### TEST
|      Properties       | Value                                                                                                                  |
|:---------------------:|:-----------------------------------------------------------------------------------------------------------------------|
|       Base Url        | https://test2apigw.cmltd.net.au/digital/product-substitution/v1                                                        |        
|  Azure Client Id      | `1a0e1a80-3325-451a-ae0d-88e361b862ac`                                                                                   |
| APIM-Subscription-Key | Primary: <br> Secondary:                                                                                               |
|     App Insights      | APPINS-CSV-PRS-SIT-W999                                                                                                |
|        Argo CD        | [Link](https://argocd-aks-dgxp-dgkb-nonprod-aue.azr.cmltd.net.au/applications/product-substitution-service-sit)        |

### SVT
|      Properties       | Value                                                                                                                 |
|:---------------------:|:----------------------------------------------------------------------------------------------------------------------|
|       Base Url        | https://svt2apigw.cmltd.net.au/digital/product-substitution/v1                                                        |        
|  Azure Client Id      | `1dbed5a3-36bd-45f4-96bb-956db0988ee9`                                                                                  |
| APIM-Subscription-Key | Primary: <br> Secondary:                                                                                              |
|     App Insights      | APPINS-CSV-PRS-SVT-W999                                                                                               |
|        Argo CD        | [Link](https://argocd-aks-dgxp-dgkb-nonprod-aue.azr.cmltd.net.au/applications/product-substitution-service-svt)       |

### PROD
|      Properties       | Value                                                                                                               |
|:---------------------:|:--------------------------------------------------------------------------------------------------------------------|
|       Base Url        |                                                                                                                       |
|  Azure Client Id      |                                                                                                                       |
| APIM-Subscription-Key | Primary: <br> Secondary:                                                                                              |
|     App Insights      |                                                                                                                       |
|        Argo CD        |                                                                                                                       |

### Test account

| Env  | Username              | CCP Passwor | Flybuys Password |
|:-----|:----------------------|:------------|:-----------------|
| DEV  | cxt-dr-test@proton.me | cxtdr2022   | CxtDr2022        |
| TEST | cxt-dr-test@proton.me | cxtdr2022   | CxtDr2022        |
| SVT  | cxt-dr-test@proton.me | cxtdr2022   | CxtDr2022        |
| PROD | n/a                   | n/a         | n/a              |


## Logging and Monitoring
Logs can be viewed via App Insights.

### Logging
To enable debug logging in environment, you can [override configuration at runtime](https://docs.microsoft.com/en-us/azure/azure-functions/configure-monitoring?tabs=v2#overriding-monitoring-configuration-at-runtime).

## Dependencies

### Central Customer Profile (CCP)
[Environments](https://colesgroup.atlassian.net/wiki/spaces/CCS/pages/1400838498/Environments)
