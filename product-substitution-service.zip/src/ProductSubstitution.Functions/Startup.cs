using FluentValidation;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using ProductSubstitution.Core.Options;
using ProductSubstitution.Functions.Services;
using ProductSubstitution.Functions.Validators;
using ProductSubstitution.Infrastructure.AzureStorage;
using ProductSubstitution.Infrastructure.AzureStorage.Queues;
using ProductSubstitution.Infrastructure.CosmosDb;

[assembly: FunctionsStartup(typeof(ProductSubstitution.Functions.Startup))]
namespace ProductSubstitution.Functions;

public class Startup : FunctionsStartup
{
    public override void Configure(IFunctionsHostBuilder builder)
    {
        var configuration = builder.GetContext().Configuration;

        builder.Services.Configure<ProductRetentionOptions>(
            configuration.GetSection(ProductRetentionOptions.Section));

        builder.Services.RegisterCosmosDbRepositories(configuration);
        builder.Services.RegisterAzureStorage(configuration);
        builder.Services.AddScoped<IValidator<SubstitutionMessage>, SubstitutionMessageValidator>();
        builder.Services.AddScoped<ISubstitutionQueueService, SubstitutionQueueService>();
    }
}
