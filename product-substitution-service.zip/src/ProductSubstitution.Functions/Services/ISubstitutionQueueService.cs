using System.Threading.Tasks;
using Azure.Storage.Queues.Models;
using ProductSubstitution.Infrastructure.AzureStorage.Queues;
using ProductSubstitution.Infrastructure.CosmosDb.Documents;

namespace ProductSubstitution.Functions.Services;

public interface ISubstitutionQueueService
{
    Task<SubstitutionItem> ProcessMessage(SubstitutionMessage substitutionMessage);
    Task<(bool, SubstitutionMessage)> ParseMessage(QueueMessage queueMessage);
}
