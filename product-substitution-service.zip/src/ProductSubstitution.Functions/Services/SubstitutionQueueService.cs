using System;
using System.Globalization;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Azure.Storage.Queues.Models;
using FluentValidation;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using ProductSubstitution.Core.Options;
using ProductSubstitution.Infrastructure.AzureStorage.Queues;
using ProductSubstitution.Infrastructure.AzureStorage.Repositories;
using ProductSubstitution.Infrastructure.CosmosDb.Documents;
using ProductSubstitution.Infrastructure.CosmosDb.Repositories;
using Product = ProductSubstitution.Infrastructure.CosmosDb.Documents.Product;

namespace ProductSubstitution.Functions.Services;

public class SubstitutionQueueService : ISubstitutionQueueService
{
    private readonly IValidator<SubstitutionMessage> _substitutionMessageValidator;
    private readonly IPoisonQueueRepository _poisonQueueRepository;
    private readonly ISubstitutionRepository _substitutionRepository;
    private readonly ProductRetentionOptions _productRetentionSettings;
    private readonly ILogger<SubstitutionQueueService> _logger;

    public SubstitutionQueueService(IValidator<SubstitutionMessage> substitutionMessageValidator,
        IPoisonQueueRepository poisonQueueRepository, ISubstitutionRepository substitutionRepository,
        IOptions<ProductRetentionOptions> productRetentionOptions,
        ILogger<SubstitutionQueueService> logger)
    {
        _substitutionMessageValidator = substitutionMessageValidator;
        _poisonQueueRepository = poisonQueueRepository;
        _substitutionRepository = substitutionRepository;
        _productRetentionSettings = productRetentionOptions.Value;
        _logger = logger;
    }

    public async Task<(bool, SubstitutionMessage)> ParseMessage(QueueMessage queueMessage)
    {
        _logger.LogInformation("Begin to parse message with queue message Id: {MessageId}", queueMessage.MessageId);

        SubstitutionMessage substitutionMessage;

        try
        {
            substitutionMessage = JsonSerializer.Deserialize<SubstitutionMessage>(queueMessage.MessageText);
        }
        catch
        {
            _logger.LogError(
                "Failed to deserialize queue message Id {MessageId}, inserted on datetime {InsertedOn}",
                queueMessage.MessageId,
                queueMessage.InsertedOn?.ToString(Constants.LogDateTimeFormat, NumberFormatInfo.CurrentInfo));

            await _poisonQueueRepository.SendMessageAsync(queueMessage);

            return (false, null);
        }

        var validationResult = await _substitutionMessageValidator.ValidateAsync(substitutionMessage);
        if (!validationResult.IsValid)
        {
            _logger.LogError(
                "Message validation failed for queue message Id {MessageId}, inserted on datetime {InsertedOn}, order Id: {OrderId}. Errors: {Errors}",
                queueMessage.MessageId,
                queueMessage.InsertedOn?.ToString(Constants.LogDateTimeFormat, NumberFormatInfo.CurrentInfo),
                substitutionMessage?.Data.OrderId,
                validationResult.Errors);

            await _poisonQueueRepository.SendMessageAsync(queueMessage);

            return (false, null);
        }

        _logger.LogInformation("Successfully parsed queue message Id: {MessageId}, order Id: {OrderId}",
            queueMessage.MessageId,
            substitutionMessage!.Data.OrderId);

        return (true, substitutionMessage);
    }

    public async Task<SubstitutionItem> ProcessMessage(SubstitutionMessage substitutionMessage)
    {
        _logger.LogInformation(
            "Begin to process message with substitution message Id: {MessageId}, order Id: {OrderId}",
            substitutionMessage.Id,
            substitutionMessage.Data.OrderId);

        var substitutionItem = await _substitutionRepository.ReadItemAsync(substitutionMessage.Data.ProfileId) ??
                               new SubstitutionItem
                               {
                                   Id = substitutionMessage.Data.ProfileId,
                                   PartitionKey = substitutionMessage.Data.ProfileId
                               };

        var substitutionMessageProducts = substitutionMessage.Data.Products.Where(substitutionMessageProduct =>
            int.TryParse(substitutionMessageProduct.Id, out var productId) &&
            productId > 0 &&
            substitutionMessageProduct.AllowSubstitute);

        var products = substitutionItem.Products.ToList();

        foreach (var substitutionMessageProduct in substitutionMessageProducts)
        {
            if (products.SingleOrDefault(product => product.Id == substitutionMessageProduct.Id) is
                { } existingProduct)
            {
                _logger.LogInformation(
                    "Updating existing product {ProductId}, with transaction datetime: {TransactionDateTime}",
                    existingProduct.Id,
                    existingProduct.TransactionDateTime.ToString(Constants.LogDateTimeFormat, NumberFormatInfo.CurrentInfo));

                existingProduct.TransactionDateTime = substitutionMessage.Data.TransactionDateTime;
            }
            else
            {
                var newProduct = new Product
                {
                    Id = substitutionMessageProduct.Id,
                    TransactionDateTime = substitutionMessage.Data.TransactionDateTime
                };

                _logger.LogInformation("Adding new product {ProductId}, transaction datetime: {TransactionDateTime}",
                    newProduct.Id,
                    newProduct.TransactionDateTime.ToString(Constants.LogDateTimeFormat, NumberFormatInfo.CurrentInfo));

                products.Add(newProduct);
            }
        }

        products.RemoveAll(product =>
            // Remove products that are older than number of days set in config
            product.TransactionDateTime < DateTimeOffset.UtcNow.AddDays(-1 * _productRetentionSettings.Days)
            ||
            // Remove products customer do not want to be substituted
            substitutionMessage.Data.Products.Any(substitutionMessageProduct =>
                substitutionMessageProduct.Id == product.Id && !substitutionMessageProduct.AllowSubstitute)
        );

        substitutionItem.Products = products;
        await _substitutionRepository.UpsertItemAsync(substitutionItem);

        _logger.LogInformation(
            "Successfully processed message with substitution message Id: {MessageId}, order Id: {OrderId}",
            substitutionMessage.Id,
            substitutionMessage.Data.OrderId);

        return substitutionItem;
    }
}
