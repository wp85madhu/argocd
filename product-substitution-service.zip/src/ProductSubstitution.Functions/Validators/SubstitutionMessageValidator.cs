using FluentValidation;
using ProductSubstitution.Infrastructure.AzureStorage.Queues;

namespace ProductSubstitution.Functions.Validators;

public class SubstitutionMessageValidator : AbstractValidator<SubstitutionMessage>
{
    public SubstitutionMessageValidator()
    {
        RuleFor(message => message).NotNull();
        RuleFor(message => message.Data).NotNull();
        RuleFor(message => message.Data.TransactionDateTime).NotEmpty();
        RuleFor(message => message.Data.OrderId).NotEmpty();
        RuleFor(message => message.Data.ProfileId).NotEmpty();
        RuleFor(message => message.Data.Products).NotEmpty();
    }
}
