namespace ProductSubstitution.Functions;

public static class Constants
{
    public const string LogDateTimeFormat = "yyyy-MM-ddTHH:mm:ssZ";
}
