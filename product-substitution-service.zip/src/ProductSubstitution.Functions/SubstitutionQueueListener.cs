using System.Threading.Tasks;
using Azure.Storage.Queues.Models;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using ProductSubstitution.Functions.Services;

namespace ProductSubstitution.Functions;

public class SubstitutionQueueListener
{
    private readonly ISubstitutionQueueService _substitutionQueueService;

    public SubstitutionQueueListener(ISubstitutionQueueService substitutionQueueService)
    {
        _substitutionQueueService = substitutionQueueService;
    }

    [FunctionName("SubstitutionQueueListener")]
    public async Task Run(
        [QueueTrigger("productsubstitution", Connection = "AzureWebJobsStorage")] QueueMessage queueMessage,
        ILogger logger)
    {
        logger.LogInformation("Substitution queue listener is triggered by {MessageId}, {DequeueCount}",
            queueMessage.MessageId, queueMessage.DequeueCount);

        var (isSuccess, substitutionMessage) = await _substitutionQueueService.ParseMessage(queueMessage);
        if (!isSuccess)
        {
            return;
        }

        await _substitutionQueueService.ProcessMessage(substitutionMessage);
    }
}
