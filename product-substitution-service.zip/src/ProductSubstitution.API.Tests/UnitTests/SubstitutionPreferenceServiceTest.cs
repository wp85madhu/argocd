using System.Collections.Generic;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.Extensions.Options;
using Moq;
using ProductSubstitution.API.Services;
using ProductSubstitution.API.Tests.Fixtures;
using ProductSubstitution.Core.Options;
using ProductSubstitution.Infrastructure.CosmosDb.Repositories;
using ProductSubstitution.Infrastructure.Exceptions;
using Xunit;
using Product = ProductSubstitution.API.Models.Product;

namespace ProductSubstitution.API.Tests.UnitTests;

public class SubstitutionPreferenceServiceTest : IClassFixture<SubstitutionItemFixture>
{
    private readonly SubstitutionItemFixture _substitutionItemFixture;
    private readonly IOptions<ProductRetentionOptions> _productRetentionOptions;
    private readonly ISubstitutionPreferenceService _substitutionPreferenceService;
    private readonly Mock<ISubstitutionRepository> _mockSubstitutionRepository;

    public SubstitutionPreferenceServiceTest(SubstitutionItemFixture substitutionItemFixture)
    {
        _substitutionItemFixture = substitutionItemFixture;
        _mockSubstitutionRepository = new Mock<ISubstitutionRepository>();

        _productRetentionOptions = Microsoft.Extensions.Options.Options.Create(
            new ProductRetentionOptions
            {
                Days = 90,
            });

        _substitutionPreferenceService =
            new SubstitutionPreferenceService(_mockSubstitutionRepository.Object, _productRetentionOptions);
    }

    [Fact]
    public async Task ProcessMessage_Should_PerformCorrectly()
    {
        _mockSubstitutionRepository.Setup(x => x.ReadItemAsync(It.IsAny<string>()))
            .ReturnsAsync(_substitutionItemFixture.SubstitutionItem);

        var substitutionItem =
            await _substitutionPreferenceService.GetSubstitutionPreferences("0b67abc4-1b3e-4127-8246-ab2df5faad6b");

        substitutionItem.Products.Should().BeEquivalentTo(
            new List<Product>
            {
                new()
                {
                    ProductId = "2"
                },
                new()
                {
                    ProductId = "3"
                },
                new()
                {
                    ProductId = "4"
                }
            }
        );
    }

    [Fact]
    public async Task GetProductSubstitute_WithDbUnavailable_ThrowException()
    {
        var dbNotAvailableException = new CosmosDbNotAvailableException("CosmosDB was not available");
        _mockSubstitutionRepository.Setup(s => s.ReadItemAsync(It.IsAny<string>()))
            .ThrowsAsync(dbNotAvailableException);
        await Assert.ThrowsAsync<CosmosDbNotAvailableException>(() =>
            _substitutionPreferenceService.GetSubstitutionPreferences("0a67abc4-1b3e-4127-8246-ab2df5faad6b"));
    }


    [Fact]
    public async Task GetProductSubstitute_ValidCcpId_ThrowNoException()
    {
        _mockSubstitutionRepository.Setup(s => s.ReadItemAsync(It.IsAny<string>()))
            .ReturnsAsync(_substitutionItemFixture.EmptySubstitutionItem);

        var substitutionItem = await _substitutionPreferenceService.GetSubstitutionPreferences("1234");
        substitutionItem.Products.Should().BeEquivalentTo(
            new List<Product>());
    }
}
