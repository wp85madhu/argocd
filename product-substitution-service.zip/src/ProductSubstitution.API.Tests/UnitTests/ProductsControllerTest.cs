using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using ProductSubstitution.API.Controllers;
using ProductSubstitution.API.Models;
using ProductSubstitution.API.Services;
using Xunit;

namespace ProductSubstitution.API.Tests.UnitTests;

public class ProductsControllerTest
{
    private readonly Mock<ISubstitutionPreferenceService> _mockSubstitutionPreferenceService;

    public ProductsControllerTest()
    {
        _mockSubstitutionPreferenceService = new Mock<ISubstitutionPreferenceService>();
    }

    [Fact]
    public async Task GetProductSubstitute_WithValidUserAuthorization_OkResult()
    {
        var response = new SubstitutionPreferenceResponse();

        _mockSubstitutionPreferenceService.Setup(s => s.GetSubstitutionPreferences(It.IsAny<string>()))
            .ReturnsAsync(response);

        var request = new Mock<HttpRequest>();
        request.Setup(x => x.Headers[Constants.CcpId]).Returns("1234");

        var controller = new ProductsController(_mockSubstitutionPreferenceService.Object);
        var controllerContext = new ControllerContext()
        {
            HttpContext = Mock.Of<HttpContext>(_ => _.Request == request.Object)
        };
        controller.ControllerContext = controllerContext;

        var actualItems = await controller.GetSubstitutionPreference("123");
        var result = actualItems as ObjectResult;

        result.Should().BeOfType<OkObjectResult>();
    }
}
