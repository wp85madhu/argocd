using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;

namespace ProductSubstitution.Functions.Tests.Helpers;

//Simple class that implements IAsyncCollector by simply adding any items to a list
//Can be used to store and check the output of a function by checking the contents of the list
public class TestAsyncCollector<T> : IAsyncCollector<T>
{
    public List<T> Items { get; } = new();

    public Task AddAsync(T item, CancellationToken cancellationToken = default)
    {
        Items.Add(item);

        return Task.FromResult(true);
    }

    public Task FlushAsync(CancellationToken cancellationToken = default)
    {
        return Task.FromResult(true);
    }
}
