using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Azure.Storage.Queues.Models;
using FluentAssertions;
using FluentValidation;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using ProductSubstitution.Core.Options;
using ProductSubstitution.Functions.Services;
using ProductSubstitution.Functions.Tests.Fixtures;
using ProductSubstitution.Functions.Validators;
using ProductSubstitution.Infrastructure.AzureStorage.Queues;
using ProductSubstitution.Infrastructure.AzureStorage.Repositories;
using ProductSubstitution.Infrastructure.CosmosDb.Documents;
using ProductSubstitution.Infrastructure.CosmosDb.Repositories;
using Xunit;
using Product = ProductSubstitution.Infrastructure.CosmosDb.Documents.Product;

namespace ProductSubstitution.Functions.Tests;

public class SubstitutionQueueServiceTests : IClassFixture<QueueMessageFixture>,
    IClassFixture<SubstitutionMessageFixture>,
    IClassFixture<SubstitutionItemFixture>
{
    private readonly QueueMessageFixture _queueMessageFixture;
    private readonly SubstitutionMessageFixture _substitutionMessageFixture;
    private readonly SubstitutionItemFixture _substitutionItemFixture;
    private readonly IValidator<SubstitutionMessage> _substitutionMessageValidator;
    private readonly Mock<IPoisonQueueRepository> _mockPoisonQueueRepository;
    private readonly Mock<ISubstitutionRepository> _mockSubstitutionRepository;
    private readonly Mock<ILogger<SubstitutionQueueService>> _mockLogger;
    private readonly IOptions<ProductRetentionOptions> _productRetentionOptions;
    private readonly ISubstitutionQueueService _substitutionQueueService;

    public SubstitutionQueueServiceTests(QueueMessageFixture queueMessageFixture,
        SubstitutionMessageFixture substitutionMessageFixture,
        SubstitutionItemFixture substitutionItemFixture)
    {
        _queueMessageFixture = queueMessageFixture;
        _substitutionMessageFixture = substitutionMessageFixture;
        _substitutionItemFixture = substitutionItemFixture;
        _substitutionMessageValidator = new SubstitutionMessageValidator();
        _mockPoisonQueueRepository = new Mock<IPoisonQueueRepository>();
        _mockSubstitutionRepository = new Mock<ISubstitutionRepository>();
        _mockLogger = new Mock<ILogger<SubstitutionQueueService>>();

        _productRetentionOptions = Options.Create(
            new ProductRetentionOptions
            {
                Days = 90,
            });

        _substitutionQueueService = new SubstitutionQueueService(_substitutionMessageValidator,
            _mockPoisonQueueRepository.Object,
            _mockSubstitutionRepository.Object,
            _productRetentionOptions,
            _mockLogger.Object);
    }

    [Fact]
    public async Task ParseMessage_Should_ReturnSuccess()
    {
        _mockPoisonQueueRepository.Setup(x => x.SendMessageAsync(It.IsAny<QueueMessage>())).Verifiable();

        var (isSuccess, substitutionMessage) =
            await _substitutionQueueService.ParseMessage(_queueMessageFixture.ValidQueueMessage);

        _mockPoisonQueueRepository.Verify(x => x.SendMessageAsync(It.IsAny<QueueMessage>()), Times.Never);

        isSuccess.Should().BeTrue();
        substitutionMessage.Should().BeEquivalentTo(
            new SubstitutionMessage
            {
                Id = "28ba7ea8-da02-47c6-b242-9d929beb50b3",
                Source = "Source",
                Version = "1",
                TimeStamp = DateTime.Today,
                Data = new Data
                {
                    ProfileId = "0b67abc4-1b3e-4127-8246-ab2df5faad6b",
                    OrderId = "A8232944",
                    TransactionDateTime = DateTime.Today,
                    Products = new List<Infrastructure.AzureStorage.Queues.Product>
                    {
                        new()
                        {
                            Id = "0",
                            AllowSubstitute = true
                        },
                        new()
                        {
                            Id = "1",
                            AllowSubstitute = true
                        },
                        new()
                        {
                            Id = "2",
                            AllowSubstitute = true
                        },
                        new()
                        {
                            Id = "3",
                            AllowSubstitute = true
                        },
                        new()
                        {
                            Id = "4",
                            AllowSubstitute = false
                        },
                        new()
                        {
                            Id = "6",
                            AllowSubstitute = true
                        }
                    }
                }
            });
    }

    [Fact]
    public async Task ParseMessage_Should_ReturnFalse_When_DeserializationFails()
    {
        _mockPoisonQueueRepository.Setup(x => x.SendMessageAsync(It.IsAny<QueueMessage>())).Verifiable();

        var (isSuccess, substitutionMessage) =
            await _substitutionQueueService.ParseMessage(_queueMessageFixture.FailDeserializationQueueMessage);

        _mockPoisonQueueRepository.Verify(x => x.SendMessageAsync(It.IsAny<QueueMessage>()));

        isSuccess.Should().BeFalse();
        substitutionMessage.Should().BeNull();
    }

    [Fact]
    public async Task ParseMessage_Should_ReturnFalse_When_ValidationFails()
    {
        _mockPoisonQueueRepository.Setup(x => x.SendMessageAsync(It.IsAny<QueueMessage>())).Verifiable();

        var (isSuccess, substitutionMessage) =
            await _substitutionQueueService.ParseMessage(_queueMessageFixture.FailValidationQueueMessage);

        _mockPoisonQueueRepository.Verify(x => x.SendMessageAsync(It.IsAny<QueueMessage>()));

        isSuccess.Should().BeFalse();
        substitutionMessage.Should().BeNull();
    }

    [Fact]
    public async Task ProcessMessage_Should_PerformCorrectly()
    {
        _mockSubstitutionRepository.Setup(x => x.ReadItemAsync(It.IsAny<string>()))
            .ReturnsAsync(_substitutionItemFixture.SubstitutionItem);

        var substitutionItem = await _substitutionQueueService.ProcessMessage(_substitutionMessageFixture.SubstitutionMessage);

        substitutionItem.Should().BeEquivalentTo(
            new SubstitutionItem
            {
                Id = "0b67abc4-1b3e-4127-8246-ab2df5faad6b",
                PartitionKey = "0b67abc4-1b3e-4127-8246-ab2df5faad6b",
                Products = new List<Product>
                {
                    new()
                    {
                        Id = "1",
                        TransactionDateTime = DateTime.Today

                    },
                    new()
                    {
                        Id = "2",
                        TransactionDateTime = DateTime.Today

                    },
                    new()
                    {
                        Id = "3",
                        TransactionDateTime = DateTime.Today

                    },
                    new()
                    {
                        Id = "6",
                        TransactionDateTime = DateTime.Today

                    }
                }
            }
        );
    }
}
