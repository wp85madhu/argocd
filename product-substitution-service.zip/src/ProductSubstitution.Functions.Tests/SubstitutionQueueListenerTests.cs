using System.Threading.Tasks;
using Azure.Storage.Queues.Models;
using Microsoft.Extensions.Logging;
using Moq;
using ProductSubstitution.Functions.Services;
using ProductSubstitution.Functions.Tests.Fixtures;
using ProductSubstitution.Infrastructure.AzureStorage.Queues;
using Xunit;

namespace ProductSubstitution.Functions.Tests;

public class SubstitutionQueueListenerTests : IClassFixture<QueueMessageFixture>, IClassFixture<SubstitutionMessageFixture>
{
    private readonly QueueMessageFixture _queueMessageFixture;
    private readonly SubstitutionMessageFixture _substitutionMessageFixture;
    private readonly Mock<ISubstitutionQueueService> _mockSubstitutionQueueService;
    private readonly Mock<ILogger> _mockLogger;

    public SubstitutionQueueListenerTests(QueueMessageFixture queueMessageFixture, SubstitutionMessageFixture substitutionMessageFixture)
    {
        _queueMessageFixture = queueMessageFixture;
        _substitutionMessageFixture = substitutionMessageFixture;
        _mockSubstitutionQueueService = new Mock<ISubstitutionQueueService>();
        _mockLogger = new Mock<ILogger>();
    }

    [Fact]
    public async Task ShouldRunCorrectly_When_RequestIsValid()
    {
        _mockSubstitutionQueueService.Setup(x => x.ParseMessage(It.IsAny<QueueMessage>()))
            .ReturnsAsync((true, _substitutionMessageFixture.SubstitutionMessage));
        _mockSubstitutionQueueService.Setup(x => x.ProcessMessage(It.IsAny<SubstitutionMessage>())).Verifiable();

        var substitutionQueueListener = new SubstitutionQueueListener(_mockSubstitutionQueueService.Object);

        await substitutionQueueListener.Run(_queueMessageFixture.ValidQueueMessage, _mockLogger.Object);

        _mockSubstitutionQueueService.Verify(x => x.ParseMessage(It.IsAny<QueueMessage>()));
        _mockSubstitutionQueueService.Verify(x => x.ProcessMessage(It.IsAny<SubstitutionMessage>()));
    }

    [Fact]
    public async Task ShouldNotProceed_When_RequestDeserializationFails()
    {
        _mockSubstitutionQueueService.Setup(x => x.ParseMessage(It.IsAny<QueueMessage>())).ReturnsAsync((false, null));
        _mockSubstitutionQueueService.Setup(x => x.ProcessMessage(It.IsAny<SubstitutionMessage>())).Verifiable();

        var substitutionQueueListener = new SubstitutionQueueListener(_mockSubstitutionQueueService.Object);

        await substitutionQueueListener.Run(_queueMessageFixture.FailDeserializationQueueMessage, _mockLogger.Object);

        _mockSubstitutionQueueService.Verify(x => x.ParseMessage(It.IsAny<QueueMessage>()));
        _mockSubstitutionQueueService.Verify(x => x.ProcessMessage(It.IsAny<SubstitutionMessage>()), Times.Never);
    }

    [Fact]
    public async Task ShouldNotProceed_When_RequestValidationFails()
    {
        _mockSubstitutionQueueService.Setup(x => x.ParseMessage(It.IsAny<QueueMessage>())).ReturnsAsync((false, null));
        _mockSubstitutionQueueService.Setup(x => x.ProcessMessage(It.IsAny<SubstitutionMessage>())).Verifiable();

        var substitutionQueueListener = new SubstitutionQueueListener(_mockSubstitutionQueueService.Object);

        await substitutionQueueListener.Run(_queueMessageFixture.FailValidationQueueMessage, _mockLogger.Object);

        _mockSubstitutionQueueService.Verify(x => x.ParseMessage(It.IsAny<QueueMessage>()));
        _mockSubstitutionQueueService.Verify(x => x.ProcessMessage(It.IsAny<SubstitutionMessage>()), Times.Never);
    }
}
