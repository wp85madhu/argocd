using System;
using System.Collections.Generic;
using System.Text.Json;
using Azure.Storage.Queues.Models;
using ProductSubstitution.Infrastructure.AzureStorage.Queues;

namespace ProductSubstitution.Functions.Tests.Fixtures;

public class QueueMessageFixture
{
    public QueueMessage ValidQueueMessage { get; }
    public QueueMessage FailValidationQueueMessage { get; }
    public QueueMessage FailDeserializationQueueMessage { get; }

    public QueueMessageFixture()
    {
        ValidQueueMessage = GetValidQueueMessage();
        FailValidationQueueMessage = GetFailValidationQueueMessage();
        FailDeserializationQueueMessage = GetFailedDeserializationQueueMessage();
    }

    private static QueueMessage GetValidQueueMessage()
    {
        var substitutionMessage = new SubstitutionMessage
        {
            Id = "28ba7ea8-da02-47c6-b242-9d929beb50b3",
            Source = "Source",
            Version = "1",
            TimeStamp = DateTime.Today,
            Data = new Data
            {
                ProfileId = "0b67abc4-1b3e-4127-8246-ab2df5faad6b",
                OrderId = "A8232944",
                TransactionDateTime = DateTime.Today,
                Products = new List<Product>
                 {
                     new()
                     {
                         Id = "0",
                         AllowSubstitute = true
                     },
                     new()
                     {
                         Id = "1",
                         AllowSubstitute = true
                     },
                     new()
                     {
                         Id = "2",
                         AllowSubstitute = true
                     },
                     new()
                     {
                         Id = "3",
                         AllowSubstitute = true
                     },
                     new()
                     {
                         Id = "4",
                         AllowSubstitute = false
                     },
                     new()
                     {
                         Id = "6",
                         AllowSubstitute = true
                     }
                 }
            }
        };

        return BuildQueueMessage(substitutionMessage);
    }

    private static QueueMessage GetFailValidationQueueMessage()
    {
        var invalidSubstitutionMessage = new SubstitutionMessage
        {
            Id = Guid.NewGuid().ToString(),
            Source = "Source",
            Version = "1",
            TimeStamp = DateTime.UtcNow
        };

        return BuildQueueMessage(invalidSubstitutionMessage);
    }

    private static QueueMessage GetFailedDeserializationQueueMessage() => QueuesModelFactory.QueueMessage(
        Guid.NewGuid().ToString(),
        Guid.NewGuid().ToString(),
        JsonSerializer.Serialize("{ \"fails\" : \"deserialization\" }"),
        0);

    private static QueueMessage BuildQueueMessage(SubstitutionMessage substitutionMessage) => QueuesModelFactory.QueueMessage(
        Guid.NewGuid().ToString(),
        Guid.NewGuid().ToString(),
        JsonSerializer.Serialize(substitutionMessage),
        0);
}
