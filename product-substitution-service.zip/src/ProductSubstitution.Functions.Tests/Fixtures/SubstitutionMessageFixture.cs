using System;
using System.Collections.Generic;
using ProductSubstitution.Infrastructure.AzureStorage.Queues;

namespace ProductSubstitution.Functions.Tests.Fixtures;

public class SubstitutionMessageFixture
{
    public SubstitutionMessage SubstitutionMessage { get; }

    public SubstitutionMessageFixture()
    {
        SubstitutionMessage = new SubstitutionMessage
        {
            Id = Guid.NewGuid().ToString(),
            Source = "Source",
            Version = "1",
            TimeStamp = DateTime.UtcNow,
            Data = new Data
            {
                ProfileId = "0b67abc4-1b3e-4127-8246-ab2df5faad6b",
                TransactionDateTime = DateTime.Today,
                Products = new List<Product>
                {
                     new()
                     {
                         Id = "0",
                         AllowSubstitute = true
                     },
                     new()
                     {
                         Id = "1",
                         AllowSubstitute = true
                     },
                     new()
                     {
                         Id = "2",
                         AllowSubstitute = true
                     },
                     new()
                     {
                         Id = "3",
                         AllowSubstitute = true
                     },
                     new()
                     {
                         Id = "4",
                         AllowSubstitute = false
                     },
                     new()
                     {
                         Id = "6",
                         AllowSubstitute = true
                     }
                }
            }
        };
    }
}
