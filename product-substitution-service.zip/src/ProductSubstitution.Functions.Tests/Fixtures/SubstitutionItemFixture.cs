using System;
using System.Collections.Generic;
using ProductSubstitution.Infrastructure.CosmosDb.Documents;

namespace ProductSubstitution.Functions.Tests.Fixtures;

public class SubstitutionItemFixture
{
    public SubstitutionItem SubstitutionItem { get; }

    public SubstitutionItemFixture()
    {
        SubstitutionItem = new SubstitutionItem
        {
            Id = "0b67abc4-1b3e-4127-8246-ab2df5faad6b",
            PartitionKey = "0b67abc4-1b3e-4127-8246-ab2df5faad6b",
            Products = new List<Product>
            {
                new()
                {
                    Id = "1",
                    TransactionDateTime = DateTime.Today.AddDays(-95)
                },
                new()
                {
                    Id = "2",
                    TransactionDateTime = DateTime.Today.AddDays(-30)
                },
                new()
                {
                    Id = "3",
                    TransactionDateTime = DateTime.Today.AddDays(-25)
                },
                new()
                {
                    Id = "4",
                    TransactionDateTime = DateTime.Today.AddDays(-1)
                },
                new()
                {
                    Id = "5",
                    TransactionDateTime = DateTime.Today.AddDays(-120)
                }
            }
        };
    }
}
