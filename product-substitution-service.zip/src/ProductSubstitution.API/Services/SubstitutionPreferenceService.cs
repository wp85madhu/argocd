using Microsoft.Extensions.Options;
using ProductSubstitution.API.Models;
using ProductSubstitution.Core.Options;
using ProductSubstitution.Infrastructure.CosmosDb.Repositories;
using Product = ProductSubstitution.API.Models.Product;

namespace ProductSubstitution.API.Services;

public class SubstitutionPreferenceService : ISubstitutionPreferenceService
{
    private readonly ISubstitutionRepository _substitutionRepository;
    private readonly ProductRetentionOptions _productRetentionSettings;

    public SubstitutionPreferenceService(ISubstitutionRepository substitutionRepository,
        IOptions<ProductRetentionOptions> productRetentionOptions)
    {
        _substitutionRepository = substitutionRepository;
        _productRetentionSettings = productRetentionOptions.Value;
    }

    public async Task<SubstitutionPreferenceResponse> GetSubstitutionPreferences(string ccpId)
    {
        var substitutionItem = await _substitutionRepository.ReadItemAsync(ccpId);

        var products = substitutionItem?.Products
            .Where(product => product.TransactionDateTime > DateTimeOffset.UtcNow.AddDays(-1 * _productRetentionSettings.Days))
            .Select(product =>
                new Product
                {
                    ProductId = product.Id
                }
            ).ToList() ?? new List<Product>();

        return new SubstitutionPreferenceResponse
        {
            Products = products
        };
    }
}
