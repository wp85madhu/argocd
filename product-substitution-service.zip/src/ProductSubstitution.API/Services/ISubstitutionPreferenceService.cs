using ProductSubstitution.API.Models;

namespace ProductSubstitution.API.Services;

public interface ISubstitutionPreferenceService
{
    Task<SubstitutionPreferenceResponse> GetSubstitutionPreferences(string ccpId);
}
