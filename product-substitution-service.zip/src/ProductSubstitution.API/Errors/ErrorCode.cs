namespace ProductSubstitution.API.Errors;

public class ErrorCode
{
    public static string BadRequest => "Bad_Request"; // 400
    public static string UnauthorizedAccess => "Unauthorised"; // 401
    public static string Forbidden => "Forbidden"; // 403
    public static string InternalServerError => "Internal_Server_Error"; // 500
    public static string CosmosDbUnavailable => "CosmosDb_Unavailable";
    public static string ValidationError => "Validation_Error";
}
