using System.IdentityModel.Tokens.Jwt;
using ProductSubstitution.API.Options;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using ProductSubstitution.API.Exceptions;

namespace ProductSubstitution.API.Filters;

[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public class UserAuthorizeAttribute : Attribute, IFilterFactory
{
    public bool IsReusable => true;

    public IFilterMetadata CreateInstance(IServiceProvider serviceProvider)
    {
        var options = serviceProvider.GetRequiredService<IOptions<UserAuthorizationOptions>>();
        var configurationManager = new ConfigurationManager<OpenIdConnectConfiguration>(
            $"{options.Value.Issuer}/.well-known/openid-configuration",
            new OpenIdConnectConfigurationRetriever(),
            new HttpDocumentRetriever());
        return new UserAuthorizationFilter(options, configurationManager);
    }
}

public class UserAuthorizationFilter : IAsyncAuthorizationFilter
{
    private readonly UserAuthorizationOptions _userAuthorisationOptions;
    private readonly IConfigurationManager<OpenIdConnectConfiguration> _configurationManager;

    public UserAuthorizationFilter(IOptions<UserAuthorizationOptions> userAuthorisationOptions,
        IConfigurationManager<OpenIdConnectConfiguration> configurationManager)
    {
        _configurationManager = configurationManager;
        _userAuthorisationOptions = userAuthorisationOptions.Value;
    }

    public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
    {
        var token = context.HttpContext.Request.Headers["UserAuthorization"].ToString();
        if (string.IsNullOrWhiteSpace(token))
        {
            throw new MissingUserAuthorisationException("Missing UserAuthorisation");
        }
        if (!token.StartsWith(JwtBearerDefaults.AuthenticationScheme, StringComparison.OrdinalIgnoreCase))
        {
            throw new UnauthorizedAccessException("Bearer scheme is challenged.");
        }
        await ValidateTokenAsync(token[(JwtBearerDefaults.AuthenticationScheme.Length + 1)..], context);
    }

    private async Task ValidateTokenAsync(string token, AuthorizationFilterContext context)
    {
        var discoveryDocument = await _configurationManager.GetConfigurationAsync(CancellationToken.None);
        var validateParameters = new TokenValidationParameters
        {
            ValidateIssuerSigningKey = true,
            IssuerSigningKeys = discoveryDocument.SigningKeys,
            ValidateIssuer = false,
            ValidAudience = _userAuthorisationOptions.Audience,
        };
        try
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            tokenHandler.ValidateToken(token, validateParameters, out var validatedToken);
            var jwtSecurityToken = (JwtSecurityToken)validatedToken;
            var profileClaim = jwtSecurityToken.Claims.First(x => x.Type == Constants.ProfileIdClaim);
            context.HttpContext.Request.Headers[Constants.CcpId] = profileClaim.Value;
        }
        catch (Exception ex)
        {
            throw new UnauthorizedAccessException(ex.Message);
        }
    }
}
