using System.Net;
using ProductSubstitution.API.Errors;
using ProductSubstitution.Core.Errors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace ProductSubstitution.API.Filters;

public class ValidateModelStateFilterAttribute : ActionFilterAttribute
{
    public override void OnActionExecuting(ActionExecutingContext context)
    {
        if (context.ModelState.IsValid)
        {
            return;
        }

        var responseObj = new ErrorResponse
        {
            Errors = context.ModelState.Values.SelectMany(o => o.Errors)
                .Select(error => new ErrorDetail
                {
                    ErrorCode = ErrorCode.BadRequest,
                    Message = error.ErrorMessage,
                    Priority = ErrorPriority.HIGH
                })
        };

        context.Result = new JsonResult(responseObj)
        {
            StatusCode = (int)HttpStatusCode.BadRequest
        };
    }
}
