using System.Net.Mime;
using System.Text.Json;
using System.Text.Json.Serialization;
using ProductSubstitution.API.Errors;
using ProductSubstitution.Core.Errors;
using ProductSubstitution.Infrastructure.Exceptions;
using FluentValidation;
using Microsoft.AspNetCore.Diagnostics;
using ProductSubstitution.API.Exceptions;

namespace ProductSubstitution.API.Filters;

public static class CustomExceptionHandler
{
    public static void UseCustomExceptionHandler(this IApplicationBuilder app)
    {
        app.UseExceptionHandler(exceptionHandlerApp =>
        {
            exceptionHandlerApp.Run(async context =>
            {
                var exceptionFeature = context.Features.Get<IExceptionHandlerPathFeature>();
                await HandleExceptionAsync(context, exceptionFeature);
            });
        });
    }

    private static async Task HandleExceptionAsync(HttpContext context,
        IExceptionHandlerFeature? exceptionHandlerFeature)
    {
        var exception = exceptionHandlerFeature?.Error ?? null;

        var (errorResponse, statusCode) = exception switch
        {
            ValidationException validationException =>
            (
                new ErrorResponse
                {
                    Errors = validationException.Errors.Select(error =>
                        new ErrorDetail
                        {
                            ErrorCode = ErrorCode.BadRequest,
                            Message = error.ErrorMessage,
                            Priority = ErrorPriority.HIGH,
                            Properties = new ErrorProperty(error.PropertyName, string.Empty)
                        })
                },
                StatusCodes.Status400BadRequest
            ),
            UnauthorizedAccessException unauthorizedAccessException =>
            (
                new ErrorResponse(ErrorCode.UnauthorizedAccess, unauthorizedAccessException.Message,
                    ErrorPriority.HIGH),
                StatusCodes.Status401Unauthorized
            ),
            MissingUserAuthorisationException missingUserAuthorizationException =>
            (
                new ErrorResponse(ErrorCode.ValidationError, missingUserAuthorizationException.Message, ErrorPriority.HIGH,
                    new ErrorProperty("UserAuthorisation", "string")),
                StatusCodes.Status400BadRequest
            ),
            CosmosDbNotAvailableException cosmosDbException =>
            (
                new ErrorResponse(ErrorCode.CosmosDbUnavailable, cosmosDbException.Message, ErrorPriority.HIGH),
                StatusCodes.Status500InternalServerError
            ),
            _ =>
            (
                new ErrorResponse(ErrorCode.InternalServerError, exception?.Message ?? "Internal server error",
                    ErrorPriority.HIGH),
                StatusCodes.Status500InternalServerError
            )
        };

        var errorResponseJson = JsonSerializer.Serialize(errorResponse, new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        });

        context.Response.StatusCode = statusCode;
        context.Response.ContentType = MediaTypeNames.Application.Json;

        await context.Response.WriteAsync(errorResponseJson);
    }
}
