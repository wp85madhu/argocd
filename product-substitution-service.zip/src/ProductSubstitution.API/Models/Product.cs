namespace ProductSubstitution.API.Models;

public class Product
{
    public string ProductId { get; set; } = null!;
}
