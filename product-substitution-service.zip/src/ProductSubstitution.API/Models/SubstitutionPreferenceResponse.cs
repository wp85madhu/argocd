namespace ProductSubstitution.API.Models;

public class SubstitutionPreferenceResponse
{
    public IEnumerable<Product> Products { get; set; } = Enumerable.Empty<Product>();
}
