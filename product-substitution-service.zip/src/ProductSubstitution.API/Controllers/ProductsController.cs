using System.ComponentModel.DataAnnotations;
using System.Net.Mime;
using ProductSubstitution.API.Filters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProductSubstitution.API.Models;
using ProductSubstitution.API.Services;
using ProductSubstitution.Core.Errors;

namespace ProductSubstitution.API.Controllers;

[ApiController]
[Route("[controller]")]
[Produces(MediaTypeNames.Application.Json)]
[Authorize]
[UserAuthorize]
public class ProductsController : ControllerBase
{
    private readonly ISubstitutionPreferenceService _substitutionPreferenceService;

    public ProductsController(ISubstitutionPreferenceService substitutionPreferenceService)
    {
        _substitutionPreferenceService = substitutionPreferenceService;
    }

    /// <summary>
    /// Retrieves list of preferred products for substitution
    /// </summary>
    /// <remarks>Retrieves customers product substitution preference list from last 90 days of shopping history</remarks>
    /// <returns></returns>
    /// <response code="200">Successful Response</response>
    /// <response code="400">Bad Request</response>
    /// <response code="401">Unauthorized</response>
    /// <response code="500">Internal Server Error</response>
    [ProducesResponseType(typeof(SubstitutionPreferenceResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status500InternalServerError)]
    [HttpGet(Name = "getProductSubstitutes")]
    public async Task<IActionResult> GetSubstitutionPreference([FromHeader][Required] string userAuthorization)
    {
        var ccpId = HttpContext.Request.Headers[Constants.CcpId].ToString();
        var substitutionPreferences = await _substitutionPreferenceService.GetSubstitutionPreferences(ccpId);

        return Ok(substitutionPreferences);
    }
}
