using System.Diagnostics.CodeAnalysis;
namespace ProductSubstitution.API.Exceptions;

[ExcludeFromCodeCoverage]
public class MissingUserAuthorisationException : Exception
{
    public MissingUserAuthorisationException(string message) : base(message)
    {

    }
}
