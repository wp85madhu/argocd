namespace ProductSubstitution.API.Options;

public class UserAuthorizationOptions
{
    public static string Section => "UserAuthorization";
    public string Issuer { get; set; } = null!;
    public string Audience { get; set; } = null!;
}
