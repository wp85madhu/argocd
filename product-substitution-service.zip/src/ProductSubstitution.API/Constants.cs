namespace ProductSubstitution.API;

public static class Constants
{
    public static string ProfileIdClaim => "https://ccp/profileId";
    public static string CcpId => "CcpId";
}
