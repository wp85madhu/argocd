using Azure.Identity;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Fluent;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ProductSubstitution.Infrastructure.CosmosDb.Options;
using ProductSubstitution.Infrastructure.CosmosDb.Repositories;

namespace ProductSubstitution.Infrastructure.CosmosDb;

public static class ServicesExtensions
{
    public static void RegisterCosmosDbRepositories(this IServiceCollection serviceCollection, IConfiguration configuration, bool useConnectionString = false)
    {
        var cosmosOptions = configuration.GetSection(CosmosDbOptions.Section)
            .Get<CosmosDbOptions>();
        CosmosClient cosmosClient;
        if (useConnectionString)
        {
            cosmosClient = new CosmosClientBuilder(cosmosOptions.ConnectionString)
                .WithConnectionModeGateway()
                .WithContentResponseOnWrite(true)
                .Build();
        }
        else
        {
            cosmosClient = new CosmosClientBuilder(cosmosOptions.AccountEndpoint, new DefaultAzureCredential())
                .WithConnectionModeDirect()
                .WithContentResponseOnWrite(true)
                .Build();
        }

        serviceCollection.AddSingleton<ICosmosDbContainerFactory>(_ => new CosmosDbContainerFactory(cosmosClient, cosmosOptions.DatabaseName));
        serviceCollection.AddSingleton<ISubstitutionRepository, SubstitutionRepository>();
    }
}
