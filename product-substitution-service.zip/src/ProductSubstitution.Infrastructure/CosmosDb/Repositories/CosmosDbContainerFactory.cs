using Microsoft.Azure.Cosmos;

namespace ProductSubstitution.Infrastructure.CosmosDb.Repositories;

public class CosmosDbContainerFactory : ICosmosDbContainerFactory
{
    private readonly CosmosClient _cosmosClient;
    private readonly string _databaseName;

    public CosmosDbContainerFactory(CosmosClient cosmosClient, string databaseName)
    {
        _cosmosClient = cosmosClient;
        _databaseName = databaseName;
    }

    public Container GetContainer(string containerName)
    {
        return _cosmosClient.GetContainer(_databaseName, containerName);
    }
}
