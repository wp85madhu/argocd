using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using ProductSubstitution.Infrastructure.CosmosDb.Documents;

namespace ProductSubstitution.Infrastructure.CosmosDb.Repositories;

public abstract class CosmosDbRepository<T> where T : BaseItem
{
    protected abstract string ContainerName { get; }
    protected Container DbContainer { get; }
    protected ILogger Logger { get; }

    protected CosmosDbRepository(ICosmosDbContainerFactory cosmosDbContainerFactory, ILogger logger)
    {
        DbContainer = cosmosDbContainerFactory.GetContainer(ContainerName);
        Logger = logger;
    }
}
