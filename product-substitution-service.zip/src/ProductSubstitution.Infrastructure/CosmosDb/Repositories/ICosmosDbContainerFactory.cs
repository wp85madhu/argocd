using Microsoft.Azure.Cosmos;

namespace ProductSubstitution.Infrastructure.CosmosDb.Repositories;

public interface ICosmosDbContainerFactory
{
    public Container GetContainer(string containerName);
}
