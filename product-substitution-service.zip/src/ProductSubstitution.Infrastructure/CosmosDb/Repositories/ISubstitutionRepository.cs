using ProductSubstitution.Infrastructure.CosmosDb.Documents;

namespace ProductSubstitution.Infrastructure.CosmosDb.Repositories;

public interface ISubstitutionRepository
{
    Task<SubstitutionItem?> ReadItemAsync(string id);

    Task UpsertItemAsync(SubstitutionItem substitutionItem);
}
