using System.Net;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using ProductSubstitution.Infrastructure.CosmosDb.Documents;
using ProductSubstitution.Infrastructure.Exceptions;

namespace ProductSubstitution.Infrastructure.CosmosDb.Repositories;

public class SubstitutionRepository : CosmosDbRepository<SubstitutionItem>, ISubstitutionRepository
{
    protected override string ContainerName => "Substitutions";

    public SubstitutionRepository(ICosmosDbContainerFactory cosmosDbContainerFactory, ILogger<SubstitutionRepository> logger) : base(cosmosDbContainerFactory, logger)
    {
    }

    public async Task<SubstitutionItem?> ReadItemAsync(string id)
    {
        try
        {
            var itemResponse = await DbContainer.ReadItemAsync<SubstitutionItem>(id, new PartitionKey(id));

            Logger.LogInformation("Reading customer product substitutions with RU {RequestCharge}", itemResponse.RequestCharge);

            return itemResponse.Resource;
        }
        catch (CosmosException e)
        {
            switch (e.StatusCode)
            {
                case HttpStatusCode.ServiceUnavailable:
                    throw new CosmosDbNotAvailableException("CosmosDB was not available");
                case HttpStatusCode.NotFound:
                    return null;
                default:
                    Logger.LogError(e, "Exception occurred when getting item id {ItemId}, error {ErrorMessage}", id, e.Message);
                    throw;
            }
        }
    }

    public async Task UpsertItemAsync(SubstitutionItem substitutionItem)
    {
        try
        {
            var item = await DbContainer.UpsertItemAsync(substitutionItem, new PartitionKey(substitutionItem.Id));

            Logger.LogInformation("Updating customer product substitutions with RU {RequestCharge}", item.RequestCharge);
        }
        catch (CosmosException e)
        {
            Logger.LogError(e,
                "Exception occurred when updating item id {ItemId}, error {Message}",
                substitutionItem.Id,
                e.Message);
            throw;
        }
    }
}
