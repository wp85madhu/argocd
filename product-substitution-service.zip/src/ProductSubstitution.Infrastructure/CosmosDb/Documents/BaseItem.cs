﻿using Newtonsoft.Json;

namespace ProductSubstitution.Infrastructure.CosmosDb.Documents;

/// <summary>
/// Azure Function v3 SDK only supports Newtonsoft.Json package to convert json object,
/// Use JsonProperty to decorate property name
/// </summary>
public class BaseItem
{
    [JsonProperty("id")]
    public string Id { get; set; } = string.Empty;

    [JsonProperty("partitionKey")]
    public string PartitionKey { get; set; } = null!;

    [JsonProperty("_etag")]
    public string? ETag { get; }
}
