using Newtonsoft.Json;

namespace ProductSubstitution.Infrastructure.CosmosDb.Documents;

public class Product
{
    [JsonProperty("productId")]
    public string Id { get; set; } = null!;

    [JsonProperty("transactionDate")]
    public DateTimeOffset TransactionDateTime { get; set; }
}
