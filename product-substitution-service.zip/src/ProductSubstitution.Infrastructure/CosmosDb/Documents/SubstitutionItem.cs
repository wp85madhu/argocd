using Newtonsoft.Json;

namespace ProductSubstitution.Infrastructure.CosmosDb.Documents;

public class SubstitutionItem : BaseItem
{
    [JsonProperty("products")]
    public IEnumerable<Product> Products { get; set; } = Enumerable.Empty<Product>();
}
