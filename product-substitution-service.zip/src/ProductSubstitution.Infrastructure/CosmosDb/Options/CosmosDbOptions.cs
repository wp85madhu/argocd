namespace ProductSubstitution.Infrastructure.CosmosDb.Options;

public class CosmosDbOptions
{
    public static string Section => "CosmosDb";
    public string AccountEndpoint { get; set; } = null!;
    public string ConnectionString { get; set; } = string.Empty;
    public string DatabaseName { get; set; } = null!;
}
