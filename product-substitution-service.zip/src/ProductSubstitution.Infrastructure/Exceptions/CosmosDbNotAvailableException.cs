using System.Diagnostics.CodeAnalysis;

namespace ProductSubstitution.Infrastructure.Exceptions;

[ExcludeFromCodeCoverage]
public class CosmosDbNotAvailableException : Exception
{
    public CosmosDbNotAvailableException(string message) : base(message)
    {

    }
}
