namespace ProductSubstitution.Infrastructure;

public static class Common
{
    public static string AzureStorageConnectionStringKey => "AzureWebJobsStorage";
}
