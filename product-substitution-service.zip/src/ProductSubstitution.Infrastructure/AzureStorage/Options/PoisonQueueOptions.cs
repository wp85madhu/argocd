namespace ProductSubstitution.Infrastructure.AzureStorage.Options;

public class PoisonQueueOptions
{
    public static string Section => "PoisonQueue";
    public int TimeToLiveDays { get; set; } = 30;
}
