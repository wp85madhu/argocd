using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ProductSubstitution.Infrastructure.AzureStorage.Options;
using ProductSubstitution.Infrastructure.AzureStorage.Repositories;

namespace ProductSubstitution.Infrastructure.AzureStorage;

public static class ServicesExtensions
{
    public static void RegisterAzureStorage(this IServiceCollection serviceCollection, IConfiguration configuration)
    {
        serviceCollection.Configure<PoisonQueueOptions>(options =>
        {
            configuration.GetSection(PoisonQueueOptions.Section).Bind(options);
        });

        var connectionString = configuration.GetValue<string>(Common.AzureStorageConnectionStringKey);

        serviceCollection.AddSingleton<IAzureStorageFactory>(_ => new AzureStorageFactory(connectionString));
        serviceCollection.AddSingleton<IPoisonQueueRepository, PoisonQueueRepository>();
    }
}
