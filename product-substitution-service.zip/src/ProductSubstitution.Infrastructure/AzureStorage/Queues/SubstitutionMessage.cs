using System.Text.Json.Serialization;

namespace ProductSubstitution.Infrastructure.AzureStorage.Queues;

public class SubstitutionMessage
{
    [JsonPropertyName("id")]
    public string Id { get; set; } = null!;

    [JsonPropertyName("source")]
    public string Source { get; set; } = null!;

    [JsonPropertyName("timeStamp")]
    public DateTimeOffset TimeStamp { get; set; }

    [JsonPropertyName("version")]
    public string Version { get; set; } = null!;

    [JsonPropertyName("data")]
    public Data Data { get; set; } = new();
}
