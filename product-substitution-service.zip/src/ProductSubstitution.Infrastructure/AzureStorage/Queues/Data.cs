using System.Text.Json.Serialization;

namespace ProductSubstitution.Infrastructure.AzureStorage.Queues;

public class Data
{
    [JsonPropertyName("transactionDateTime")]
    public DateTimeOffset TransactionDateTime { get; set; }

    [JsonPropertyName("orderId")]
    public string OrderId { get; set; } = null!;

    [JsonPropertyName("profileId")]
    public string ProfileId { get; set; } = null!;

    [JsonPropertyName("products")]
    public IEnumerable<Product> Products { get; set; } = Enumerable.Empty<Product>();
}
