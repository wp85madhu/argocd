using System.Text.Json.Serialization;

namespace ProductSubstitution.Infrastructure.AzureStorage.Queues;

public class Product
{
    [JsonPropertyName("productId")]
    public string Id { get; set; } = null!;

    [JsonPropertyName("allowSubstitute")]
    public bool AllowSubstitute { get; set; }
}
