using Azure.Storage.Queues.Models;

namespace ProductSubstitution.Infrastructure.AzureStorage.Repositories;

public interface IPoisonQueueRepository
{
    Task SendMessageAsync(QueueMessage queueMessage);
}
