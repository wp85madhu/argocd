using Azure.Storage.Queues;
using Microsoft.Extensions.Logging;

namespace ProductSubstitution.Infrastructure.AzureStorage.Repositories;

public abstract class AzureQueueRepository<T> where T : class
{
    protected abstract string QueueName { get; }
    protected QueueClient QueueClient { get; }
    protected ILogger Logger { get; }

    protected AzureQueueRepository(IAzureStorageFactory azureStorageTableFactory, ILogger logger)
    {
        QueueClient = azureStorageTableFactory.GetQueueClient(QueueName);
        Logger = logger;
    }
}
