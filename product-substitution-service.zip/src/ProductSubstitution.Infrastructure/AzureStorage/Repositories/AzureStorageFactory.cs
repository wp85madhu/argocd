using Azure.Storage.Queues;

namespace ProductSubstitution.Infrastructure.AzureStorage.Repositories;

public class AzureStorageFactory : IAzureStorageFactory
{
    private readonly QueueServiceClient _queueServiceClient;

    public AzureStorageFactory(string connectionString)
    {
        _queueServiceClient = new QueueServiceClient(connectionString);
    }

    public QueueClient GetQueueClient(string queueName) => _queueServiceClient.GetQueueClient(queueName);
}
