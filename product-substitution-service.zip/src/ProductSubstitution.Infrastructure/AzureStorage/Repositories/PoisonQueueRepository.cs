using Azure.Storage.Queues.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using ProductSubstitution.Infrastructure.AzureStorage.Options;

namespace ProductSubstitution.Infrastructure.AzureStorage.Repositories;

public class PoisonQueueRepository : AzureQueueRepository<QueueMessage>, IPoisonQueueRepository
{
    protected override string QueueName => "productsubstitution-poison";

    private readonly PoisonQueueOptions _poisonQueueSettings;

    public PoisonQueueRepository(IAzureStorageFactory azureStorageTableFactory,
        IOptions<PoisonQueueOptions> poisonQueueOptions,
        ILogger<PoisonQueueRepository> logger) : base(azureStorageTableFactory,
        logger)
    {
        _poisonQueueSettings = poisonQueueOptions.Value;
    }

    public async Task SendMessageAsync(QueueMessage queueMessage)
    {
        try
        {
            await QueueClient.SendMessageAsync(queueMessage.Body,
                timeToLive: TimeSpan.FromDays(_poisonQueueSettings.TimeToLiveDays));

            Logger.LogInformation("Pushed message into poison queue, original message Id {OriginalMessageId}",
                queueMessage.MessageId);
        }
        catch (Exception e)
        {
            Logger.LogError(e,
                "Error occurred when pushing message into poison queue, original message Id {OriginalMessageId}, error {ErrorMessage}",
                queueMessage.MessageId, e.Message);
        }
    }
}
