using Azure.Storage.Queues;

namespace ProductSubstitution.Infrastructure.AzureStorage.Repositories;

public interface IAzureStorageFactory
{
    public QueueClient GetQueueClient(string queueName);
}
