namespace ProductSubstitution.Core.Options;

public class ProductRetentionOptions
{
    public static string Section => "ProductRetention";
    public int Days { get; init; } = 90;
}
