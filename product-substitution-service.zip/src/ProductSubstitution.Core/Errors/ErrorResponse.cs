using System.Diagnostics;

namespace ProductSubstitution.Core.Errors;

public class ErrorResponse
{
    public string TraceId { get; set; }

    public DateTime Timestamp { get; set; }

    public IEnumerable<ErrorDetail> Errors { get; set; }

    public ErrorResponse()
    {
        TraceId = Activity.Current?.TraceId.ToString() ?? Guid.Empty.ToString();
        Timestamp = DateTime.UtcNow;
        Errors = new List<ErrorDetail>();
    }

    public ErrorResponse(string errorCode, string message, ErrorPriority errorPriority, ErrorProperty? properties = null)
    {
        TraceId = Activity.Current?.TraceId.ToString() ?? Guid.Empty.ToString();
        Timestamp = DateTime.UtcNow;
        Errors = new List<ErrorDetail>
        {
            new()
            {
                ErrorCode = errorCode,
                Message = message,
                Priority = errorPriority,
                Properties = properties
            }
        };
    }
}
