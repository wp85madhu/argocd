
namespace ProductSubstitution.Core.Errors;

public class ErrorDetail
{
    public string ErrorCode { get; set; } = null!;
    public string Message { get; set; } = null!;
    public ErrorPriority Priority { get; set; }
    public ErrorProperty? Properties { get; set; }
}
