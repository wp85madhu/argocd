using System.Text.Json.Serialization;

namespace ProductSubstitution.Core.Errors;

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum ErrorPriority
{
    HIGH,
    MEDIUM,
    LOW
}
