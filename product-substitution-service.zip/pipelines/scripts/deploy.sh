#!/bin/bash
#
# Purpose: This script will update the container image used by a kubernetes kustomize deployment 
#   This script does not apply the changes to a Kubernetes cluster, it simply updates the overlay
#   for the environment passed as parameter 1
#
# Inputs:
#   1. Environment/Overlay Name: This is the name of the kustomize overlay to be updated
#   2. Image name: This is the container image reference that is to be deployed
#   3. Work Directory: this is the directory containing the microservice git repo

set -ue -o pipefail

#Script Parameters
enviro="$1"
imageRef="$2"
workDir="$3"

msName=$(basename "${imageRef}" | cut -d ":" -f1)

kustomizeInstalled="N"
kustomizePath=""
kustomizeInstall=https://raw.githubusercontent.com/kubernetes-sigs/kustomize/master/hack/install_kustomize.sh

if [[ ! $(command -v kustomize) ]]; then

    if [[ -e kustomize ]]
    then
        echo "Remove local version of kustomize"
        rm kustomize
    fi
    echo "Installing kustomize"
    curl -sS "${kustomizeInstall}"  | bash
    kustomizeInstalled=Y
    kustomizePath="$(pwd)/"
fi

cd "${workDir}/manifests/${enviro}"

echo "Image name: '${imageRef}'"

echo "Updating ${enviro} environment image for ${msName}..."
"${kustomizePath}kustomize" edit set image "${msName}"="${imageRef}"
echo "Done"

#Validate kustomize builds successfully
if ! "${kustomizePath}kustomize" build >/dev/null
then
    echo "Kustomize build failed, Please Investigate!"
    exit 1
fi

if [[ ${kustomizeInstalled} == 'Y' ]]
then
    rm "${kustomizePath}kustomize"
fi

