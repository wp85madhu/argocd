#!/bin/bash

#set -x
############################ FUNCTIONS ####################################################
terraform_apply() { 
    echo "======================================================="
    echo "================ Apply Terraform ======================="
    echo "======================================================="

    terraform apply \
      -no-color \
      $tf_var_files \
      -var "client_id=$servicePrincipalId" \
      -auto-approve \
      -input=false \
      $working_directory

    EXIT_CODE="$?"
    if [[ "$EXIT_CODE" -gt 0 ]]; then exit "$EXIT_CODE"; fi
}

########################### MAIN ####################################################
# This path won't work if not using BASH
. "${BASH_SOURCE%/*}"/terraform_init_plan.sh
terraform_apply