# Requirements

https://colesgroup.atlassian.net/wiki/spaces/DTPE/pages/358451258/Product+List+-+Platform+Service